# Introduction 
CustomerManagement is an ASP.NET Core 2.0 application with Angular 5.
CustomerManagement provides ASP.NET Web APIs (REST APIs) for creating PL customers. 
The client Angular web and the APIs are placed in one project.
Bearer and Cookies AuthenticationSchemes are used to authenticate the APIs.
Hybrid Flow is used to authenticate the client Angular web.

# Getting Started
1.	Installation process
2.	Software dependencies
Customer Management requires Raven 4.0 to run. Safest way to run version 4.0 side by side with Raven 3.x is to use Docker.
https://docs.docker.com/docker-for-windows/
Please note that you have to Switch to Windows Containers after docker is installed.

With that set up you can get latest version of raven server from https://hub.docker.com/r/ravendb/ravendb/
You can download docker image: docker pull ravendb/ravendb:windows-nanoserver-latest
Because containers can be stopped and loose any data they had please set up a folder for raven data at C:\DockerShare\RavenDB4
And start the server using script: .\scripts\start-raven4.ps1

If we run CustomerManagement and after signing in SSO we have an "authorization failed" message,
this is because Docker has assigned a random IP address to the project CustomerManagement.
To know which IP to use, run User management side by side and look at the Output / Debug window when we log in.
We will see an error for an "Invalid redirect_uri" which, in this case, these allowed Uris:
"AllowedRedirectUris": [
  "http://localhost:2464/signin-oidc",
  "http://localhost:60001/signin-oidc"
]
We will set the URL to the port 60001 and that will work.

Other option is to correct it manually in appsettings (or use an enviroment variable).
Note that the IP will change when you stop or start the server again.

3.	Latest releases
4.	API references
http://localhost:60001/swagger/
5.	Usage
Global Resources APIs running are required.
You can send language in Accept-Language header or in the url parameter. For example,
Accept-Language = "vi-VN" or
PATCH http://localhost:60001/api/v1/customers/{customerId}?culture=vi-VN

# Build and Test
1.	Build

2.	Test
The RavenServerPath in appsettings must reference to the directory of Raven.Server.dll
For example, "RavenServerPath": "C:\\RavenDB-4.0.0-rc-40023-windows-x64\\Server"

# Contribute
New BDD tests:
You have to include your Specflow features in the CustomerManagement.Api.Test.csproj as below to be able to debug or run Specflow scenarios.
<ItemGroup>
	<SpecFlowEmbeddedFeature Include="Features\CustomerRegistration.feature" />
	<SpecFlowEmbeddedFeature Include="Features\CustomerEdit.feature" />
</ItemGroup>