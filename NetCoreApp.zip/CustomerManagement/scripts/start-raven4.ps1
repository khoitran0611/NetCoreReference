﻿. .\run-nanoserver.ps1 -DataDir "C:\DockerShare\RavenDB4" -AuthenticationDisabled

$ravenUrl = "$($scheme)://$($ravenIp):$BindPort"
$customerManagementUrlEV = "CustomerManagement:RavenStoreOptions:Url"
write-host -fore green "Setting up $customerManagementUrlEV=$ravenUrl"
[environment]::SetEnvironmentVariable($customerManagementUrlEV, $ravenUrl, "Machine")