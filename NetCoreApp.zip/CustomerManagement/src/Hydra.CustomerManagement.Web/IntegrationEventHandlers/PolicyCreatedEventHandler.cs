﻿using System;
using System.Threading.Tasks;
using Hydra.Common.Integration.EventBus;
using Hydra.Common.Integration.EventBus.Exceptions;
using Hydra.CustomerManagement.Web.Services;
using Hydra.Insurance.IntegrationEvents;
using Microsoft.Extensions.Logging;

namespace Hydra.CustomerManagement.Web.IntegrationEventHandlers
{
    public class PolicyCreatedEventHandler : BaseIntegrationEventHandler, IIntegrationEventHandler<PolicyCreatedEvent>
    {
        private readonly ICustomerManagementService customerRepository;
        private readonly ILogger<PolicyCreatedEventHandler> logger;

        public PolicyCreatedEventHandler(ICustomerManagementService customerRepository, ILogger<PolicyCreatedEventHandler> logger)
        {
            this.customerRepository = customerRepository;
            this.logger = logger;
        }

        public async Task<IntegrationEventHandlerResponse> Handle(PolicyCreatedEvent @event)
        {
            try
            {
                await this.customerRepository.AddPolicyToCustomerAsync(
                    @event.PolicyIdentity.PolicyHolderId.ToString(),
                    new Domain.PolicySummary
                    {
                        PolicyId = @event.PolicyIdentity.PolicyId,
                        Version = @event.PolicyIdentity.PolicyVersion,
                        PolicyReference = @event.PolicyReference,
                        ProductId = @event.Product.ProductProfileId.ToString(),
                        ProductName = @event.Product.ProductName,
                        PolicyStart = @event.PolicyStart,
                        PolicyEnd = @event.PolicyEnd,
                        IsActive = false,
                        Premium = @event.PolicyPremium.Amount,
                        Currency = @event.PolicyPremium.Currency,
                        FormattedPremium = @event.PolicyPremium.FormattedAmount,
                        PartnerId = @event.PartnerId,
                        Scope = @event.MetaData.Scope,
                        OrganisationContext = @event.MetaData.OrganisationContext,
                    },
                    @event.MetaData.CorrelationId);

                return Handled();
            }
            catch (OutOfSequenceExternalVersionException ex)
            {
                logger.LogInformation(ex, $"Retrying {nameof(PolicyCreatedEvent)}; version {@event.PolicyIdentity.PolicyVersion} out of sequence");
                return Retry();
            }
            catch (OldExternalVersionException ex)
            {
                logger.LogInformation(ex, $"Rejecting {nameof(PolicyCreatedEvent)}; already handled version {@event.PolicyIdentity.PolicyVersion}");
                return Reject();
            }
            catch (Exception ex)
            {
                logger.LogError(ex, $"Error whilst handling {nameof(PolicyCreatedEvent)} event for policy {@event.PolicyIdentity.PolicyId}");
                return Retry();
            }
        }
    }
}
