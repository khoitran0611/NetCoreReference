﻿using System;
using System.Threading.Tasks;
using Hydra.Common.Integration.EventBus;
using Hydra.Common.Integration.EventBus.Exceptions;
using Hydra.CustomerManagement.Web.Services;
using Hydra.Insurance.IntegrationEvents;
using Microsoft.Extensions.Logging;

namespace Hydra.CustomerManagement.Web.IntegrationEventHandlers
{
    public class PolicyRemovedEventHandler : BaseIntegrationEventHandler, IIntegrationEventHandler<PolicyCancelledEvent>
    {
        private readonly ICustomerManagementService customerRepository;
        private readonly ILogger<PolicyRemovedEventHandler> logger;

        public PolicyRemovedEventHandler(ICustomerManagementService customerRepository, ILogger<PolicyRemovedEventHandler> logger)
        {
            this.customerRepository = customerRepository;
            this.logger = logger;
        }

        public async Task<IntegrationEventHandlerResponse> Handle(PolicyCancelledEvent @event)
        {
            try
            {
                await this.customerRepository.RemovePolicyFromCustomerAsync(
                    @event.PolicyIdentity.PolicyHolderId.ToString(),
                    @event.PolicyIdentity.PolicyId,
                    @event.PolicyIdentity.PolicyVersion,
                    @event.MetaData.CorrelationId);

                return Handled();
            }
            catch (OutOfSequenceExternalVersionException ex)
            {
                logger.LogInformation(ex, $"Retrying removal of policy {@event.PolicyIdentity.PolicyId}, version {@event.PolicyIdentity.PolicyVersion} - out of sequence");
                return Retry();
            }
            catch (OldExternalVersionException ex)
            {
                logger.LogInformation(ex, $"Rejecting removal of policy {@event.PolicyIdentity.PolicyId} - already handled version {@event.PolicyIdentity.PolicyVersion}");
                return Reject();
            }
            catch (Exception ex)
            {
                logger.LogError(ex, $"Error whilst handling {nameof(PolicyCancelledEvent)} event for policy {@event.PolicyIdentity.PolicyId}");
                return Retry();
            }
        }
    }
}
