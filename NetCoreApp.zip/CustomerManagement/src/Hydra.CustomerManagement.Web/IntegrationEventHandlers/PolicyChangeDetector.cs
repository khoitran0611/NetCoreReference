﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Hydra.CustomerManagement.Web.Domain;
using Hydra.Insurance.IntegrationEvents;

namespace Hydra.CustomerManagement.Web.IntegrationEventHandlers
{
    public class PolicyChangeDetector
    {
        private readonly PolicyPeriodChange policyPeriodChange;
        private readonly PolicyPremiumChange policyPremiumChange;
        private readonly bool? isActiveChange;

        public PolicyChangeDetector(PolicyPeriodChange policyPeriodChange = null, PolicyPremiumChange policyPremiumChange = null, bool? isActiveChange = null)
        {
            this.policyPeriodChange = policyPeriodChange;
            this.policyPremiumChange = policyPremiumChange;
            this.isActiveChange = isActiveChange;
        }

        public PolicyChange Detect()
        {
            var changes = new PolicyChange();

            bool startDateChanged = policyPeriodChange == null ? false : policyPeriodChange.NewPolicyStartDate != policyPeriodChange.OriginalStartDate;
            bool endDateChanged = policyPeriodChange == null ? false : policyPeriodChange.NewPolicyEndDate != policyPeriodChange.OriginalEndDate;
            if (startDateChanged || endDateChanged)
            {
                changes.PolicyPeriod = new PolicyChange.Period
                {
                    Start = policyPeriodChange.NewPolicyStartDate,
                    End = policyPeriodChange.NewPolicyEndDate,
                };
            }
            bool premiumChanged = policyPeriodChange == null ? false : policyPremiumChange.NewPremium != policyPremiumChange.OriginalPremium;
            if (premiumChanged)
            {
                changes.Premium = policyPremiumChange.NewPremium.Amount;
                changes.Currency = policyPremiumChange.NewPremium.Currency;
                changes.FormattedPremium = policyPremiumChange.NewPremium.FormattedAmount;
            }
            bool isActiveChanged = isActiveChange.HasValue;
            if (isActiveChanged)
            {
                changes.IsActive = isActiveChange.Value;
            }

            return changes;
        }
    }
}
