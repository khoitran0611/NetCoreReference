﻿using System;
using System.Threading.Tasks;
using Hydra.Common.Integration.EventBus;
using Hydra.Common.Integration.EventBus.Events;
using Hydra.Common.Integration.EventBus.Exceptions;
using Hydra.CustomerManagement.Web.Services;
using Hydra.Insurance.IntegrationEvents;
using Microsoft.Extensions.Logging;

namespace Hydra.CustomerManagement.Web.IntegrationEventHandlers
{
    public class PolicyUpdatedEventHandler :
        BaseIntegrationEventHandler,
        IIntegrationEventHandler<PolicyInceptionExecutedEvent>,
        IIntegrationEventHandler<PolicyDetailsUpdatedEvent>,
        IIntegrationEventHandler<PolicyExpiredEvent>,
        IIntegrationEventHandler<PolicyTerminatedEvent>
    {
        private readonly ICustomerManagementService customerRepository;
        private readonly ILogger<PolicyUpdatedEventHandler> logger;

        public PolicyUpdatedEventHandler(ICustomerManagementService customerRepository, ILogger<PolicyUpdatedEventHandler> logger)
        {
            this.customerRepository = customerRepository;
            this.logger = logger;
        }

        public async Task<IntegrationEventHandlerResponse> Handle(PolicyInceptionExecutedEvent @event)
        {
            var policyChange = new PolicyChangeDetector(isActiveChange: true).Detect();
            return await ProcessPolicyUpdate(@event, @event.PolicyIdentity, policyChange);
        }

        public async Task<IntegrationEventHandlerResponse> Handle(PolicyDetailsUpdatedEvent @event)
        {
            var policyChange = new PolicyChangeDetector(@event.PolicyPeriodChange, @event.PolicyPremiumChange).Detect();
            return await ProcessPolicyUpdate(@event, @event.PolicyIdentity, policyChange);
        }

        public async Task<IntegrationEventHandlerResponse> Handle(PolicyExpiredEvent @event)
        {
            var policyChange = new PolicyChangeDetector(isActiveChange: false).Detect();
            return await ProcessPolicyUpdate(@event, @event.PolicyIdentity, policyChange);
        }

        public async Task<IntegrationEventHandlerResponse> Handle(PolicyTerminatedEvent @event)
        {
            var policyChange = new PolicyChangeDetector(
                @event.PolicyPeriodChange,
                @event.PolicyPremiumChange,
                isActiveChange: false).Detect();
            return await ProcessPolicyUpdate(@event, @event.PolicyIdentity, policyChange);
        }

        private async Task<IntegrationEventHandlerResponse> ProcessPolicyUpdate(
            BaseIntegrationEvent @event,
            PolicyIdentity policyIdentity,
            Domain.PolicyChange policyChange)
        {
            try
            {
                await this.customerRepository.UpdateCustomerPolicyAsync(
                    policyIdentity.PolicyHolderId.ToString(),
                    policyIdentity.PolicyId,
                    policyIdentity.PolicyVersion,
                    policyChange,
                    @event.MetaData.CorrelationId);

                return Handled();
            }
            catch (OutOfSequenceExternalVersionException ex)
            {
                logger.LogInformation(ex, $"Retrying update event for policy {policyIdentity.PolicyId}, version {policyIdentity.PolicyVersion} - out of sequence");
                return Retry();
            }
            catch (OldExternalVersionException ex)
            {
                logger.LogInformation(ex, $"Rejecting update event for policy {policyIdentity.PolicyId} - already handled version {policyIdentity.PolicyVersion}");
                return Reject();
            }
            catch (Exception ex)
            {
                logger.LogError(ex, $"Error whilst handling insurance update event for policy {policyIdentity.PolicyId}");
                return Retry();
            }
        }
    }
}
