using System;

namespace Hydra.CustomerManagement.Web.Models
{
    public class ErrorViewModel
    {
        public string RequestId { get; set; }

        public bool ShowRequestId => !string.IsNullOrEmpty(RequestId);

        public bool ShowApplicationInsightsId => !string.IsNullOrEmpty(ApplicationInsightsId);

        public string ApplicationInsightsId { get; set; }

        public Exception Error { get; set; }

        public DateTimeOffset OccurredAt { get; set; }

        public string Path { get; set; }
    }
}