﻿using System;

namespace Hydra.CustomerManagement.Web.Models.VietnamPrivateLines
{
    public class VietnamPrivateLinesCustomerViewModel
    {
        public PersonName PersonName { get; set; }
        public PersonalInformation PersonalInformation { get; set; }
        public IdentificationDetails IdentificationDetails { get; set; }
        public PassportDetails PassportDetails { get; set; }
        public ContactDetails ContactDetails { get; set; }
        public InsuranceDetails InsuranceDetails { get; set; }
        public Banking Banking { get; set; }
        public bool IsEmbedded { get; set; }
    }

    public class Address
    {
        public string AddressLine { get; set; }
        public string CityOrProvince { get; set; }
    }

    public class Banking
    {
        public string BankAccountNumber { get; set; }
        public string BankName { get; set; }
    }

    public class ContactDetails
    {
        public Address ContactAddress { get; set; }
        public string MobilePhone { get; set; }
        public string HomePhone { get; set; }
        public string EmailAddress { get; set; }
    }

    public class IdentificationDetails
    {
        public string IdentificationNumber { get; set; }
        public DateTimeOffset? IssueDate { get; set; }
        public DateTimeOffset? ExpiryDate { get; set; }
        public string IssuedBy { get; set; }
        public Address PermanentResidenceAddress { get; set; }
    }

    public class InsuranceDetails
    {
        public string RenewalMode { get; set; }
        public string PaymentMethod { get; set; }
    }

    public class PassportDetails
    {
        public string PassportNumber { get; set; }
        public DateTimeOffset? IssueDate { get; set; }
        public DateTimeOffset? ExpiryDate { get; set; }
        public string IssuedBy { get; set; }
    }

    public class PersonalInformation
    {
        public string Gender { get; set; }
        public DateTimeOffset? BirthDate { get; set; }
        public string BirthPlace { get; set; }
    }

    public class PersonName
    {
        public string LastName { get; set; }
        public string MiddleName { get; set; }
        public string FirstName { get; set; }
    }
}