﻿using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using Hydra.CustomerManagement.Web.Domain;
using Hydra.CustomerManagement.Web.Domain.SwedenPrivateLines;
using Hydra.CustomerManagement.Web.I18n;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace Hydra.CustomerManagement.Web.Models.SwedenPrivateLines
{
    public class SwedenPrivateLinesCustomerViewModel : IUniqueIdentificationNumberCheck
    {
        internal const string ContactMotorRegistryOptionYes = "Yes";
        internal const string ContactMotorRegistryOptionNo = "No";

        internal const string PaymentMethodAnnualPBS = "Annual - PBS";
        internal const string PaymentMethodMonthlyPBS = "Monthly - PBS";
        internal const string PaymentMethodAnnualGiro = "Annual - Giro";
        internal const string PaymentMethodMonthlyGiro = "Monthly - Giro";

        [HiddenInput]
        [ReadOnly(true)]
        public Guid CustomerId { get; set; }

        public CustomerNames CustomerNames { get; set; } = new CustomerNames();
        public CustomerDetails CustomerDetails { get; set; } = new CustomerDetails();
        public AddressDetails DefaultAddressDetails { get; set; } = new AddressDetails();
        public InsuranceDefaults InsuranceDefaults { get; set; } = new InsuranceDefaults();
        public AdditionalDetails AdditionalDetails { get; set; } = new AdditionalDetails();

        public string ReturnSystemId { get; set; }

        public string ReturnCancelLink { get; set; }

        public string ReturnSuccessLink { get; set; }

        public string ParentOrigin => !string.IsNullOrWhiteSpace(ReturnSuccessLink) ? new Uri(ReturnSuccessLink).GetLeftPart(UriPartial.Authority) : string.Empty;

        public SelectList PaymentMethods { get; set; }

        public bool IsIdentificationNumberUnique => true;

        public bool IsUpdating { get; set; }

        public object SourceName => "ExternalSwedenPL";

        [Required(ErrorMessageResourceName = "MotorRegistryRequired", ErrorMessageResourceType = typeof(ResourceStrings.Validation))]
        [StringLength(5)]
        public string ContactMotorRegistry { get; set; } = ContactMotorRegistryOptionYes;

        public SelectList MotorRegistryContactOptions { get; set; }

        public string[] LinkParameters { get; set; }

        public bool IsEmbedded { get; set; }
        public bool UsePostMessage { get; set; }

        internal bool ContactMotorRegistryFlag => ContactMotorRegistry == ContactMotorRegistryOptionYes;
    }
}