﻿using System;
using System.ComponentModel.DataAnnotations;
using Hydra.CustomerManagement.Web.Attributes;
using Microsoft.AspNetCore.Http;

namespace Hydra.CustomerManagement.Web.Models.SwedenPrivateLines
{
    public class UpsertSwedenBlacklistNinsViewModel
    {
        [Required]
        [StringLength(1)]
        [Display(Name = "CustomerManagement_BlacklistManagement_Delimiter")]
        public string Delimiter { get; set; }

        [Required]
        [DisplayAsFileInput]
        [Display(Name = "CustomerManagement_UploadBlacklistFile")]
        public IFormFile BlacklistFile { get; set; }

        public string ReturnSystemId { get; set; }
        public string ReturnLink { get; set; }
        public bool IsEmbedded { get; set; }
    }
}