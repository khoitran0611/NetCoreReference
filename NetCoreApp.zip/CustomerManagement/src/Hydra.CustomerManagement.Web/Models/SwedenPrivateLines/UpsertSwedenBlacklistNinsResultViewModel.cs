﻿using System;
using System.ComponentModel.DataAnnotations;
using Hydra.CustomerManagement.Web.Attributes;

namespace Hydra.CustomerManagement.Web.Models.SwedenPrivateLines
{
    public class UpsertSwedenBlacklistNinsResultViewModel
    {
        [DisplayAsReadOnly]
        [Display(Name = "CustomerManagement_BlacklistManagement_JobId")]
        public string JobId { get; set; }

        [DisplayAsReadOnly]
        [Display(Name = "CustomerManagement_BlacklistManagement_UpsertStatus")]
        public string UpsertStatusText { get; set; }

        [DisplayAsReadOnly]
        [Display(Name = "CustomerManagement_BlacklistManagement_NumberOfNewlyBlacklisted")]
        public int NumberOfNewlyBlacklistedNins { get; set; }

        [DisplayAsReadOnly]
        [Display(Name = "CustomerManagement_BlacklistManagement_NumberOfNewlyWhitelisted")]
        public int NumberOfNewlyWhitelistedNins { get; set; }

        [DisplayAsReadOnly]
        [Display(Name = "CustomerManagement_BlacklistManagement_TotalInThisBatch")]
        public int TotalBlacklistedNinsInTheBatch { get; set; }

        [DisplayAsReadOnly]
        [Display(Name = "CustomerManagement_BlacklistManagement_NumberOfBlacklistedCustomers")]
        public int NumberOfCustomersBlacklisted { get; set; }

        [DisplayAsReadOnly]
        [Display(Name = "CustomerManagement_BlacklistManagement_NumberOfWhitelistedCustomers")]
        public int NumberOfCustomersWhitelisted { get; set; }

        public string ReturnSystemId { get; set; }
        public string ReturnLink { get; set; }
        public bool IsEmbedded { get; set; }
    }
}