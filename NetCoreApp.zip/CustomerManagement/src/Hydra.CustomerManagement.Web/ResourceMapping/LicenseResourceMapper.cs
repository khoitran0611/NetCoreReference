﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Hydra.Common.CountrySpecific.Sweden;
using Hydra.CustomerManagement.Web.Resources;
using Hydra.MotorRegistry.Client.CountrySpecific.Sweden;
using Microsoft.Extensions.Localization;

namespace Hydra.CustomerManagement.Web.ResourceMapping
{
    public interface ILicenseResourceMapper
    {
        Task<LicenseResource> Map(string nin, string contextId, Func<string, string> getNinInformationActionUrl);
    }

    public class LicenseResourceMapper : ILicenseResourceMapper
    {
        private readonly IMotorRegistryClient motorRegistryClient;
        private readonly IStringLocalizer localizer;
        private readonly ISwedenNinService swedenNinService;

        public LicenseResourceMapper(
            IStringLocalizer localizer,
            ISwedenNinService swedenNinService,
            IMotorRegistryClient motorRegistryClient)
        {
            this.motorRegistryClient = motorRegistryClient;
            this.localizer = localizer;
            this.swedenNinService = swedenNinService;
        }

        public async Task<LicenseResource> Map(string nin, string contextId, Func<string, string> getNinInformationActionUrl)
        {
            LicenseResource licenseResource;
            var validation = swedenNinService.Validate(nin);
            if (validation.IsValid)
            {
                try
                {
                    var response = await motorRegistryClient.GetHP04(nin.Replace("-", ""), contextId);
                    licenseResource = new LicenseResource(swedenNinService, response);
                }
                catch
                {
                    licenseResource = new LicenseResource(localizer.GetString("Error_MR_ErrorFindingNinData"), isValidNin: true);
                }
            }
            else
            {
                licenseResource = new LicenseResource(localizer.GetString(validation.ErrorCode), isValidNin: false);
            }

            licenseResource.Links.Add("ninInformation", getNinInformationActionUrl(nin));
            return licenseResource;
        }
    }
}