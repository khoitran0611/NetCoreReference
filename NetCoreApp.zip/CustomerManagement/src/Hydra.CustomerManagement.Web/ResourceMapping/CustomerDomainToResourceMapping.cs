﻿using System;
using System.Linq;
using AutoMapper;
using Hydra.CustomerManagement.Web.Domain.SwedenPrivateLines;
using Hydra.CustomerManagement.Web.Resources;

namespace Hydra.CustomerManagement.Web.ResourceMapping
{
    public class CustomerDomainToResourceMapping : Profile
    {
        public CustomerDomainToResourceMapping()
        {
            MapSwedenCustomerToCustomerResource();
            MapSwedenCustomerToResourceAttributes();
        }

        private void MapSwedenCustomerToCustomerResource()
        {
            CreateMap<SwedenPrivateLinesCustomer, CustomerResource>()
               .ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.Id))
               .ForMember(dest => dest.Attributes, opt => opt.MapFrom(src =>
                   new CustomerResourceAttributes
                   {
                       Reference = src.Reference,
                       SourceName = src.SourceName,
                       Version = src.Version
                   }))
               .ForMember(dest => dest.Type, opt => opt.Ignore())
               .AfterMap((spc, cr) => Mapper.Map(spc.AdditionalDetails, cr.Attributes.AdditionalDetails))
               .AfterMap((spc, cr) => Mapper.Map(spc.CustomerDetails, cr.Attributes.CustomerDetails))
               .AfterMap((spc, cr) => Mapper.Map(spc.CustomerNames, cr.Attributes.CustomerNames))
               .AfterMap((spc, cr) => Mapper.Map(spc.DefaultAddressDetails, cr.Attributes.DefaultAddressDetails))
               .AfterMap((spc, cr) => Mapper.Map(spc.InsuranceDefaults, cr.Attributes.InsuranceDefaults));
        }

        private void MapSwedenCustomerToResourceAttributes()
        {
            CreateMap<AdditionalDetails, AdditionalDetailsAttributes>()
               .ForMember(dest => dest.AdditionalInformation, opt => opt.MapFrom(src => src.AdditionalInformation));

            CreateMap<CustomerDetails, CustomerDetailsAttributes>()
               .ForMember(dest => dest.DateOfBirth, opt => opt.MapFrom(src => src.DateOfBirth))
               .ForMember(dest => dest.Email, opt => opt.MapFrom(src => src.Email))
               .ForMember(dest => dest.IdentificationNumber, opt => opt.MapFrom(src => src.IdentificationNumber))
               .ForMember(dest => dest.MobileNumber, opt => opt.MapFrom(src => src.MobileNumber))
               .ForMember(dest => dest.TelephoneNumber, opt => opt.MapFrom(src => src.TelephoneNumber))
               .ForMember(dest => dest.IsBlacklisted, opt => opt.MapFrom(src => src.IsBlacklisted));

            CreateMap<CustomerNames, CustomerNamesAttributes>()
               .ForMember(dest => dest.FirstName, opt => opt.MapFrom(src => src.FirstName))
               .ForMember(dest => dest.LastName, opt => opt.MapFrom(src => src.LastName));

            CreateMap<AddressDetails, AddressDetailsAttributes>()
               .ForMember(dest => dest.AddressId, opt => opt.MapFrom(src => src.AddressId))
               .ForMember(dest => dest.AddressLineOne, opt => opt.MapFrom(src => src.AddressLineOne))
               .ForMember(dest => dest.AddressType, opt => opt.MapFrom(src => src.AddressType))
               .ForMember(dest => dest.City, opt => opt.MapFrom(src => src.City))
               .ForMember(dest => dest.Country, opt => opt.MapFrom(src => src.Country))
               .ForMember(dest => dest.IsDefault, opt => opt.MapFrom(src => src.IsDefault))
               .ForMember(dest => dest.PostCode, opt => opt.MapFrom(src => src.PostCode));

            CreateMap<InsuranceDefaults, InsuranceDefaultsAttributes>()
               .ForMember(dest => dest.PaymentMethod, opt => opt.MapFrom(src => src.PaymentMethod))
               .ForMember(dest => dest.RenewalMode, opt => opt.MapFrom(src => src.RenewalMode));
        }
    }
}