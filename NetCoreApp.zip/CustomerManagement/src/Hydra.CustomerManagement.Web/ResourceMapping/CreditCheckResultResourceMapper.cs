﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Hydra.Common.CountrySpecific.Sweden;
using Hydra.CustomerManagement.Web.Resources;
using Hydra.CustomerManagement.Web.Services;
using Microsoft.Extensions.Localization;

namespace Hydra.CustomerManagement.Web.ResourceMapping
{
    public interface ICreditCheckResultResourceMapper
    {
        Task<CreditCheckResultResource> Map(string nin, Func<string, string> getNinInformationActionUrl);
    }

    public class CreditCheckResultResourceMapper : ICreditCheckResultResourceMapper
    {
        private readonly INinManagmentService ninManagementService;
        private readonly IStringLocalizer localizer;
        private readonly ISwedenNinService swedenNinService;

        public CreditCheckResultResourceMapper(
            IStringLocalizer localizer,
            ISwedenNinService swedenNinService,
            INinManagmentService ninManagementService)
        {
            this.ninManagementService = ninManagementService;
            this.localizer = localizer;
            this.swedenNinService = swedenNinService;
        }

        public async Task<CreditCheckResultResource> Map(string nin, Func<string, string> getNinInformationActionUrl)
        {
            CreditCheckResultResource creditCheckResultResource;
            var validation = swedenNinService.Validate(nin);
            if (validation.IsValid)
            {
                var response = await ninManagementService.GetCreditCheckResultAsync(nin);
                creditCheckResultResource = new CreditCheckResultResource(response);
            }
            else
            {
                creditCheckResultResource = new CreditCheckResultResource(localizer.GetString(validation.ErrorCode));
            }

            creditCheckResultResource.Links.Add("ninInformation", getNinInformationActionUrl(nin));
            return creditCheckResultResource;
        }
    }
}