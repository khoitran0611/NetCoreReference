﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Hydra.Common.CountrySpecific.Sweden;
using Hydra.CustomerManagement.Web.I18n;
using Hydra.CustomerManagement.Web.Resources;
using Hydra.CustomerManagement.Web.Services;
using Microsoft.Extensions.Localization;

namespace Hydra.CustomerManagement.Web.ResourceMapping
{
    public interface INinInformationResourceMapper
    {
        Task<NinInformationResource> Map(string nin, Func<string, IDictionary<string, string>> relatedLinks);
    }

    public class NinInformationResourceMapper : INinInformationResourceMapper
    {
        private readonly IStringLocalizer localizer;
        private readonly ICustomerManagementService customerRepository;
        private readonly ISwedenNinService swedenNinService;

        public NinInformationResourceMapper(
            IStringLocalizer localizer,
            ICustomerManagementService customerRepository,
            ISwedenNinService swedenNinService)
        {
            this.localizer = localizer;
            this.customerRepository = customerRepository;
            this.swedenNinService = swedenNinService;
        }

        public async Task<NinInformationResource> Map(string nin, Func<string, IDictionary<string, string>> relatedLinks)
        {
            var result = new NinInformationResource();
            var validation = swedenNinService.Validate(nin);
            if (validation.IsValid)
            {
                var customerId = await customerRepository.GetCustomerIdByIdentificationNumberAsync(nin);
                if (customerId == Guid.Empty)
                {
                    var dateOfBirthResult = swedenNinService.GetDateOfBirthFromNin(nin);
                    if (dateOfBirthResult.DateOfBirth.HasValue)
                    {
                        result.IsValid = true;
                        result.DateOfBirth = dateOfBirthResult.DateOfBirth;
                    }
                    else
                    {
                        result.IsValid = false;
                        result.LocalisedMessage = localizer.GetString(dateOfBirthResult.ErrorCode);
                    }
                }
                else
                {
                    result.AlreadyExists = true;
                    result.LocalisedMessage = ResourceStrings.Validation.Duplicate_Customer(localizer, customerId);
                    result.CustomerId = customerId;
                }
            }
            else
            {
                result.IsValid = false;
                result.LocalisedMessage = localizer.GetString(validation.ErrorCode);
            }

            foreach (var linkInfo in relatedLinks(nin))
            {
                result.Links.Add(linkInfo.Key, linkInfo.Value);
            }

            return result;
        }
    }
}