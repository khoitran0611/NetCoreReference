﻿using System;
using System.Linq;
using Newtonsoft.Json.Linq;

namespace Hydra.CustomerManagement.Web.ResourceMapping
{
    public static class JTokenKeyExtension
    {
        public static string TokenPath(this string key)
        {
            return $".{Char.ToLowerInvariant(key[0])}{key.Substring(1)}";
        }
    }

    public static class JTokenExtension
    {
        public static bool Exists(this JToken token, string key)
        {
            return token.SelectToken(key.TokenPath()) != null;
        }

        public static JToken Get(this JToken token, string key)
        {
            return token.SelectToken(key.TokenPath());
        }

        public static void ApplyIfExists(this JToken token, string key, Action<JToken> action)
        {
            if (token.Exists(key))
            {
                action(token.Get(key));
            }
        }
    }
}