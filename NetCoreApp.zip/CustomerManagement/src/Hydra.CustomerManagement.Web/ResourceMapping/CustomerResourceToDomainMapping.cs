﻿using System;
using System.Linq;
using AutoMapper;
using Hydra.CustomerManagement.Web.Domain.SwedenPrivateLines;
using Hydra.CustomerManagement.Web.Resources;

namespace Hydra.CustomerManagement.Web.ResourceMapping
{
    public class CustomerResourceToDomainMapping : Profile
    {
        public CustomerResourceToDomainMapping()
        {
            MapCustomerResourceToSwedenCustomer();
            MapAddressDetailsAttributesToAddressDetails();
            MapCustomerDetailsAttributesToCustomerDetails();
        }

        private void MapCustomerResourceToSwedenCustomer()
        {
            CreateMap<CustomerResource, SwedenPrivateLinesCustomer>()
               .ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.Id))
               .ForMember(dest => dest.Reference, opt => opt.Ignore())
               .ForMember(dest => dest.SourceName, opt => opt.MapFrom(src => src.Attributes.SourceName))
               .ForMember(dest => dest.Version, opt => opt.Ignore())
               .ForMember(dest => dest.Type, opt => opt.UseValue("Customers"))
               .ForMember(dest => dest.InsuranceDefaults, opt => opt.MapFrom(src => src.Attributes.InsuranceDefaults))
               .ForMember(dest => dest.DefaultAddressDetails, opt => opt.MapFrom(src => src.Attributes.DefaultAddressDetails))
               .ForMember(dest => dest.CustomerNames, opt => opt.MapFrom(src => src.Attributes.CustomerNames))
               .ForMember(dest => dest.CustomerDetails, opt => opt.Ignore())
               .ForMember(dest => dest.ContactMotorRegistry, opt => opt.Ignore())
               .ForMember(dest => dest.AdditionalDetails, opt => opt.MapFrom(src => src.Attributes.AdditionalDetails))
               .AfterMap((cr, spc) => Mapper.Map(cr.Attributes.CustomerDetails, spc.CustomerDetails));
        }

        private void MapCustomerDetailsAttributesToCustomerDetails()
        {
            CreateMap<CustomerDetailsAttributes, CustomerDetails>()
               .ForMember(dest => dest.IdentificationNumber, opt => opt.Ignore())
               .ForMember(dest => dest.IsBlacklisted, opt => opt.Ignore())
               .ForMember(dest => dest.DateOfBirth, opt => opt.Ignore())
               .ForMember(dest => dest.Email, opt => opt.MapFrom(src => src.Email))
               .ForMember(dest => dest.MobileNumber, opt => opt.MapFrom(src => src.MobileNumber))
               .ForMember(dest => dest.TelephoneNumber, opt => opt.MapFrom(src => src.TelephoneNumber));
        }

        private void MapAddressDetailsAttributesToAddressDetails()
        {
            CreateMap<AddressDetailsAttributes, AddressDetails>()
               .ForMember(dest => dest.AddressId, opt => opt.MapFrom(src => src.AddressId))
               .ForMember(dest => dest.AddressLineOne, opt => opt.MapFrom(src => src.AddressLineOne))
               .ForMember(dest => dest.AddressType, opt => opt.MapFrom(src => src.AddressType))
               .ForMember(dest => dest.City, opt => opt.MapFrom(src => src.City))
               .ForMember(dest => dest.Country, opt => opt.MapFrom(src => src.Country))
               .ForMember(dest => dest.IsDefault, opt => opt.MapFrom(src => src.IsDefault))
               .ForMember(dest => dest.PostCode, opt => opt.MapFrom(src => string.IsNullOrEmpty(src.PostCode) ? string.Empty : src.PostCode.Replace(" ", "")));
        }
    }
}