﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Hydra.CustomerManagement.Web.Resources
{
    public class ResourceWithLinks
    {
        public ResourceWithLinks()
        {
            Links = new Dictionary<string, string>();
        }

        public IDictionary<string, string> Links { get; set; }
    }
}