﻿using System;
using System.Linq;
using Hydra.Common.CountrySpecific.Sweden;
using Hydra.MotorRegistry.Integration.CountrySpecific.Sweden.Models;

namespace Hydra.CustomerManagement.Web.Resources
{
    public class LicenseResource : ResourceWithLinks
    {
        public LicenseResource(ISwedenNinService swedenNinService, HP04ParsedResponse response)
        {
            AddressLineOne = response.ResponseDetails.PA02.GetFormattedAddressLine();
            City = response.ResponseDetails.PA02.GetFormattedAddressCity();
            PostCode = response.ResponseDetails.PA02.POSTNR;
            var personName = response.ResponseDetails.PA01.GetPersonalName(swedenNinService);
            CustomerName = personName.FullName;
            FirstName = personName.FirstName;
            LastName = personName.LastName;
            IsValidNin = true;
        }

        public LicenseResource(string errorText, bool isValidNin)
        {
            this.SetError(errorText);
            this.IsValidNin = isValidNin;
        }

        public bool IsFailure { get; set; }

        public bool IsValidNin { get; set; }

        public string CustomerName { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string AddressLineOne { get; set; }

        public string PostCode { get; set; }

        public string City { get; set; }

        public string ErrorText { get; set; }

        internal void SetError(string errorText)
        {
            this.ErrorText = errorText;
            this.IsFailure = true;
        }
    }
}