﻿using System;
using System.Linq;
using Hydra.CustomerManagement.Web.Services;

namespace Hydra.CustomerManagement.Web.Resources
{
    public class CreditCheckResultResource : ResourceWithLinks
    {
        public CreditCheckResultResource(CreditCheckResult response)
        {
            IsBlackListed = response.IsBlackListed;
        }

        public CreditCheckResultResource(string errorText)
        {
            this.ErrorText = errorText;
            this.IsFailure = true;
        }

        public bool IsBlackListed { get; private set; }

        public string ErrorText { get; private set; }
        public bool IsFailure { get; private set; }
    }
}