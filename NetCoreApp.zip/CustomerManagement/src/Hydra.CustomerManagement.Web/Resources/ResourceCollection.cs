﻿using System;
using System.Linq;

namespace Hydra.CustomerManagement.Web.Resources
{
    public class ResourceCollection<T> : ResourceWithLinks
    {
        public T[] Data { get; set; }

        public int TotalItems { get; set; }
    }
}