﻿using System;
using JsonApiSerializer.JsonApi;

namespace Hydra.CustomerManagement.Web.Resources
{
    public class CustomerResource
    {
        public string Type { get; } = "customers";
        public Guid Id { get; set; }
        public CustomerResourceAttributes Attributes { get; set; } = new CustomerResourceAttributes();
        public Links Links { get; set; } = new Links();

        public void AddSelfLink(string getActionUrl)
        {
            Links.Add("self", new Link { Href = getActionUrl });
        }
    }

    public class CustomerResourceAttributes
    {
        public string Reference { get; set; }
        public string SourceName { get; set; }
        public int Version { get; set; }
        public CustomerNamesAttributes CustomerNames { get; set; } = new CustomerNamesAttributes();
        public InsuranceDefaultsAttributes InsuranceDefaults { get; set; } = new InsuranceDefaultsAttributes();
        public CustomerDetailsAttributes CustomerDetails { get; set; } = new CustomerDetailsAttributes();
        public AddressDetailsAttributes DefaultAddressDetails { get; set; } = new AddressDetailsAttributes();
        public AdditionalDetailsAttributes AdditionalDetails { get; set; } = new AdditionalDetailsAttributes();
    }

    public class CustomerNamesAttributes
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }

    public class InsuranceDefaultsAttributes
    {
        public string PaymentMethod { get; set; }

        public string RenewalMode { get; set; }
    }

    public sealed class CustomerDetailsAttributes
    {
        public DateTimeOffset? DateOfBirth { get; set; }
        public string Email { get; set; }
        public string IdentificationNumber { get; set; }
        public string MobileNumber { get; set; }
        public string TelephoneNumber { get; set; }
        public bool IsBlacklisted { get; set; }
    }

    public class AdditionalDetailsAttributes
    {
        public string AdditionalInformation { get; set; }
    }

    public class AddressDetailsAttributes
    {
        public Guid AddressId { get; set; }
        public string AddressLineOne { get; set; }
        public string AddressType { get; set; }
        public string City { get; set; }
        public string Country { get; set; }
        public bool IsDefault { get; set; }
        public string PostCode { get; set; }
    }
}