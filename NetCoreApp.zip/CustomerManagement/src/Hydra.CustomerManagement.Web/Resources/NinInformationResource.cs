﻿using System;
using System.Linq;

namespace Hydra.CustomerManagement.Web.Resources
{
    public class NinInformationResource : ResourceWithLinks
    {
        public bool IsValid { get; set; }
        public bool AlreadyExists { get; set; }
        public string LocalisedMessage { get; set; }
        public DateTime? DateOfBirth { get; set; }
        public Guid? CustomerId { get; set; }
    }
}