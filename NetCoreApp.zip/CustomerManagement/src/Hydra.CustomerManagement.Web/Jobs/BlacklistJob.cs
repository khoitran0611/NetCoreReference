﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Hangfire;
using Hangfire.Server;
using Hydra.CustomerManagement.Web.Services;
using Microsoft.Extensions.Logging;

namespace Hydra.CustomerManagement.Web.Jobs
{
    public class BlacklistJobRequest
    {
        public byte[] Data { get; set; }

        public string Delimiter { get; set; }
    }

    public class BlacklistJob
    {
        private const int batchSizeFrequencyToReport = 10000;
        private readonly ILogger<BlacklistJob> logger;
        private readonly IBlacklistingService blacklistingService;
        private readonly ICustomerManagementService customerRepository;
        private readonly INinManagmentService ninManagementService;

        public BlacklistJob(
            ILogger<BlacklistJob> logger,
            ICustomerManagementService customerRepository,
            IBlacklistingService blacklistingService,
            INinManagmentService ninManagementService)
        {
            this.logger = logger;
            this.blacklistingService = blacklistingService;
            this.customerRepository = customerRepository;
            this.ninManagementService = ninManagementService;
        }

        [AutomaticRetry(Attempts = 0)]
        public async Task UpsertBlacklistNins(BlacklistJobRequest blacklistJobRequest, string correleationId, ContextUserDetails contextUserDetails, PerformContext context)
        {
            using (var stream = new MemoryStream())
            {
                stream.Write(blacklistJobRequest.Data, 0, blacklistJobRequest.Data.Length);
                ResetStreamToStart(stream);

                logger.LogInformation($"Processing stream to blacklist with a delimiter {blacklistJobRequest.Delimiter}");
                var result = await blacklistingService.BlacklistBatch(stream, blacklistJobRequest.Delimiter);

                logger.LogInformation("Blacklisting Nin batch result" +
                    $"{nameof(result.NewlyBlacklistedNins)} - {result.NewlyBlacklistedNins.Count}, " +
                    $"{nameof(result.WhitelistedNins)} - {result.WhitelistedNins.Count}, " +
                    $"{nameof(result.AllBlacklistedNinsCount)} - {result.AllBlacklistedNinsCount}");

                var blacklistCustomerTask = UpdateExistingCustomers(result.NewlyBlacklistedNins, contextUserDetails, correleationId, isBlackListed: true);
                var whitelistCustomerTask = UpdateExistingCustomers(result.WhitelistedNins, contextUserDetails, correleationId, isBlackListed: false);

                var results = await Task.WhenAll(blacklistCustomerTask, whitelistCustomerTask);

                logger.LogInformation("Blacklisting Customer result" +
                    $"{nameof(blacklistCustomerTask)} - {results[0].Count}, " +
                    $"{nameof(whitelistCustomerTask)} - {results[1].Count}");

                if (!string.IsNullOrEmpty(context?.BackgroundJob?.Id))
                {
                    await ninManagementService.SaveBlacklistingJobResult(
                        context.BackgroundJob.Id,
                        new BlacklistJobResult
                        {
                            NumberOfCustomersBlacklisted = results[0].Count,
                            NumberOfCustomersWhitelisted = results[1].Count,
                            NumberOfNewlyBlacklistedNins = result.NewlyBlacklistedNins.Count,
                            NumberOfNewlyWhitelistedNins = result.WhitelistedNins.Count,
                            TotalBlacklistedNinsInTheBatch = result.AllBlacklistedNinsCount
                        });
                    logger.LogInformation($"Storing Job result {context.BackgroundJob.Id}");
                };
            }
        }

        private void ResetStreamToStart(Stream stream)
        {
            if (stream.CanSeek)
            {
                stream.Seek(0, SeekOrigin.Begin);
            }
        }

        private async Task<List<string>> UpdateExistingCustomers(List<string> nins, ContextUserDetails contextUserDetails, string correlationId, bool isBlackListed)
        {
            var customersUpdated = new List<string>();
            int ninsProcessed = 0;
            logger.LogInformation($"Nins processing will be reported for every {batchSizeFrequencyToReport}");

            foreach (var nin in nins)
            {
                var customerId = await customerRepository.GetCustomerIdByIdentificationNumberAsync(nin);
                if (customerId != Guid.Empty)
                {
                    var updatedCustomer = await customerRepository.UpdateCustomerAsync(
                        customerId.ToString(),
                        correlationId,
                        contextUserDetails,
                        (customerToUpdate) =>
                        {
                            customerToUpdate.CustomerDetails.IsBlacklisted = isBlackListed;
                            logger.LogInformation($"Found customer {customerId} with nin {nin} and updated {nameof(isBlackListed)} to {isBlackListed}");
                        });
                    customersUpdated.Add(updatedCustomer.Id.ToString());
                }

                if (++ninsProcessed % batchSizeFrequencyToReport == 1)
                {
                    logger.LogInformation($"Processing is at {ninsProcessed} of {nins.Count} Nins.");
                }
            }

            return customersUpdated;
        }
    }
}