﻿using System.ComponentModel.DataAnnotations;

namespace Hydra.CustomerManagement.Web.Attributes
{
    public class DisplayAsFileInputAttribute : ValidationAttribute
    {
        public override bool IsValid(object value)
        {
            return true;
        }
    }
}