﻿using System.ComponentModel.DataAnnotations;

namespace Hydra.CustomerManagement.Web.Attributes
{
    public class DisplayAsReadOnlyAttribute : ValidationAttribute
    {
        public override bool IsValid(object value)
        {
            return true;
        }
    }       
}