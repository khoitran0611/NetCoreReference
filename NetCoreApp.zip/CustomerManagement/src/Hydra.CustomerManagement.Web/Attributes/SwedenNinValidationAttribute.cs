﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Hydra.Common.CountrySpecific.Sweden;
using Hydra.CustomerManagement.Web.I18n;
using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using Microsoft.Extensions.Localization;
using Microsoft.Extensions.Logging;

namespace Hydra.CustomerManagement.Web.Attributes
{
    public class SwedenNinValidationAttribute : ValidationAttribute, IClientModelValidator
    {
        public void AddValidation(ClientModelValidationContext context)
        {
            var errorMessage = ResourceStrings.Validation.NINRequired;
            MergeAttribute(context.Attributes, "data-val-swedenninvalidation", errorMessage);
        }

        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            var logger = (ILogger)validationContext.GetService(typeof(ILogger<SwedenNinValidationAttribute>));

            try
            {
                var swedenNinService = (ISwedenNinService)validationContext.GetService(typeof(ISwedenNinService));
                var stringLocalizer = (IStringLocalizer)validationContext.GetService(typeof(IStringLocalizer));

                string nin = (string)value;
                var result = swedenNinService.Validate(nin);

                if (!result.IsValid)
                {
                    var localisedErrorCode = stringLocalizer.GetString(result.ErrorCode);
                    return new ValidationResult(localisedErrorCode);
                }
            }
            catch (Exception ex)
            {
                logger.LogError(ex, $"There was error when validating {value}.");
                return new ValidationResult(FormatErrorMessage(validationContext.DisplayName));
            }
            return ValidationResult.Success;
        }

        private void MergeAttribute(
            IDictionary<string, string> attributes,
            string key,
            string value)
        {
            if (!attributes.ContainsKey(key))
            {
                attributes.Add(key, value);
            }
        }
    }
}