﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Dawn;
using Hydra.CustomerManagement.Web.Attributes;
using Hydra.CustomerManagement.Web.ResourceMapping;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Hydra.CustomerManagement.Web.Controllers.api
{
    [Authorize(Policy = AuthorisationPolicies.Api)]
    [Route("api/v1/se/nins")]
    public class NinsController : Controller
    {
        private readonly INinInformationResourceMapper ninInformationResourceMapper;
        private readonly ILicenseResourceMapper licenseDetailResourceMapper;
        private readonly ICreditCheckResultResourceMapper creditCheckResultResourceMapper;

        public NinsController(
            INinInformationResourceMapper ninInformationResourceMapper,
            ILicenseResourceMapper licenseDetailResourceMapper,
            ICreditCheckResultResourceMapper creditCheckResultResourceMapper)
        {
            this.ninInformationResourceMapper = ninInformationResourceMapper;
            this.licenseDetailResourceMapper = licenseDetailResourceMapper;
            this.creditCheckResultResourceMapper = creditCheckResultResourceMapper;
        }

        [NoCache]
        [HttpGet("{nin}")]
        public async Task<IActionResult> GetNinInformation(string nin)
        {
            Guard.Argument(nin, nameof(nin)).NotNull().NotWhiteSpace();
            var resource = await ninInformationResourceMapper.Map(nin, RelatedLinks);
            return Ok(resource);
        }

        [NoCache]
        [HttpGet("{nin}/License")]
        public async Task<IActionResult> GetLicense(string nin)
        {
            Guard.Argument(nin, nameof(nin)).NotNull().NotWhiteSpace();

            var contextId = Guid.NewGuid().ToString();
            var resource = await licenseDetailResourceMapper.Map(nin, contextId, GetNinInformationUrl);

            return Ok(resource);
        }

        [NoCache]
        [HttpGet("{nin}/CreditCheckResult")]
        public async Task<IActionResult> GetCreditCheckResult(string nin)
        {
            Guard.Argument(nin, nameof(nin)).NotNull().NotWhiteSpace();
            var resource = await creditCheckResultResourceMapper.Map(nin, GetNinInformationUrl);

            if (resource.IsFailure)
            {
                return UnprocessableEntity(resource.ErrorText);
            }

            return Ok(resource);
        }

        private string GetNinInformationUrl(string nin)
        {
            return Url.Action(nameof(GetNinInformation), new { nin });
        }

        private IDictionary<string, string> RelatedLinks(string nin)
        {
            var links = new Dictionary<string, string>();
            links.Add("license", Url.Action(nameof(GetLicense), new { nin }));
            links.Add("creditCheckResult", Url.Action(nameof(GetCreditCheckResult), new { nin }));
            return links;
        }
    }
}