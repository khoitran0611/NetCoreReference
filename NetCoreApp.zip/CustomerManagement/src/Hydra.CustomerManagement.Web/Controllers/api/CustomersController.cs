﻿using System;
using System.Threading.Tasks;
using AutoMapper;
using Dawn;
using Hydra.CustomerManagement.Web.Domain.SwedenPrivateLines;
using Hydra.CustomerManagement.Web.Resources;
using Hydra.CustomerManagement.Web.Services;
using JsonApiSerializer.JsonApi;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Morcatko.AspNetCore.JsonMergePatch;

namespace Hydra.CustomerManagement.Web.Controllers.api
{
    [Authorize(Policy = AuthorisationPolicies.Api)]
    [Route("api/v1/[controller]")]
    [IgnoreAntiforgeryToken]
    public class CustomersController : Controller
    {
        private readonly IMapper mapper;
        private readonly ICustomerManagementService customerRepository;

        public CustomersController(
            IMapper mapper,
            ICustomerManagementService customerRepository)
        {
            this.mapper = mapper;
            this.customerRepository = customerRepository;
        }

        /// <summary>
        /// Gets Customer resource given customer Id.
        /// </summary>
        /// <param name="customerId">Guid of the customer to get</param>
        /// <returns>Returns a json Api document resource of the customer with attributes such as insuranceDefaults, additionalDetails.</returns>
        /// <response code="200">Returns a json Api document resource of the customer</response>
        [HttpGet]
        [Route("{customerId}")]
        public async Task<IActionResult> Get(Guid customerId)
        {
            Guard.Argument(customerId, nameof(customerId)).NotDefault();

            var customer = await this.customerRepository.GetCustomerByIdAsync(customerId.ToString());
            if (customer == null)
            {
                return NotFound();
            }
            return GetOkCustomerResourceResponse(customerId, customer);
        }

        [HttpPatch]
        [Route("{customerId}")]
        [Consumes(JsonMergePatchDocument.ContentType)]
        public async Task<IActionResult> PatchCustomer(Guid customerId, [FromBody]JsonMergePatchDocument<CustomerResource> customerPatchDocument)
        {
            Guard.Argument(customerId, nameof(customerId)).NotDefault();

            Guard.Argument(customerPatchDocument, nameof(customerPatchDocument)).NotNull("Please check the format.");

            var customer = await this.customerRepository.GetCustomerByIdAsync(customerId.ToString());
            if (customer == null)
            {
                return NotFound();
            }

            var result = await ApplyPatch(customerPatchDocument, customerId);

            return result;
        }

        private async Task<IActionResult> ApplyPatch(JsonMergePatchDocument<CustomerResource> customerPatchDocument, Guid customerId)
        {
            var customerAfterUpdate = await customerRepository.UpdateCustomerAsync(
                customerId.ToString(),
                HttpContext.TraceIdentifier,
                (customerToUpdate) =>
                {
                    var customerResource = mapper.Map<CustomerResource>(customerToUpdate);
                    customerPatchDocument.ApplyTo(customerResource);
                    mapper.Map(customerResource, customerToUpdate);
                });

            return GetOkCustomerResourceResponse(customerId, customerAfterUpdate);
        }

        private IActionResult GetOkCustomerResourceResponse(Guid customerId, SwedenPrivateLinesCustomer customer)
        {
            var customerResource = mapper.Map<SwedenPrivateLinesCustomer, CustomerResource>(customer);
            customerResource.AddSelfLink(Url.Action(nameof(Get), new { customerId }));

            return Ok(new DocumentRoot<CustomerResource> { Data = customerResource });
        }
    }
}