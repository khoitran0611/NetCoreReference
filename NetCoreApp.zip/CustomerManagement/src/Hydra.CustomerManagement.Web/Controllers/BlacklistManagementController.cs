﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Dawn;
using Hangfire;
using Hydra.CustomerManagement.Web.Jobs;
using Hydra.CustomerManagement.Web.Models.SwedenPrivateLines;
using Hydra.CustomerManagement.Web.Services;
using Hydra.GlobalResources.Client;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.StaticFiles;
using Microsoft.Extensions.Localization;

namespace Hydra.CustomerManagement.Web.Controllers
{
    [Authorize]
    public class BlacklistManagementController : Controller
    {
        private readonly string[] acceptedMimeTypes = { @"text/csv", @"text/plain", @"application/vnd.ms-excel" };

        private readonly IStringLocalizer localizer;
        private readonly IBackgroundJobClient backgroundJob;
        private readonly IBlacklistingJobMonitor jobStatusMonitor;
        private readonly INinManagmentService ninManagementService;
        private readonly CurrentUserDetailsService currentUserDetailsService;
        private readonly IGlobalResourcesClient globalResourcesClient;

        public BlacklistManagementController(
            IStringLocalizer localizer,
            IBackgroundJobClient backgroundJob,
            IBlacklistingJobMonitor jobStatusMonitor,
            INinManagmentService ninManagementService,
            CurrentUserDetailsService currentUserDetailsService,
            IGlobalResourcesClient globalResourcesClient)
        {
            this.localizer = localizer;
            this.backgroundJob = backgroundJob;
            this.jobStatusMonitor = jobStatusMonitor;
            this.ninManagementService = ninManagementService;
            this.currentUserDetailsService = currentUserDetailsService;
            this.globalResourcesClient = globalResourcesClient;
        }

        [HttpGet("Customers/SE/PL/Blacklist")]
        public async Task<IActionResult> UpsertSwedenBlacklistNins(bool isEmbedded = false)
        {
            var model = new UpsertSwedenBlacklistNinsViewModel()
            {
                IsEmbedded = isEmbedded,
                ReturnSystemId = HttpContext.Request.Query["returnSystemId"].ToString(),
                ReturnLink = HttpContext.Request.Query["returnLink"].ToString()
            };

            if (!string.IsNullOrEmpty(model.ReturnSystemId))
            {
                var returnLink = HttpContext.Request.Query["returnLink"].ToString();
                model.ReturnLink = await globalResourcesClient.ResolveLink(HttpContext.Request.Query["returnSystemId"].ToString(), returnLink);
            }

            return View("UpsertSwedenBlacklistNinsView", model);
        }

        [Authorize(Policy = "ManagementApi")]
        [HttpPost("Customers/SE/PL/Blacklist")]
        public async Task<IActionResult> UpsertBlacklistNins(UpsertSwedenBlacklistNinsViewModel upsertSwedenBlacklistNins)
        {
            Guard.Argument(upsertSwedenBlacklistNins.Delimiter, nameof(upsertSwedenBlacklistNins.Delimiter)).NotNull();

            if (!ModelState.IsValid)
            {
                return View("UpsertSwedenBlacklistNinsView", upsertSwedenBlacklistNins);
            }

            if (!IsValidFile(upsertSwedenBlacklistNins.BlacklistFile))
            {
                return View("UpsertSwedenBlacklistNinsResultView", new UpsertSwedenBlacklistNinsResultViewModel
                {
                    UpsertStatusText = localizer.GetString("CustomerManagement_BlacklistManagement_UnsupportedFile")
                });
            }

            var blacklistJobRequest = await GetBlacklistJobRequest(upsertSwedenBlacklistNins);
            var contextUserDetails = currentUserDetailsService.GetContextUserDetails();
            var correlationId = HttpContext.TraceIdentifier;

            var jobId = backgroundJob.Enqueue<BlacklistJob>(job => job.UpsertBlacklistNins(blacklistJobRequest, correlationId, contextUserDetails, null));

            return View("UpsertSwedenBlacklistNinsResultView", new UpsertSwedenBlacklistNinsResultViewModel
            {
                UpsertStatusText = localizer.GetString("CustomerManagement_BlacklistManagement_QueuedUpsertOfNins"),
                JobId = jobId,
                IsEmbedded = upsertSwedenBlacklistNins.IsEmbedded,
                ReturnSystemId = upsertSwedenBlacklistNins.ReturnSystemId,
                ReturnLink = upsertSwedenBlacklistNins.ReturnLink
            });
        }

        [HttpGet("Customers/SE/PL/BlacklistJobStatus")]
        public async Task<IActionResult> GetBlacklistJobStatus(string jobId, string returnSystemId, string returnLink, bool isEmbedded)
        {
            Guard.Argument(jobId, nameof(jobId)).NotNull().NotEmpty();

            var jobStatus = jobStatusMonitor.GetCurrentStatus(jobId);

            var result = await GetBlacklistJobResult(jobStatus, jobId, returnSystemId, returnLink, isEmbedded);

            return View("UpsertSwedenBlacklistNinsResultView", result);
        }

        private async Task<BlacklistJobRequest> GetBlacklistJobRequest(UpsertSwedenBlacklistNinsViewModel upsertSwedenBlacklistNins)
        {
            BlacklistJobRequest blacklistJobRequest = new BlacklistJobRequest
            {
                Delimiter = upsertSwedenBlacklistNins.Delimiter
            };

            using (var stream = upsertSwedenBlacklistNins.BlacklistFile.OpenReadStream())
            using (var ms = new System.IO.MemoryStream())
            {
                await stream.CopyToAsync(ms);
                blacklistJobRequest.Data = ms.ToArray();
            }

            return blacklistJobRequest;
        }

        private async Task<UpsertSwedenBlacklistNinsResultViewModel> GetBlacklistJobResult(JobStatus jobStatus, string jobId, string returnSystemId, string returnLink, bool isEmbedded)
        {
            var result = new UpsertSwedenBlacklistNinsResultViewModel
            {
                JobId = jobId,
                IsEmbedded = isEmbedded,
                ReturnSystemId = returnSystemId,
                ReturnLink = returnLink,
                UpsertStatusText = localizer.GetString(
                                        jobStatus == null ? "CustomerManagement_BlacklistManagement_JobDoesNotExist" :
                                        jobStatus.HasFinishedSuccessfully ? "CustomerManagement_BlacklistManagement_SuccessfulUpsertOfNins" :
                                        jobStatus.HasFinishedExecuting ? "CustomerManagement_BlacklistManagement_FailedUpsertOfNins" :
                                        "CustomerManagement_BlacklistManagement_QueuedUpsertOfNins")
            };

            if (jobStatus?.HasFinishedSuccessfully ?? false)
            {
                await PopulateJobResult(jobId, result);
            }

            return result;
        }

        private async Task PopulateJobResult(string jobId, UpsertSwedenBlacklistNinsResultViewModel result)
        {
            var jobResult = await ninManagementService.GetBlacklistingJobResultAsync(jobId);
            if (jobResult != null)
            {
                result.NumberOfCustomersBlacklisted = jobResult.NumberOfCustomersBlacklisted;
                result.NumberOfCustomersWhitelisted = jobResult.NumberOfCustomersWhitelisted;
                result.NumberOfNewlyBlacklistedNins = jobResult.NumberOfNewlyBlacklistedNins;
                result.NumberOfNewlyWhitelistedNins = jobResult.NumberOfNewlyWhitelistedNins;
                result.TotalBlacklistedNinsInTheBatch = jobResult.TotalBlacklistedNinsInTheBatch;
            }
        }

        private bool IsValidFile(IFormFile upsertFile)
        {
            var provider = new FileExtensionContentTypeProvider();

            if (provider.TryGetContentType(upsertFile.FileName, out string contentType))
            {
                return acceptedMimeTypes.Contains(contentType) || (upsertFile.ContentType != null && acceptedMimeTypes.Contains(upsertFile.ContentType));
            }

            return false;
        }
    }
}