﻿using System;
using System.Diagnostics;
using Hydra.CustomerManagement.Web.Models;
using Microsoft.ApplicationInsights;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Mvc;

namespace Hydra.CustomerManagement.Web.Controllers
{
    public class HomeController : Controller
    {
        private readonly TelemetryClient telemetryClient;

        public HomeController(TelemetryClient telemetryClient)
        {
            this.telemetryClient = telemetryClient;
        }
        public IActionResult Index()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            var sessionId = telemetryClient.Context.Session.Id;
            var exceptionHandlerPathFeature = HttpContext.Features.Get<IExceptionHandlerPathFeature>();
            
            return View(new ErrorViewModel
            {
                RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier,
                ApplicationInsightsId = sessionId,
                Error = exceptionHandlerPathFeature.Error,
                Path = exceptionHandlerPathFeature.Path,
                OccurredAt = DateTimeOffset.Now
            });
        }
    }
}