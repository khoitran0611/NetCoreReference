﻿using Hydra.CustomerManagement.Web.Exceptions;
using Hydra.CustomerManagement.Web.I18n;
using Hydra.CustomerManagement.Web.Models.SwedenPrivateLines;
using Hydra.CustomerManagement.Web.Services;
using Hydra.CustomerManagement.Web.ViewModelFactories;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Localization;
using System;
using System.Threading.Tasks;

namespace Hydra.CustomerManagement.Web.Controllers
{
    [Authorize]
    public class CustomersController : Controller
    {
        private readonly IStringLocalizer localizer;
        private readonly ICustomerManagementService customerRepository;
        private readonly CustomerViewModelFactory viewModelFactory;
        private readonly INinManagmentService ninManagementService;

        public CustomersController(
            IStringLocalizer localizer,
            ICustomerManagementService customerRepository,
            CustomerViewModelFactory viewModelFactory,
            INinManagmentService ninManagementService)
        {
            this.localizer = localizer;
            this.customerRepository = customerRepository;
            this.viewModelFactory = viewModelFactory;
            this.ninManagementService = ninManagementService;
        }

        [HttpPost("Customers/SE/PL/Create")]
        public async Task<IActionResult> Create(SwedenPrivateLinesCustomerViewModel viewModel)
        {
            if (!ModelState.IsValid)
            {
                viewModelFactory.FillNonPostedModelData(viewModel, ModelState);
                return View("SwedenPrivateLinesCustomerView", viewModel);
            }

            var customer = viewModelFactory.GetCustomerFromViewModel(viewModel);
            try
            {
                customer.CustomerDetails.IsBlacklisted = (await ninManagementService.GetCreditCheckResultAsync(customer.CustomerDetails.IdentificationNumber)).IsBlackListed;
                await this.customerRepository.CreateCustomerAsync(customer, viewModel.IsIdentificationNumberUnique, HttpContext.TraceIdentifier);
            }
            catch (CustomerDuplicatedNinException)
            {
                ModelState.AddModelError(
                    "CustomerDetails.IdentificationNumber",
                    ResourceStrings.Validation.Duplicate_Nin(localizer, customer.CustomerDetails.IdentificationNumber));
                viewModelFactory.FillNonPostedModelData(viewModel, ModelState);
                return View("SwedenPrivateLinesCustomerView", viewModel);
            }

            if (!string.IsNullOrEmpty(viewModel.ReturnSuccessLink))
            {
                return RedirectToReturnUrl(viewModel);
            }

            return await SwedenPrivateLinesCustomerEdit(viewModel.CustomerId, viewModel.IsEmbedded);
        }

        [HttpPost("Customers/SE/PL/Edit/{customerId}")]
        public async Task<IActionResult> Edit(SwedenPrivateLinesCustomerViewModel viewModel, Guid customerId)
        {
            if (!ModelState.IsValid)
            {
                viewModelFactory.FillNonPostedModelData(viewModel, ModelState);
                return View("SwedenPrivateLinesCustomerView", viewModel);
            }

            if (viewModel.CustomerId != customerId)
            {
                throw new CustomerConflictException("Trying to edit customer that does not match");
            }

            await customerRepository.UpdateCustomerAsync(
                customerId.ToString(),
                HttpContext.TraceIdentifier,
                (customerToUpdate) =>
                {
                    viewModelFactory.UpdateCustomerFromViewModel(viewModel, customerToUpdate);
                });

            if (!string.IsNullOrEmpty(viewModel.ReturnSuccessLink))
            {
                return RedirectToReturnUrl(viewModel);
            }
            return await SwedenPrivateLinesCustomerEdit(customerId, viewModel.IsEmbedded);
        }

        [HttpGet("Customers/SE/PL/Create")]
        public async Task<IActionResult> SwedenPrivateLinesCustomerCreate(string identificationNumber, [FromQuery]string[] linkParameters, bool isEmbedded = false, bool usePostMessage = false)
        {
            var model = await viewModelFactory.GetSwedenPrivateLinesCreateCustomerViewModel(identificationNumber, isEmbedded, usePostMessage, linkParameters, HttpContext);
            return View("SwedenPrivateLinesCustomerView", model);
        }

        [HttpGet("Customers/SE/PL/Edit/{id}")]
        public async Task<IActionResult> SwedenPrivateLinesCustomerEdit(Guid id, bool isEmbedded)
        {
            var customer = await customerRepository.GetCustomerByIdAsync(id.ToString());
            var model = await viewModelFactory.GetSwedenPrivateLinesCustomerViewModelFromCustomer(customer, isEmbedded, HttpContext);
            return View("SwedenPrivateLinesCustomerView", model);
        }

        [HttpGet("Customers/VN/PL/Create")]
        public IActionResult VietnamPrivateLinesCustomerCreate(bool isEmbedded = false)
        {
            var model = viewModelFactory.GetVietnamPrivateLinesCustomerViewModel(isEmbedded);
            return View("VietnamPrivateLinesCustomerView", model);
        }

        private IActionResult RedirectToReturnUrl(SwedenPrivateLinesCustomerViewModel viewModel)
        {
            if (viewModel.IsEmbedded)
            {
                if (viewModel.UsePostMessage)
                {
                    return View("PostMessage", viewModel);
                }
                else
                {
                    return View("RedirectInIFrame", viewModel);
                }
            }
            else
            {
                return Redirect(viewModel.ReturnSuccessLink);
            }
        }
    }
}