﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.PlatformAbstractions;

namespace Hydra.CustomerManagement.Web.Controllers
{
    [AllowAnonymous]
    [Route("[controller]")]
    public class AboutController : Controller
    {
        [HttpGet]
        public IActionResult Index()
        {
            return Ok(new
            {
                Version = PlatformServices.Default.Application.ApplicationVersion,
                StoreStatus = "OK"
            });
        }
    }
}