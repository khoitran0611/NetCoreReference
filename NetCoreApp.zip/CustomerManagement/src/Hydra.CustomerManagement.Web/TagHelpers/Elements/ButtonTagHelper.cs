﻿using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Razor.TagHelpers;
using Microsoft.Extensions.Localization;

namespace Hydra.CustomerManagement.Web.TagHelpers.Elements
{
    [HtmlTargetElement("button")]
    public class ButtonTagHelper : TagHelper
    {
        private readonly IStringLocalizer localizer;

        public ButtonTagHelper(IStringLocalizer localizer)
        {
            this.localizer = localizer;
        }

        public override async Task ProcessAsync(TagHelperContext context, TagHelperOutput output)
        {
            var content = await output.GetChildContentAsync();
            var localizedContent = localizer.GetString(content.GetContent());
            output.Content.SetContent(localizedContent);
        }
    }
}