﻿using Microsoft.AspNetCore.Razor.TagHelpers;

namespace Hydra.CustomerManagement.Web.TagHelpers
{
    public class RowTagHelper : TagHelper
    {
        public override void Process(TagHelperContext context, TagHelperOutput output)
        {
            output.TagName = "div";
            output.Attributes.Add("class", "row");
        }
    }
}