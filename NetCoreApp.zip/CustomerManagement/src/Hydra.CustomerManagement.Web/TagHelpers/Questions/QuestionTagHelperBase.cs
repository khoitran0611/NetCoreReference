﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using Hydra.CustomerManagement.Web.Attributes;
using Microsoft.AspNetCore.Html;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using Microsoft.AspNetCore.Razor.TagHelpers;
using Microsoft.Extensions.Localization;

namespace Hydra.CustomerManagement.Web.TagHelpers.Questions
{
    public abstract class QuestionTagHelperBase : TagHelper
    {
        private readonly IStringLocalizer localizer;

        protected QuestionTagHelperBase(
            IStringLocalizer localizer,
            IHtmlGenerator generator)
        {
            this.localizer = localizer;
            Generator = generator;
        }

        [ViewContext]
        public ViewContext ViewContext { get; set; }

        [HtmlAttributeName("asp-for")]
        public ModelExpression AspFor { get; set; }

        [HtmlAttributeName("displayReadonly")]
        public bool DisplayReadonly { get; set; }

        public string Label { get; set; }
        public string Placeholder { get; set; }
        public int Size { get; set; }

        protected IHtmlGenerator Generator { get; set; }

        public IHtmlContent RenderValidation()
        {
            var control = Generator.GenerateValidationMessage(ViewContext, AspFor.ModelExplorer, AspFor.Name, null, ViewContext.ValidationMessageElement, null);
            control.AddCssClass("text-danger");
            return control;
        }

        public IHtmlContent RenderLabel()
        {
            var localizedLabel = localizer.GetString(Label);
            var control = Generator.GenerateLabel(ViewContext, AspFor.ModelExplorer, AspFor.Name, localizedLabel, htmlAttributes: null);
            if (AspFor.Metadata.IsRequired)
            {
                control.AddCssClass("required");
            }
            return control;
        }

        public IHtmlContent RenderList(SelectList list)
        {
            var items = (List<SelectListItem>)list.Items;
            var control = Generator.GenerateSelect(ViewContext, AspFor.ModelExplorer, null, AspFor.Name, items, false, null);
            control.AddCssClass("form-control");
            return control;
        }

        public IHtmlContent RenderTextArea(int rows)
        {
            var localizePlaceholder = localizer.GetString(Placeholder);
            var control = Generator.GenerateTextArea(ViewContext, AspFor.ModelExplorer, AspFor.Name, rows, 0, new { placeholder = localizePlaceholder });
            control.AddCssClass("form-control");
            control.Attributes.Add("style", "resize: none");
            return control;
        }

        public IHtmlContent RenderTextBox(string formattedValue = null)
        {
            var localizePlaceholder = localizer.GetString(Placeholder);
            var control = Generator.GenerateTextBox(ViewContext, AspFor.ModelExplorer, AspFor.Name, AspFor.Model, formattedValue, new { placeholder = localizePlaceholder });
            control.AddCssClass("form-control");
            AddCustomMarkupFromModelAttributes(control);
            return control;
        }

        public IHtmlContent RenderDatePicker()
        {
            var value = AspFor.Model as DateTimeOffset?;
            var formattedValue = value?.Date.ToString("s", CultureInfo.InvariantCulture);

            var id = $"datepicker{AspFor.Name}";

            var iconBuilder = new TagBuilder("span");
            iconBuilder.AddCssClass("glyphicon glyphicon-calendar");

            var iconWrapperBuilder = new TagBuilder("span");
            iconWrapperBuilder.AddCssClass("input-group-addon");
            iconWrapperBuilder.InnerHtml.AppendHtml(iconBuilder);

            var tagBuilder = new TagBuilder("div");
            tagBuilder.GenerateId(id, string.Empty);
            tagBuilder.AddCssClass("input-group date");

            tagBuilder.InnerHtml.AppendHtml(RenderTextBox(formattedValue));
            tagBuilder.InnerHtml.AppendHtml(iconWrapperBuilder);

            return tagBuilder;
        }

        private void AddCustomMarkupFromModelAttributes(TagBuilder control)
        {
            var metadata = AspFor.Metadata.ValidatorMetadata;

            if (metadata.OfType<DisplayAsReadOnlyAttribute>().Any() || DisplayReadonly)
            {
                control.Attributes.Add("readonly", "readonly");
            }
            if (metadata.OfType<SwedenNinValidationAttribute>().Any())
            {
                control.Attributes.Add("data-inputmask", "'mask': '[99]999999-9999', 'rightAlign': true, 'removeMaskOnSubmit': true");
            }
            if (metadata.OfType<SwedenPostcodeValidationAttribute>().Any())
            {
                control.Attributes.Add("data-inputmask", "'mask': '999 99', 'removeMaskOnSubmit': true");
            }
            if (metadata.OfType<DisplayAsFileInputAttribute>().Any())
            {
                if (control.Attributes.ContainsKey("type"))
                {
                    control.Attributes["type"] = "file";
                }
                else
                {
                    control.Attributes.Add("type", "file");
                }
            }
        }
    }
}