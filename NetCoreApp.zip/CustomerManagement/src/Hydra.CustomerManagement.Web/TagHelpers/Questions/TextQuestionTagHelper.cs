﻿using Microsoft.AspNetCore.Mvc.ViewFeatures;
using Microsoft.AspNetCore.Razor.TagHelpers;
using Microsoft.Extensions.Localization;

namespace Hydra.CustomerManagement.Web.TagHelpers.Questions
{
    public class TextQuestionTagHelper : QuestionTagHelperBase
    {
        public TextQuestionTagHelper(
            IStringLocalizer localizer,
            IHtmlGenerator generator)
            : base(localizer, generator)
        {
        }

        public override void Process(TagHelperContext context, TagHelperOutput output)
        {
            output.TagName = "div";
            output.Attributes.Add("class", $"col-sm-{Size}");

            output.Content.AppendHtml(@"<div class=""form-group"">");
            output.Content.AppendHtml(RenderLabel());
            output.Content.AppendHtml(RenderTextBox());
            output.Content.AppendHtml(RenderValidation());
            output.Content.AppendHtml("</div>");
        }
    }
}