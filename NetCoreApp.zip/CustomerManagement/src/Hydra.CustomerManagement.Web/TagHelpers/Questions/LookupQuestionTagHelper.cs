﻿using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using Microsoft.AspNetCore.Razor.TagHelpers;
using Microsoft.Extensions.Localization;

namespace Hydra.CustomerManagement.Web.TagHelpers.Questions
{
    public class LookupQuestionTagHelper : QuestionTagHelperBase
    {
        public LookupQuestionTagHelper(
            IStringLocalizer localizer,
            IHtmlGenerator generator)
            : base(localizer, generator)
        {
        }

        public SelectList AspItems { get; set; }

        public override void Process(TagHelperContext context, TagHelperOutput output)
        {
            output.TagName = "div";
            output.Attributes.Add("class", $"col-sm-{Size}");

            output.Content.AppendHtml(@"<div class=""form-group"">");
            output.Content.AppendHtml(RenderLabel());
            output.Content.AppendHtml(RenderList(AspItems));
            output.Content.AppendHtml(RenderValidation());
            output.Content.AppendHtml("</div>");
        }
    }
}