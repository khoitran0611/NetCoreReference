﻿using System.Threading.Tasks;
using Microsoft.AspNetCore.Razor.TagHelpers;

namespace Hydra.CustomerManagement.Web.TagHelpers.Interactions
{
    public class InteractionsTagHelper : TagHelper
    {
        public override async Task ProcessAsync(TagHelperContext context, TagHelperOutput output)
        {
            await output.GetChildContentAsync();
            output.TagName = "interactions";
        }
    }
}