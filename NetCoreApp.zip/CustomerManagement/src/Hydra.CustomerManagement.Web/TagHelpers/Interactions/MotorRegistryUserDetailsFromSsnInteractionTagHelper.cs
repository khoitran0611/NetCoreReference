﻿using Microsoft.AspNetCore.Mvc.ViewFeatures;
using Microsoft.AspNetCore.Razor.TagHelpers;

namespace Hydra.CustomerManagement.Web.TagHelpers.Interactions
{
    [HtmlTargetElement("motorregistry-userdetails-from-ssn-interaction", ParentTag = "interactions")]
    public class MotorRegistryUserDetailsFromSsnInteractionTagHelper : TagHelper
    {
        public ModelExpression ContactRegistry { get; set; }
        public ModelExpression Ssn { get; set; }
        public ModelExpression FirstName { get; set; }
        public ModelExpression LastName { get; set; }

        public ModelExpression Address { get; set; }
        public ModelExpression PostCode { get; set; }
        public ModelExpression City { get; set; }

        public override void Process(TagHelperContext context, TagHelperOutput output)
        {
            output.TagName = "motorregistry-userdetails-from-ssn-interaction";
            output.Attributes.Add("contact-registry", ContactRegistry.Name);
            output.Attributes.Add("ssn", Ssn.Name);
            output.Attributes.Add("first-name", FirstName.Name);
            output.Attributes.Add("last-name", LastName.Name);
            output.Attributes.Add("address", Address.Name);
            output.Attributes.Add("post-code", PostCode.Name);
            output.Attributes.Add("city", City.Name);
        }
    }
}