﻿using Microsoft.AspNetCore.Mvc.ViewFeatures;
using Microsoft.AspNetCore.Razor.TagHelpers;

namespace Hydra.CustomerManagement.Web.TagHelpers.Interactions
{
    [HtmlTargetElement("ssn-and-dateofbirth-interaction", ParentTag = "interactions")]
    public class SsnAndDateofbirthInteractionTagHelper : TagHelper
    {
        public ModelExpression Ssn { get; set; }
        public ModelExpression DateOfBirth { get; set; }

        public override void Process(TagHelperContext context, TagHelperOutput output)
        {
            output.TagName = "ssn-and-dateofbirth-interaction";
            output.Attributes.Add("ssn", Ssn.Name);
            output.Attributes.Add("date-of-birth", DateOfBirth.Name);
        }
    }
}