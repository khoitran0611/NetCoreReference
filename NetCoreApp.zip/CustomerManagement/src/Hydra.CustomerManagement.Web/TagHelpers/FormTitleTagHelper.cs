﻿using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Razor.TagHelpers;
using Microsoft.Extensions.Localization;

namespace Hydra.CustomerManagement.Web.TagHelpers
{
    public class FormTitleTagHelper : TagHelper
    {
        private readonly IStringLocalizer localizer;

        public FormTitleTagHelper(IStringLocalizer localizer)
        {
            this.localizer = localizer;
        }

        public override async Task ProcessAsync(TagHelperContext context, TagHelperOutput output)
        {
            var content = await output.GetChildContentAsync();
            var localizedContent = localizer.GetString(content.GetContent());
            output.Content.SetContent(localizedContent);

            output.TagName = "div";
            output.Attributes.Add("class", "page-header");
            output.PreContent.AppendHtml("<h3>");
            output.PostContent.AppendHtml("</h3>");
        }
    }
}