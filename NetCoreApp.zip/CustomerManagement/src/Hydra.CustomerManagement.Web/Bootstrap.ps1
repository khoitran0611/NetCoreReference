$externalBootstrapScript = "c:\bootstrap\customer-management-startup.ps1"
if(Test-Path $externalBootstrapScript)
{
	Write-Output "Executing external bootstrap '$externalBootstrapScript'..."
	Invoke-Expression $externalBootstrapScript
	Write-Output 'Finished external bootstrap script.'
}

.\Hydra.CustomerManagement.Web.exe