﻿using System;
using System.Linq;
using Microsoft.Extensions.Localization;

namespace Hydra.CustomerManagement.Web.I18n
{
    public static class ResourceStrings
    {
        public static void Initialise(IStringLocalizer localizer)
        {
            Validation.DateOfBirthRequired = localizer.GetString("CustomerManagement_Validation_DateOfBirth_Required");
            Validation.EmailRequired = localizer.GetString("CustomerManagement_Validation_Email_Required");
            Validation.NINRequired = localizer.GetString("CustomerManagement_Validation_NIN_Required");
            Validation.MobileNumberRequired = localizer.GetString("CustomerManagement_Validation_MobileNumber_Required");
            Validation.FirstNameRequired = localizer.GetString("CustomerManagement_Validation_FirstName_Required");
            Validation.LastNameRequired = localizer.GetString("CustomerManagement_Validation_LastName_Required");
            Validation.AddressOneRequired = localizer.GetString("CustomerManagement_Validation_AddressOne_Required");
            Validation.CityRequired = localizer.GetString("CustomerManagement_Validation_City_Required");
            Validation.PostCodeRequired = localizer.GetString("CustomerManagement_Validation_PostCode_Required");
            Validation.MotorRegistryRequired = localizer.GetString("CustomerManagement_Validation_MotorRegistry_Required");

            PaymentMethods.AnnualPBS = localizer.GetString("CustomerManagement_PaymentMethod_AnnualPBS");
            PaymentMethods.MonthlyPBS = localizer.GetString("CustomerManagement_PaymentMethod_MonthlyPBS");
            PaymentMethods.AnnualGiro = localizer.GetString("CustomerManagement_PaymentMethod_AnnualGiro");
            PaymentMethods.MonthlyGiro = localizer.GetString("CustomerManagement_PaymentMethod_MonthlyGiro");
            DisplayOptions.Yes = localizer.GetString("YesString");
            DisplayOptions.No = localizer.GetString("NoString");
        }

        // Static properties are required for use with the annotation property for ErrorMessageResourceName
        public static class Validation
        {
            public static string DateOfBirthRequired { get; set; }
            public static string EmailRequired { get; set; }
            public static string NINRequired { get; set; }
            public static string MobileNumberRequired { get; set; }
            public static string FirstNameRequired { get; set; }
            public static string LastNameRequired { get; set; }
            public static string AddressOneRequired { get; set; }
            public static string CityRequired { get; set; }
            public static string PostCodeRequired { get; set; }
            public static string MotorRegistryRequired { get; set; }

            public static string Duplicate_Customer(IStringLocalizer localizer, object customerId)
            {
                return localizer.GetString("CustomerManagement_Duplicate_Customer", customerId);
            }

            public static string Duplicate_Nin(IStringLocalizer localizer, string identificationNumber)
            {
                return localizer.GetString("CustomerManagement_Duplicate_Nin", identificationNumber);
            }
        }

        public static class PaymentMethods
        {
            public static string AnnualPBS { get; set; }

            public static string MonthlyPBS { get; set; }
            public static string AnnualGiro { get; set; }
            public static string MonthlyGiro { get; set; }
        }

        public static class DisplayOptions
        {
            public static string Yes { get; set; }

            public static string No { get; set; }
        }
    }
}