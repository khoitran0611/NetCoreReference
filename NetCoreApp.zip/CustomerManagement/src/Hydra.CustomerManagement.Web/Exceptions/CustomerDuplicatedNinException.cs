﻿using System;
using System.Runtime.Serialization;

namespace Hydra.CustomerManagement.Web.Exceptions
{
    [Serializable]
    public class CustomerDuplicatedNinException : Exception
    {
        public CustomerDuplicatedNinException(string message) : base(message)
        {
        }

        protected CustomerDuplicatedNinException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }

        public Guid CustomerId { get; set; }
        public string IdentificationNumber { get; set; }
    }
}