﻿using System;
using System.Runtime.Serialization;

namespace Hydra.CustomerManagement.Web.Exceptions
{
    [Serializable]
    public class CustomerConflictException : Exception
    {
        public CustomerConflictException(string message) : base(message)
        {
        }

        protected CustomerConflictException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}
