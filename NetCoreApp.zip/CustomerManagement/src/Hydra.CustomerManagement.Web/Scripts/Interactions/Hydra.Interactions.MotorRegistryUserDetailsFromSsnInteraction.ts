﻿module Hydra.Interactions {
	export class MotorRegistryInteractionElements {
		public contactRegistryElement: JQuery;
		public ssnElement: JQuery;
		public firstNameElement: JQuery;
		public lastNameElement: JQuery;
		public addressElement: JQuery;
		public postCodeElement: JQuery;
		public cityElement: JQuery;

		constructor(
			contactRegistry: string,
			ssn: string,
			firstName: string,
			lastName: string,
			address: string,
			postCode: string,
			city: string) {
			if (this.hasRequiredElements([contactRegistry, ssn, firstName, lastName, address, postCode, city])) {
				this.contactRegistryElement = this.getElementByName(contactRegistry);
				this.ssnElement = this.getElementByName(ssn);
				this.firstNameElement = this.getElementByName(firstName);
				this.lastNameElement = this.getElementByName(lastName);
				this.addressElement = this.getElementByName(address);
				this.postCodeElement = this.getElementByName(postCode);
				this.cityElement = this.getElementByName(city);
			} else {
				throw "Not all elements needed for interaction exist";
			}
		}

		private hasRequiredElements(requiredElementNames: string[]): boolean {
			return requiredElementNames.every((name) => this.elementExistsByName(name));
		}

		private elementExistsByName(name: string): boolean {
			return this.getElementByName(name).length === 1;
		}

		private getElementByName(name: string): JQuery {
			return $(`[name='${name}']`);
		}
	}
	export class MotorRegistryUserDetailsFromSsnInteraction {
		constructor(public interactionElements: MotorRegistryInteractionElements, public ninServiceManager: ninManager) {
			this.bindInteraction();
		}
		private bindInteraction(): void {
			var self = this;

			this.interactionElements.contactRegistryElement.focusout(function () {
				self.RepopulateNinBasedFields(self.interactionElements.contactRegistryElement, self.interactionElements);
			});

			this.interactionElements.ssnElement.focusout(function () {
				self.RepopulateNinBasedFields(self.interactionElements.ssnElement, self.interactionElements);
            });

            if (this.interactionElements.ssnElement.val()) {
                self.RepopulateNinBasedFields(self.interactionElements.ssnElement, self.interactionElements);
            }
		}

		private clearWarning(): void {
			$("#motorregistry_nin_error").remove();
		}

		private addWarning(sourceElement: JQuery, errorText: string): void {
			sourceElement.after("<div id='motorregistry_nin_error' class='alert alert-warning' role='alert'>" + errorText + "</div>");
		}

		private clearResults(interactionElements: MotorRegistryInteractionElements): void {
			interactionElements.addressElement.val('');
			interactionElements.cityElement.val('');
			interactionElements.postCodeElement.val('');

			interactionElements.firstNameElement.val('');
			interactionElements.lastNameElement.val('');
		}

		private setupMotorRegistryFields(interactionElements: MotorRegistryInteractionElements, result: ILicenseResult): void {
			interactionElements.addressElement.val(result.addressLineOne);
			interactionElements.cityElement.val(result.city);
			interactionElements.postCodeElement.val(result.postCode);

			interactionElements.firstNameElement.val(result.firstName);
			interactionElements.lastNameElement.val(result.lastName);
		}

		private lookupDetailsFromRegistry(interactionElements: MotorRegistryInteractionElements): boolean {
			let lookupInRegistry: boolean = false;
			if (this.interactionElements.ssnElement.val() &&
				this.interactionElements.contactRegistryElement.val() === "Yes") {
				lookupInRegistry = true;
			}

			return lookupInRegistry;
		}

		private RepopulateNinBasedFields(sourceElement: JQuery, interactionElements: MotorRegistryInteractionElements): void {
			let self: MotorRegistryUserDetailsFromSsnInteraction = this;
			self.clearWarning();
			if (self.lookupDetailsFromRegistry(interactionElements)) {
				let ssnValue: string = self.interactionElements.ssnElement.val() as string;
				if (ssnValue) {
					self.ninServiceManager
						.fetchLicenseDetails(ssnValue)
						.then(result => {
							if (result.isFailure === true) {
								if (result.isValidNin === true) {
									// Clear values and setup MR related warning message only if the nin is valid.
									self.clearResults(interactionElements);
									self.addWarning(sourceElement, result.errorText);
								}
							} else {
								// Setup values
								self.setupMotorRegistryFields(interactionElements, result);
							}
						})
						.catch(() => { self.addWarning(sourceElement, "Could not connect to server for nin lookup") });
				}
			}
		}
	}
}