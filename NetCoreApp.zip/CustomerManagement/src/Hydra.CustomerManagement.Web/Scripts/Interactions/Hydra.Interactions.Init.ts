﻿module Hydra.Interactions {
	export function Init() {
		AddValidation();
		AddNinBasedInteractions();
	}

	function AddNinBasedInteractions() {
		let ninServiceManager: ninManager = new ninManager();
		AddSsnAndDateOfBirthInteraction(ninServiceManager);
		AddMotorRegistryUserDetailsFromSsnInteraction(ninServiceManager);
	}

	function AddSsnAndDateOfBirthInteraction(ninServiceManager: ninManager) {
		let $interactions = $('interactions > ssn-and-dateofbirth-interaction');
		if ($interactions) {
			if ($interactions.length !== 1) {
				throw "There are more than 1 SSN and Date of birth interaction";
			}
			let $interaction = $interactions.first();
			let ssn = $interaction.attr('ssn');
			let dateOfBirth = $interaction.attr('date-of-birth');
			new SsnAndDateOfBirthInteraction(ssn, dateOfBirth, ninServiceManager);
		}
	}
	function AddMotorRegistryUserDetailsFromSsnInteraction(ninServiceManager: ninManager) {
		let $interactions = $('interactions > motorregistry-userdetails-from-ssn-interaction');
		if ($interactions) {
			if ($interactions.length !== 1) {
				throw "There are more than 1 MotorRegistry UserDetails Retrival interactions";
			}
			let $interaction = $interactions.first();
			let ssn = $interaction.attr('ssn');
			let dateOfBirth = $interaction.attr('date-of-birth');
			let registryElements: MotorRegistryInteractionElements = new MotorRegistryInteractionElements(
				$interaction.attr('contact-registry'),
				$interaction.attr('ssn'),
				$interaction.attr('first-name'),
				$interaction.attr('last-name'),
				$interaction.attr('address'),
				$interaction.attr('post-code'),
				$interaction.attr('city'))

            new MotorRegistryUserDetailsFromSsnInteraction(registryElements, ninServiceManager);
		}
	}
}