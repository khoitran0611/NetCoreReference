﻿module Hydra.Interactions {
	export class ninDetailMapping {
		ninId: string;
		basicInformation: INinInformationResult;
		licenseInformation: ILicenseResult;

		hasBasicInformation(): boolean {
			return this.basicInformation !== null;
		}

		hasLicenseInformation(): boolean {
			return this.licenseInformation !== null;
		}

		constructor(nin: string) {
			this.ninId = nin;
			this.basicInformation = null;
			this.licenseInformation = null;
		}
	}

	export class ninManager {
		ninDetailMappings: ninDetailMapping[];
		constructor() {
			this.ninDetailMappings = [];
		}

		public async fetchBasicNinDetailsAsync(ssn: string): Promise<INinInformationResult> {
			let details = this.getOrCreateNinFromMappings(ssn);
			if (details.hasBasicInformation()) {
				return details.basicInformation;
			}

			details.basicInformation = await fetchNin(`/api/v1/se/nins/${ssn}`);
			return details.basicInformation;
		}

		public async fetchLicenseDetails(ssn: string): Promise<ILicenseResult> {
			let details = this.getOrCreateNinFromMappings(ssn);
			if (details.hasLicenseInformation()) {
				return details.licenseInformation;
			}

			details.basicInformation = await this.fetchBasicNinDetailsAsync(ssn);
			if (details.hasBasicInformation() && details.basicInformation.isValid === false) {
				details.licenseInformation = inValidNinLicense;
				return inValidNinLicense;
			}

			details.licenseInformation = await fetchLicense(this.getLicenseDetailsUrl(details.basicInformation));
			return details.licenseInformation;
		}

		getLicenseDetailsUrl(ninInformation: INinInformationResult): string {
			if (ninInformation.links != null) {
				return ninInformation.links.license;
			}

			return null;
		}

		getOrCreateNinFromMappings(nin: string): ninDetailMapping {
			for (var mapping of this.ninDetailMappings) {
				if (mapping.ninId === nin) {
					return mapping;
				}
			}
			let newMember = new ninDetailMapping(nin);
			var length = this.ninDetailMappings.push(newMember);
			return this.ninDetailMappings[length - 1];
		}
	}

	const fetchNin = (getUrl: string) => new Promise<INinInformationResult>((resolve, reject) => {
		$.ajax({
			cache: false,
			dataType: 'json',
			url: getUrl
		}).done(function (result: INinInformationResult) {
			resolve(result);
		}).fail(function () {
			reject();
		})
	});

	const fetchLicense = (getUrl: string) => new Promise<ILicenseResult>((resolve, reject) => {
		$.ajax({
			cache: false,
			dataType: 'json',
			url: getUrl
		}).done(function (result: ILicenseResult) {
			resolve(result);
		}).fail(function () {
			reject();
		})
	});

	export interface INinInformationResult {
		isValid: boolean;
		alreadyExists: boolean;
		dateOfBirth: string;
		localisedMessage: string;
		customerId: string;
		links: INinInformationLinks;
	}

	export interface INinInformationLinks {
		license: string;
	}

	export interface ILicenseDetailsLinks {
		ninInformation: string;
	}

	const inValidNinLicense: ILicenseResult = {
		isFailure: true,
		isValidNin: false,
		customerName: null,
		firstName: null,
		lastName: null,
		addressLineOne: null,
		postCode: null,
		city: null,
		errorText: null,
		links: null
	}

	export interface ILicenseResult {
		isFailure: boolean;
		isValidNin: boolean;
		customerName: string;
		firstName: string;
		lastName: string;
		addressLineOne: string;
		postCode: string;
		city: string;
		errorText: string;
		links: ILicenseDetailsLinks;
	}
}