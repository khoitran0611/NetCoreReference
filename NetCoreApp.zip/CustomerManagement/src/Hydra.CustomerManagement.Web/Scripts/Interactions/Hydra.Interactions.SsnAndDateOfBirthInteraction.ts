﻿module Hydra.Interactions {
	export class SsnAndDateOfBirthInteraction {
		constructor(public ssn: string, public dateOfBirth: string, public ninServiceManager: ninManager) {
			if (this.hasRequiredElements([ssn, dateOfBirth])) {
				this.bindInteraction();
			} else {
				throw "Not all elements needed for interaction exist";
			}
		}
		private bindInteraction(): void {
			var self = this;
			let $ssn = this.getElementByName(this.ssn);
			let validationSsn = new Validation($ssn);

			let $dateOfBirth = this.getElementByName(this.dateOfBirth);
			let validationDateOfBirth = new Validation($dateOfBirth);

			let isReadOnly = $ssn.prop('readonly') || $ssn.attr('readonly');

			if (!isReadOnly) {
                $ssn.focusout(() => self.update($ssn, self.formatSwedishDate, validationSsn, validationDateOfBirth));

                if ($ssn.val()) {
                    self.update($ssn, self.formatSwedishDate, validationSsn, validationDateOfBirth);
                }
			}
        }

        private update($ssn: JQuery<HTMLElement>, scopedFormatSwedishDate: (date: string) => string, validationSsn: Validation, validationDateOfBirth: Validation) {
            if ($ssn.val()) {
                let ssnValue: string = $ssn.val() as string;
                this.ninServiceManager
                    .fetchBasicNinDetailsAsync(ssnValue)
                    .then(result => {
                        if (result.isValid === true
                            && result.alreadyExists === false
                            && result.dateOfBirth !== null) {
                            let formattedDateOfBirth = scopedFormatSwedishDate(result.dateOfBirth);
                            validationSsn.clearErrors();
                            validationDateOfBirth.setValueAndClearErrors(formattedDateOfBirth);
                        }
                        else {
                            validationSsn.invalidateFieldAndShowError(result.localisedMessage);
                            validationDateOfBirth.clearValueAndClearErrors();
                        }
                    })
                    .catch(() => {
                        validationSsn.invalidateFieldAndShowError("Couldn't connect to server for validation");
                    });
            }
            else {
                validationSsn.clearValueAndClearErrors();
                validationDateOfBirth.clearValueAndClearErrors();
            }
        }

		private elementExistsByName(name: string): boolean {
			return this.getElementByName(name).length === 1;
        }

		private formatSwedishDate(date: string): string {
			let year = date.substring(0, 4);
			let month = date.substring(5, 7);
			let day = date.substring(8, 10);
			return `${year}-${month}-${day}`;
		}
		private getElementByName(name: string): JQuery {
			return $(`[name='${name}']`);
		}
		private hasRequiredElements(requiredElementNames: string[]): boolean {
			return requiredElementNames.every((name) => this.elementExistsByName(name));
		}
	}
}