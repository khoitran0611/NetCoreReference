﻿module Hydra.Interactions {
    export class Validation {
        constructor(private $element: JQuery) {
            if (!(this.hasLibraries && this.hasForm && this.controlHasPropertyName)) {
                throw `Validation won't work for element ${$element.attr('id')}`;
            }
        }
        invalidateField(): void {
            this.$element.attr('aria-invalid', 'true');
        }
        validateField(): void {
            this.$element.attr('aria-invalid', 'false');
        }

        showError(errorMessage: string) {
            let validator = this.$element.closest('form').validate();
            let elementName = this.$element.attr('name');
            let error: any = {};
            error[elementName] = errorMessage;
            validator.showErrors(error);
        }
        clearErrors(): void {
            this.showError(null);
        }

        setValueAndClearErrors(value: string) {
            this.$element.val(value);
            this.validateField();
            this.clearErrors();
        }
        clearValueAndClearErrors() {
            this.$element.val('');
            this.validateField();
            this.clearErrors();
        }
        invalidateFieldAndShowError(errorMessage: string) {
            this.invalidateField();
            this.showError(errorMessage);
        }
        private hasLibraries(): boolean {
            return jQuery !== undefined                        // npm i @types/jquery
                && jQuery.validator !== undefined              // npm i @types/jquery.validation
                && jQuery.validator.unobtrusive !== undefined; // npm i @types/jquery-validation-unobtrusive
        }
        private hasForm(): boolean {
            return this.$element.closest('form').length >= 1;
        }
        private controlHasPropertyName(): boolean {
            return this.$element.attr('name') !== undefined;
        }
    }

    export function AddValidation(): void {
        $.validator.addMethod('ariainvalid', function (value, element, params) {
            return $(element).attr('aria-invalid') === 'true';
        });
        $.validator.unobtrusive.adapters.add('ariainvalid', [], function (options: any) {
            options.rules['ariainvalid'] = options.params;
        });
    }
}