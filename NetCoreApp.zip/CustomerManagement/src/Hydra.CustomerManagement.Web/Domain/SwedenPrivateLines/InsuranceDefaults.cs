﻿using System.ComponentModel.DataAnnotations;

namespace Hydra.CustomerManagement.Web.Domain.SwedenPrivateLines
{
    public class InsuranceDefaults
    {
        [StringLength(50)]
        public string PaymentMethod { get; set; }

        [StringLength(50)]
        public string RenewalMode { get; set; } = "Automatic";
    }
}