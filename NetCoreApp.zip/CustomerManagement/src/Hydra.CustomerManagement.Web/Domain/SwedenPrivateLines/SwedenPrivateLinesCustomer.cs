﻿using System;
using System.Collections.Generic;
using System.Linq;
using Hydra.Common.Integration.EventBus.Exceptions;

namespace Hydra.CustomerManagement.Web.Domain.SwedenPrivateLines
{
    public class SwedenPrivateLinesCustomer
    {
        public string Id { get; set; }
        public string Type { get; set; }
        public string Reference { get; set; }
        public string SourceName { get; set; }
        public int Version { get; set; }

        public CustomerNames CustomerNames { get; set; }
        public InsuranceDefaults InsuranceDefaults { get; set; }
        public CustomerDetails CustomerDetails { get; set; }
        public AddressDetails DefaultAddressDetails { get; set; }
        public AdditionalDetails AdditionalDetails { get; set; }
        public bool ContactMotorRegistry { get; set; }

        public List<PolicySummary> Policies { get; set; } = new List<PolicySummary>();

        internal void AddPolicy(PolicySummary policy)
        {
            if (this.Policies.Any(p => p.PolicyId == policy.PolicyId))
            {
                throw new OldExternalVersionException("Error trying to add policy that already exists");
            }

            this.Policies.Add(policy);
            this.Version++;
        }

        internal void UpdatePolicy(
            Guid policyId,
            int policyVersion,
            bool? isActiveChange,
            PolicyChange.Period updatedPeriod,
            decimal? updatedPremium,
            string currency,
            string formattedPremium)
        {
            var policy = GetPolicyAtVersion(policyId, policyVersion);
            if (isActiveChange.HasValue)
            {
                policy.IsActive = isActiveChange.Value;
            }
            if (updatedPeriod != null)
            {
                policy.PolicyStart = updatedPeriod.Start;
                policy.PolicyEnd = updatedPeriod.End;
            }
            if(updatedPremium.HasValue)
            {
                policy.Premium = updatedPremium.Value;
                policy.Currency = currency;
                policy.FormattedPremium = formattedPremium;
            }
            this.Version++;
        }

        internal void UpdatePolicyStatus(Guid policyId, int policyVersion, bool isActive)
        {
            GetPolicyAtVersion(policyId, policyVersion).IsActive = isActive;
            this.Version++;
        }

        internal void UpdatePolicyPeriod(Guid policyId, int policyVersion, PolicyChange.Period updatedPeriod)
        {
            var policy = GetPolicyAtVersion(policyId, policyVersion);
            policy.PolicyStart = updatedPeriod.Start;
            policy.PolicyEnd = updatedPeriod.End;
            this.Version++;
        }

        internal void UpdatePolicyPremium(Guid policyId, int policyVersion, decimal premium, string currency, string formattedPremium)
        {
            var policy = GetPolicyAtVersion(policyId, policyVersion);
            policy.Premium = premium;
            policy.Currency = currency;
            policy.FormattedPremium = formattedPremium;
            this.Version++;
        }

        internal void RemovePolicy(Guid policyId, int policyVersion)
        {
            var policy = GetPolicyAtVersion(policyId, policyVersion);
            this.Policies.Remove(policy);
            this.Version++;
        }

        private PolicySummary GetPolicyAtVersion(Guid policyId, int nextVersion)
        {
            var matchingPolicy = this.Policies.SingleOrDefault(p => p.PolicyId == policyId);
            if (matchingPolicy == null)
            {
                throw new OutOfSequenceExternalVersionException("Trying to update policy that hasn't been created yet.");
            }
            if (matchingPolicy.Version == nextVersion)
            {
                throw new OldExternalVersionException($"Customer Policy at version {matchingPolicy.Version} has already been updated");
            }
            var matchingPolicyExpectedVersion = matchingPolicy.Version + 1;
            if (matchingPolicyExpectedVersion > nextVersion)
            {
                throw new OutOfSequenceExternalVersionException($"Cannot update Customer Policy at version {matchingPolicy.Version} with data for version {nextVersion}");
            }

            matchingPolicy.Version = nextVersion;
            return matchingPolicy;
        }
    }
}