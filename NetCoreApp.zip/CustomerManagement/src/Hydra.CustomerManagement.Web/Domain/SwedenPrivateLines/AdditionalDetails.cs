﻿using System.ComponentModel.DataAnnotations;

namespace Hydra.CustomerManagement.Web.Domain.SwedenPrivateLines
{
    public class AdditionalDetails
    {
        [StringLength(1000)]
        public string AdditionalInformation { get; set; }
    }
}