﻿using System;
using System.ComponentModel.DataAnnotations;
using Hydra.CustomerManagement.Web.Attributes;
using Hydra.CustomerManagement.Web.I18n;

namespace Hydra.CustomerManagement.Web.Domain.SwedenPrivateLines
{
    public class AddressDetails
    {
        public Guid AddressId { get; set; }

        [Required(ErrorMessageResourceName = "AddressOneRequired", ErrorMessageResourceType = typeof(ResourceStrings.Validation))]
        [StringLength(50)]
        public string AddressLineOne { get; set; }

        [StringLength(50)]
        public string AddressType { get; set; }

        [Required(ErrorMessageResourceName = "CityRequired", ErrorMessageResourceType = typeof(ResourceStrings.Validation))]
        [StringLength(50)]
        public string City { get; set; }

        [StringLength(50)]
        public string Country { get; set; } = "SE";

        public bool IsDefault { get; set; } = true;

        [Required(ErrorMessageResourceName = "PostCodeRequired", ErrorMessageResourceType = typeof(ResourceStrings.Validation))]
        [StringLength(20)]
        [SwedenPostcodeValidation]
        public string PostCode { get; set; }
    }
}