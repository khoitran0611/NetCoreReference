﻿using System;
using System.ComponentModel.DataAnnotations;
using Hydra.CustomerManagement.Web.I18n;

namespace Hydra.CustomerManagement.Web.Domain.SwedenPrivateLines
{
    public sealed class CustomerNames : IEquatable<CustomerNames>
    {
        [Required(ErrorMessageResourceName = "FirstNameRequired", ErrorMessageResourceType = typeof(ResourceStrings.Validation))]
        [StringLength(50)]
        public string FirstName { get; set; }

        [Required(ErrorMessageResourceName = "LastNameRequired", ErrorMessageResourceType = typeof(ResourceStrings.Validation))]
        [StringLength(50)]
        public string LastName { get; set; }

        public bool Equals(CustomerNames other)
        {
            return this.FirstName.Equals(other.FirstName) &&
                this.LastName.Equals(other.LastName);
        }
    }
}