﻿using System;
using System.ComponentModel.DataAnnotations;
using Hydra.CustomerManagement.Web.Attributes;
using Hydra.CustomerManagement.Web.I18n;

namespace Hydra.CustomerManagement.Web.Domain.SwedenPrivateLines
{
    public sealed class CustomerDetails : IEquatable<CustomerDetails>
    {
        [Required(ErrorMessageResourceName = "DateOfBirthRequired", ErrorMessageResourceType = typeof(ResourceStrings.Validation))]
        [DisplayAsReadOnly]
        public DateTimeOffset? DateOfBirth { get; set; }

        [Required(ErrorMessageResourceName = "EmailRequired", ErrorMessageResourceType = typeof(ResourceStrings.Validation))]
        [EmailAddress]
        [StringLength(50)]
        public string Email { get; set; }

        [Required(ErrorMessageResourceName = "NINRequired", ErrorMessageResourceType = typeof(ResourceStrings.Validation))]
        [StringLength(50)]
        [SwedenNinValidation]
        public string IdentificationNumber { get; set; }

        [Required(ErrorMessageResourceName = "MobileNumberRequired", ErrorMessageResourceType = typeof(ResourceStrings.Validation))]
        [StringLength(50)]
        public string MobileNumber { get; set; }

        [StringLength(50)]
        public string TelephoneNumber { get; set; }

        public bool IsBlacklisted { get; set; }

        public bool Equals(CustomerDetails other)
        {
            return this.IdentificationNumber.Equals(other.IdentificationNumber) &&
                this.DateOfBirth.Equals(other.DateOfBirth) &&
                this.TelephoneNumber.Equals(other.TelephoneNumber) &&
                this.MobileNumber.Equals(other.MobileNumber) &&
                this.Email.Equals(other.Email) &&
                this.IsBlacklisted.Equals(other.IsBlacklisted);
        }
    }
}