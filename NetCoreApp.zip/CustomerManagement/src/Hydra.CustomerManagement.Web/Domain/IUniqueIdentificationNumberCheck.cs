﻿namespace Hydra.CustomerManagement.Web.Domain
{
    public interface IUniqueIdentificationNumberCheck
    {
        bool IsIdentificationNumberUnique { get; }
    }
}
