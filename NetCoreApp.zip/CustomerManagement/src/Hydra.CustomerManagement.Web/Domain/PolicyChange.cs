﻿using System;

namespace Hydra.CustomerManagement.Web.Domain
{
    public class PolicyChange
    {
        public bool? IsActive { get; set; }

        public Period PolicyPeriod { get; set; }

        public decimal? Premium { get; set; }

        public string Currency { get; set; }

        public string FormattedPremium { get; set; }

        public class Period
        {
            public DateTimeOffset Start { get; set; }
            public DateTimeOffset End { get; set; }
        }
    }
}
