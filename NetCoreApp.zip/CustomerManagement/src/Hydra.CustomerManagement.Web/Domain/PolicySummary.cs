﻿using System;

namespace Hydra.CustomerManagement.Web.Domain
{
    public class PolicySummary
    {
        public Guid PolicyId { get; set; }
        public string ProductId { get; set; }
        public DateTimeOffset PolicyStart { get; set; }
        public DateTimeOffset PolicyEnd { get; set; }
        public string PolicyReference { get; set; }
        public string ProductName { get; set; }
        public bool IsActive { get; set; }
        public decimal Premium { get; set; }
        public string Currency { get; set; }
        public string FormattedPremium { get; set; }
        public int Version { get; set; }
        public Guid PartnerId { get; set; }
        public string Scope { get; set; }
        public string OrganisationContext { get; set; }
    }
}
