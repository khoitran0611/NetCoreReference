﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Raven.Client.Documents;
using Raven.Client.Documents.BulkInsert;
using Raven.Client.Documents.Operations.Attachments;

namespace Hydra.CustomerManagement.Web.Services
{
    public interface INinManagmentService
    {
        Task<CreditCheckResult> GetCreditCheckResultAsync(string identificationNumber);

        Task BlacklistNins(IEnumerable<string> nins);

        Task WhitelistNins(IEnumerable<string> nins);

        Task UploadLatestBlacklistBatch(Stream stream, string delimiter);

        Task<BlacklistBatchResult> GetLatestBlacklistBatch();

        Task SaveBlacklistingJobResult(string jobId, BlacklistJobResult blacklistJobResult);

        Task<BlacklistJobResult> GetBlacklistingJobResultAsync(string jobId);
    }

    public class RavenNinManagementService : INinManagmentService
    {
        private readonly IDocumentStore documentStore;

        public RavenNinManagementService(
            IRavenStoreFactory storeFactory)
        {
            documentStore = storeFactory.Store;
        }

        public async Task BlacklistNins(IEnumerable<string> nins)
        {
            using (var session = documentStore.OpenAsyncSession())
            {
                BulkInsertOperation bulkInsert = null;
                try
                {
                    bulkInsert = documentStore.BulkInsert();

                    foreach (var nin in nins)
                    {
                        await bulkInsert.StoreAsync(new BlacklistedNin { Nin = nin }, $@"{nameof(BlacklistedNin)}/{nin}");
                    }
                }
                finally
                {
                    if (bulkInsert != null)
                    {
                        await bulkInsert.DisposeAsync().ConfigureAwait(false);
                        await session.SaveChangesAsync();
                    }
                }
            }
        }

        public async Task<CreditCheckResult> GetCreditCheckResultAsync(string identificationNumber)
        {
            var identificationNumberWithoutHyphens = identificationNumber.Replace("-", string.Empty);

            using (var session = documentStore.OpenAsyncSession())
            {
                var result = await session.Query<BlacklistedNin>()
                    .FirstOrDefaultAsync(c => c.Nin == identificationNumberWithoutHyphens);

                return new CreditCheckResult(result != null) { Nin = identificationNumberWithoutHyphens };
            }
        }

        public async Task<BlacklistBatchResult> GetLatestBlacklistBatch()
        {
            using (var session = documentStore.OpenAsyncSession())
            {
                var latestBatch = await session.LoadAsync<BlacklistedBatch>($@"{nameof(BlacklistedBatch)}/{BlacklistedBatch.LastBlacklistedBatchId}");

                if (latestBatch == null)
                {
                    return null;
                }

                using (AttachmentResult attachment = await session.Advanced.Attachments.GetAsync(latestBatch, "importFile"))
                {
                    var blacklistBatchResult = new BlacklistBatchResult
                    {
                        LatestStream = new MemoryStream(),
                        Delimiter = latestBatch.Delimiter
                    };
                    await attachment.Stream.CopyToAsync(blacklistBatchResult.LatestStream);
                    blacklistBatchResult.LatestStream.Seek(0, SeekOrigin.Begin);
                    return blacklistBatchResult;
                }
            }
        }

        public async Task SaveBlacklistingJobResult(string jobId, BlacklistJobResult blacklistJobResult)
        {
            using (var session = documentStore.OpenAsyncSession())
            {
                await session.StoreAsync(blacklistJobResult, $@"{nameof(BlacklistJobResult)}/{jobId}");

                await session.SaveChangesAsync();
            }
        }

        public async Task<BlacklistJobResult> GetBlacklistingJobResultAsync(string jobId)
        {
            using (var session = documentStore.OpenAsyncSession())
            {
                var result = await session.LoadAsync<BlacklistJobResult>($@"{nameof(BlacklistJobResult)}/{jobId}");

                return result;
            }
        }

        public async Task UploadLatestBlacklistBatch(Stream stream, string delimiter)
        {
            using (var session = documentStore.OpenAsyncSession())
            {
                session.Advanced.UseOptimisticConcurrency = false;
                var lastUploadedBatch = new BlacklistedBatch
                {
                    Name = BlacklistedBatch.LastBlacklistedBatchId,
                    Delimiter = delimiter,
                    BatchDate = DateTimeOffset.Now
                };

                await session.StoreAsync(lastUploadedBatch, id: $@"{nameof(BlacklistedBatch)}/{BlacklistedBatch.LastBlacklistedBatchId}");
                session.Advanced.Attachments.Store(lastUploadedBatch, "importFile", stream, "text/csv");

                await session.SaveChangesAsync();
            }
        }

        public async Task WhitelistNins(IEnumerable<string> nins)
        {
            using (var session = documentStore.OpenAsyncSession())
            {
                foreach (var nin in nins)
                {
                    session.Delete($@"{nameof(BlacklistedNin)}/{nin}");
                }

                await session.SaveChangesAsync();
            }
        }
    }
}