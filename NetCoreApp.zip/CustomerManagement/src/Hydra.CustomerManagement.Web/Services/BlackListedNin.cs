﻿using System;

namespace Hydra.CustomerManagement.Web.Services
{
    public class BlacklistedNin
    {
        public string Nin { get; set; }
    }
}