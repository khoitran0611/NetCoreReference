﻿using System;
using System.Linq;
using Microsoft.AspNetCore.Http;

namespace Hydra.CustomerManagement.Web.Services
{
    public class ContextUserDetails
    {
        public string DisplayName { get; set; }
        public Guid Scope { get; set; }
    }

    public class CurrentUserDetailsService
    {
        private readonly IHttpContextAccessor accessor;

        public CurrentUserDetailsService(IHttpContextAccessor accessor)
        {
            this.accessor = accessor;
        }

        public ContextUserDetails GetContextUserDetails()
        {
            return new ContextUserDetails
            {
                DisplayName = GetDisplayName(),
                Scope = GetScope()
            };
        }

        private string GetDisplayName()
        {
            var user = accessor?.HttpContext?.User;
            return user == null ? string.Empty : (user.FindFirst("given_name")?.Value + " " + user.FindFirst("family_name")?.Value).Trim();
        }

        private Guid GetScope()
        {
            var scopeValue = accessor?.HttpContext?.User?.FindFirst(HydraClaimTypes.Tenant)?.Value;
            if (scopeValue != null && Guid.TryParse(scopeValue, out Guid scope))
            {
                return scope;
            }
            else
            {
                throw new InvalidOperationException("Tenant scope is not found or not valid");
            }
        }
    }
}