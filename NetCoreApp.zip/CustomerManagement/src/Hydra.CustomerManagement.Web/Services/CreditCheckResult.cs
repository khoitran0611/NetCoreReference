﻿using System;
using System.Linq;

namespace Hydra.CustomerManagement.Web.Services
{
    public class CreditCheckResult
    {
        public CreditCheckResult(bool isBlackListed)
        {
            IsBlackListed = isBlackListed;
        }

        public string Nin { get; set; }
        public bool IsBlackListed { get; private set; }
    }
}