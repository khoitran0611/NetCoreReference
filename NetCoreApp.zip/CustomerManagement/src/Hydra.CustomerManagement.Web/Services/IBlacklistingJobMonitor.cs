﻿using System;
using System.Linq;

namespace Hydra.CustomerManagement.Web.Services
{
    public interface IBlacklistingJobMonitor
    {
        JobStatus GetCurrentStatus(string jobId);
    }

    public class JobStatus
    {
        public bool HasFinishedExecuting { get; set; }
        public bool HasFinishedSuccessfully { get; set; }
    }
}