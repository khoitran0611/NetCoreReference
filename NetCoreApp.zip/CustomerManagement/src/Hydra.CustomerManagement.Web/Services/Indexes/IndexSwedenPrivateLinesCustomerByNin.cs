﻿using System;
using System.Linq;
using Hydra.CustomerManagement.Web.Domain.SwedenPrivateLines;
using Raven.Client.Documents.Indexes;

namespace Hydra.CustomerManagement.Web.Services.Indexes
{
    public class IndexSwedenPrivateLinesCustomerByNin : AbstractIndexCreationTask<SwedenPrivateLinesCustomer>
    {
        public IndexSwedenPrivateLinesCustomerByNin()
        {
            this.Map =
                docs =>
                    from d in docs
                    select new
                    {
                        CustomerDetails_IdentificationNumber = d.CustomerDetails.IdentificationNumber,
                    };
        }
    }
}