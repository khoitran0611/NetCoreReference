﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Hydra.Common.Integration.EventBus;
using Hydra.CustomerManagement.Web.Domain;
using Hydra.CustomerManagement.Web.Domain.SwedenPrivateLines;
using Hydra.CustomerManagement.Web.Mappers;

namespace Hydra.CustomerManagement.Web.Services
{
    public class EventPublishingCustomerManagementService : ICustomerManagementService
    {
        private readonly ICustomerEventsMapper customerEventsMapper;
        private readonly IEventBus eventBus;
        private readonly CurrentUserDetailsService currentUserDetailsService;
        private readonly RavenCustomerManagementService ravenRepository;

        public EventPublishingCustomerManagementService(
            ICustomerEventsMapper customerEventsMapper,
            IEventBus eventBus,
            CurrentUserDetailsService currentUserDetailsService,
            RavenCustomerManagementService ravenRepository)
        {
            this.customerEventsMapper = customerEventsMapper;
            this.eventBus = eventBus;
            this.currentUserDetailsService = currentUserDetailsService;
            this.ravenRepository = ravenRepository;
        }

        public async Task<SwedenPrivateLinesCustomer> CreateCustomerAsync(SwedenPrivateLinesCustomer customer, bool isIdentificationNumberUnique, string correlationId)
        {
            var newCustomer = await ravenRepository.CreateCustomerAsync(customer, isIdentificationNumberUnique, correlationId);

            var userDetails = currentUserDetailsService.GetContextUserDetails();
            var customerCreatedEvent = customerEventsMapper.MapToCustomerCreatedEvent(
                newCustomer,
                userDetails.Scope,
                userDetails.DisplayName,
                correlationId);

            eventBus.Publish(customerCreatedEvent);

            return newCustomer;
        }

        public async Task<SwedenPrivateLinesCustomer> GetCustomerByIdAsync(string id)
        {
            return await ravenRepository.GetCustomerByIdAsync(id);
        }

        public async Task<Guid> GetCustomerIdByIdentificationNumberAsync(string identificationNumber)
        {
            return await ravenRepository.GetCustomerIdByIdentificationNumberAsync(identificationNumber);
        }

        public async Task<int> AddPolicyToCustomerAsync(string id, PolicySummary policy, string correlationId)
        {
            var updatedVersion = await ravenRepository.AddPolicyToCustomerAsync(id, policy, correlationId);

            var policyAddedEvent = customerEventsMapper.MapToCustomerPolicyAddedEvent(
                id,
                updatedVersion,
                policy,
                correlationId);

            eventBus.Publish(policyAddedEvent);

            return updatedVersion;
        }

        public async Task<SwedenPrivateLinesCustomer> UpdateCustomerPolicyAsync(string id, Guid policyId, int policyVersion, PolicyChange policyChange, string correlationId)
        {
            var updatedCustomer = await ravenRepository.UpdateCustomerPolicyAsync(id, policyId, policyVersion, policyChange, correlationId);
            var updatedPolicy = updatedCustomer.Policies.Single(p => p.PolicyId == policyId);

            var policyUpdatedEvent = customerEventsMapper.MapToCustomerPolicyUpdatedEvent(
                id,
                updatedCustomer.Version,
                updatedPolicy,
                correlationId);

            eventBus.Publish(policyUpdatedEvent);

            return updatedCustomer;
        }

        public async Task<int> RemovePolicyFromCustomerAsync(string id, Guid policyId, int policyVersion, string correlationId)
        {
            var updatedVersion = await ravenRepository.RemovePolicyFromCustomerAsync(id, policyId, policyVersion, correlationId);

            var policyRemovedEvent = customerEventsMapper.MapToCustomerPolicyRemovedEvent(
                id,
                updatedVersion,
                policyId,
                correlationId);

            eventBus.Publish(policyRemovedEvent);

            return updatedVersion;
        }

        public async Task<SwedenPrivateLinesCustomer> UpdateCustomerAsync(string id, string correlationId, Action<SwedenPrivateLinesCustomer> updater)
        {
            var contextUserDetails = currentUserDetailsService.GetContextUserDetails();
            var updatedCustomer = await UpdateCustomerAsync(id, correlationId, contextUserDetails, updater);
            return updatedCustomer;
        }

        public async Task<SwedenPrivateLinesCustomer> UpdateCustomerAsync(string id, string correlationId, ContextUserDetails contextUserDetails, Action<SwedenPrivateLinesCustomer> updater)
        {
            var updatedCustomer = await ravenRepository.UpdateCustomerAsync(id, correlationId, contextUserDetails, updater);

            var customerUpdatedEvent = customerEventsMapper.MapToCustomerUpdatedEvent(
                updatedCustomer,
                contextUserDetails.Scope,
                contextUserDetails.DisplayName,
                correlationId);

            eventBus.Publish(customerUpdatedEvent);

            return updatedCustomer;
        }
    }
}