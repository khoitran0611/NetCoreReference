﻿using System;
using System.IO;
using System.Linq;

namespace Hydra.CustomerManagement.Web.Services
{
    public class BlacklistBatchResult
    {
        public Stream LatestStream { get; set; }
        public string Delimiter { get; set; }
    }
}