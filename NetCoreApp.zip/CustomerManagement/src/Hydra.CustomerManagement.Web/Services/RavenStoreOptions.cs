﻿using Hydra.CustomerManagement.Web.Services.Indexes;
using Raven.Client.Documents.Indexes;

namespace Hydra.CustomerManagement.Web.Services
{
    public class RavenStoreOptions
    {
        public bool RunInMemory { get; set; }

        public string Url { get; set; }

        public string DatabaseName { get; set; }

        public static AbstractIndexCreationTask[] GetIndexes()
        {
            return new AbstractIndexCreationTask[]
            {
                new IndexSwedenPrivateLinesCustomerByNin()
            };
        }
    }
}