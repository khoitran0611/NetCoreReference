﻿using System;
using System.Linq;
using Hangfire;
using Hangfire.Storage;

namespace Hydra.CustomerManagement.Web.Services
{
    public class BlacklistingJobStatusMonitor : IBlacklistingJobMonitor
    {
        private readonly string[] finishedStates = new[] { "Succeeded", "Failed" };
        private readonly string[] successStates = new[] { "Succeeded" };
        private readonly IMonitoringApi jobStorage;

        public BlacklistingJobStatusMonitor(JobStorage jobStorage)
        {
            this.jobStorage = jobStorage.GetMonitoringApi();
        }

        public JobStatus GetCurrentStatus(string jobId)
        {
            var job = jobStorage.JobDetails(jobId);

            var currentStatus = job.History.OrderByDescending(state => state.CreatedAt).First();
            var hasFinishedExecuting = finishedStates.Contains(currentStatus.StateName);
            var hasFinishedExecutingSuccessfully = successStates.Contains(currentStatus.StateName);

            return new JobStatus
            {
                HasFinishedExecuting = hasFinishedExecuting,
                HasFinishedSuccessfully = hasFinishedExecutingSuccessfully,
            };
        }
    }
}