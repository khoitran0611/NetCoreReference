﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CsvHelper;
using Hydra.CustomerManagement.Web.Mappings;
using Microsoft.Extensions.Logging;

namespace Hydra.CustomerManagement.Web.Services
{
    public interface IBlacklistingService
    {
        Task<BlacklistingResult> BlacklistBatch(Stream stream, string delimiter);
    }

    public class BlacklistingResult
    {
        public List<string> NewlyBlacklistedNins { get; set; }
        public List<string> WhitelistedNins { get; set; }
        public int AllBlacklistedNinsCount { get; set; }
    }

    public class BlacklistingService : IBlacklistingService
    {
        private readonly INinManagmentService ninManagementService;
        private readonly ILogger<BlacklistingService> logger;

        public BlacklistingService(INinManagmentService ninManagementService, ILogger<BlacklistingService> logger)
        {
            this.ninManagementService = ninManagementService;
            this.logger = logger;
        }

        public async Task<BlacklistingResult> BlacklistBatch(Stream stream, string delimiter)
        {
            var processingResult = await ProcessBlacklistBatch(stream, delimiter);

            ResetStreamToStart(stream);

            await ninManagementService.UploadLatestBlacklistBatch(stream, delimiter);

            return processingResult;
        }

        private static void ResetStreamToStart(Stream stream)
        {
            if (stream.CanSeek)
            {
                stream.Seek(0, SeekOrigin.Begin);
            }
        }

        private async Task<BlacklistingResult> ProcessBlacklistBatch(Stream stream, string delimiter)
        {
            var currentBlacklistBatch = await ninManagementService.GetLatestBlacklistBatch();

            var currentlyBlacklistedNins = currentBlacklistBatch == null ? new List<string>() : GetNins(currentBlacklistBatch.LatestStream, currentBlacklistBatch.Delimiter);
            var ninsToBlacklist = GetNins(stream, delimiter, leaveStreamOpen: true);

            logger.LogInformation($"Current batch has {currentlyBlacklistedNins.Count} blacklisted nins and new batch has {ninsToBlacklist.Count} nins to blacklist.");

            var ninsToAdd = ninsToBlacklist.Except(currentlyBlacklistedNins).ToList();
            var ninsToDelete = currentlyBlacklistedNins.Except(ninsToBlacklist).ToList();

            await ninManagementService.BlacklistNins(ninsToAdd);
            await ninManagementService.WhitelistNins(ninsToDelete);

            logger.LogInformation($"Newly blacklisted {ninsToAdd.Count} nins and whitelisted {ninsToDelete.Count} nins.");

            return new BlacklistingResult
            {
                NewlyBlacklistedNins = ninsToAdd,
                WhitelistedNins = ninsToDelete,
                AllBlacklistedNinsCount = ninsToBlacklist.Count
            };
        }

        private IList<string> GetNins(Stream stream, string delimiter, bool leaveStreamOpen = false)
        {
            if (stream.CanSeek)
            {
                stream.Seek(0, SeekOrigin.Begin);
            }
            using (var streamReader = new StreamReader(stream, Encoding.UTF8, detectEncodingFromByteOrderMarks: true, bufferSize: 1024, leaveOpen: leaveStreamOpen))
            using (var csv = new CsvReader(streamReader))
            {
                csv.Configuration.HasHeaderRecord = false;
                csv.Configuration.Delimiter = delimiter;
                csv.Configuration.RegisterClassMap<BlacklistedNinMap>();

                return csv.GetRecords<BlacklistedNin>().Select(bln => GetProcessedNin(bln.Nin)).ToList();
            }
        }

        private string GetProcessedNin(string nin)
        {
            return nin.Length == 10 ? $"19{nin}" : nin;
        }
    }
}