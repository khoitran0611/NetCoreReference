﻿namespace Hydra.CustomerManagement.Web.Services
{
    public class BlacklistJobResult
    {
        public int NumberOfNewlyBlacklistedNins { get; set; }
        public int NumberOfNewlyWhitelistedNins { get; set; }
        public int TotalBlacklistedNinsInTheBatch { get; set; }
        public int NumberOfCustomersBlacklisted { get; set; }
        public int NumberOfCustomersWhitelisted { get; set; }
    }
}