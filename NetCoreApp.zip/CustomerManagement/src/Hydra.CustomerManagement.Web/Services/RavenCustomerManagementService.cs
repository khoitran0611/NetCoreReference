﻿using System;
using System.Threading.Tasks;
using CentralSequences.Client;
using Hydra.CustomerManagement.Web.Domain;
using Hydra.CustomerManagement.Web.Domain.SwedenPrivateLines;
using Hydra.CustomerManagement.Web.Exceptions;
using Hydra.CustomerManagement.Web.I18n;
using Hydra.CustomerManagement.Web.Services.Indexes;
using Microsoft.Extensions.Localization;
using Raven.Client.Documents;
using Raven.Client.Documents.Session;

namespace Hydra.CustomerManagement.Web.Services
{
    public class RavenCustomerManagementService : ICustomerManagementService
    {
        private readonly ICentralSequencesClient centralSequencesClient;
        private readonly IDocumentStore documentStore;
        private readonly IStringLocalizer localizer;

        public RavenCustomerManagementService(
            IRavenStoreFactory storeFactory,
            IStringLocalizer localizer,
            ICentralSequencesClient centralSequencesClient)
        {
            this.documentStore = storeFactory.Store;
            this.localizer = localizer;
            this.centralSequencesClient = centralSequencesClient;
        }

        public async Task<SwedenPrivateLinesCustomer> CreateCustomerAsync(SwedenPrivateLinesCustomer customer, bool isIdentificationNumberUnique, string correlationId)
        {
            using (var session = this.documentStore.OpenAsyncSession())
            {
                await AssertNewCustomer(customer.Id, session);
                await AssertIdentificationNumberDoesNotAlreadyExist(customer.CustomerDetails.IdentificationNumber, isIdentificationNumberUnique);

                var reference = await this.centralSequencesClient.GetNextSequenceAsync("CustomerReference");
                customer.Reference = reference.ToString();
                customer.Version = 0;

                await session.StoreAsync(customer, customer.Id);
                await session.SaveChangesAsync();

                return customer;
            }
        }

        public async Task<SwedenPrivateLinesCustomer> GetCustomerByIdAsync(string id)
        {
            using (var session = this.documentStore.OpenAsyncSession())
            {
                var customer = await session.LoadAsync<SwedenPrivateLinesCustomer>(id);
                return customer;
            }
        }

        public async Task<Guid> GetCustomerIdByIdentificationNumberAsync(string identificationNumber)
        {
            var identificationNumberWithoutHyphens = identificationNumber.Replace("-", string.Empty);

            using (var session = this.documentStore.OpenAsyncSession())
            {
                var customer = await session.Query<SwedenPrivateLinesCustomer, IndexSwedenPrivateLinesCustomerByNin>()
                                .FirstOrDefaultAsync(c => c.CustomerDetails.IdentificationNumber == identificationNumberWithoutHyphens);

                return customer != null ? Guid.Parse(customer.Id) : Guid.Empty;
            }
        }

        public async Task<int> AddPolicyToCustomerAsync(string id, PolicySummary policy, string correlationId)
        {
            using (var session = this.documentStore.OpenAsyncSession())
            {
                var customer = await session.LoadAsync<SwedenPrivateLinesCustomer>(id);
                customer.AddPolicy(policy);

                await session.SaveChangesAsync();

                return customer.Version;
            }
        }

        public async Task<SwedenPrivateLinesCustomer> UpdateCustomerPolicyAsync(string id, Guid policyId, int policyVersion, PolicyChange policyChange, string correlationId)
        {
            using (var session = this.documentStore.OpenAsyncSession())
            {
                var customer = await session.LoadAsync<SwedenPrivateLinesCustomer>(id);
                customer.UpdatePolicy(
                    policyId,
                    policyVersion,
                    policyChange.IsActive,
                    policyChange.PolicyPeriod,
                    policyChange.Premium,
                    policyChange.Currency,
                    policyChange.FormattedPremium);

                await session.SaveChangesAsync();

                return customer;
            }
        }

        public async Task<int> RemovePolicyFromCustomerAsync(string id, Guid policyId, int policyVersion, string correlationId)
        {
            using (var session = this.documentStore.OpenAsyncSession())
            {
                var customer = await session.LoadAsync<SwedenPrivateLinesCustomer>(id);
                customer.RemovePolicy(policyId, policyVersion);

                await session.SaveChangesAsync();

                return customer.Version;
            }
        }

        public async Task<SwedenPrivateLinesCustomer> UpdateCustomerAsync(string id, string correlationId, Action<SwedenPrivateLinesCustomer> updater)
        {
            var updatedCustomer = await UpdateCustomerAsync(id, correlationId, contextUserDetails: null, updater: updater);
            return updatedCustomer;
        }

        public async Task<SwedenPrivateLinesCustomer> UpdateCustomerAsync(string id, string correlationId, ContextUserDetails contextUserDetails, Action<SwedenPrivateLinesCustomer> updater)
        {
            using (var session = this.documentStore.OpenAsyncSession())
            {
                var customer = await session.LoadAsync<SwedenPrivateLinesCustomer>(id);

                var currentVersion = customer.Version;
                updater(customer);
                customer.Version = currentVersion + 1;

                await session.SaveChangesAsync();

                return customer;
            }
        }

        private async Task AssertNewCustomer(string id, IAsyncDocumentSession session)
        {
            var existingCustomer = await session.LoadAsync<SwedenPrivateLinesCustomer>(id);
            if (existingCustomer != null)
            {
                throw new InvalidOperationException(ResourceStrings.Validation.Duplicate_Customer(localizer, id));
            }
        }

        private async Task AssertIdentificationNumberDoesNotAlreadyExist(string identificationNumber, bool isIdentificationNumberUnique)
        {
            if (isIdentificationNumberUnique)
            {
                var customerId = await GetCustomerIdByIdentificationNumberAsync(identificationNumber);
                if (customerId != Guid.Empty)
                {
                    var message = ResourceStrings.Validation.Duplicate_Nin(localizer, identificationNumber);
                    throw new CustomerDuplicatedNinException(message) { CustomerId = customerId, IdentificationNumber = identificationNumber };
                }
            }
        }
    }
}