﻿using System;
using System.Threading;
using Hydra.CustomerManagement.Web.Extensions;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Raven.Client.Documents;

namespace Hydra.CustomerManagement.Web.Services
{
    public interface IRavenStoreFactory : IDisposable
    {
        IDocumentStore Store { get; }
    }

    public class RavenStoreFactory : IRavenStoreFactory
    {
        private readonly Lazy<IDocumentStore> store;
        private readonly RavenStoreOptions options;
        private readonly ILogger<RavenStoreFactory> logger;

        public RavenStoreFactory(RavenStoreOptions options)
        {
            this.options = options;
            this.store = new Lazy<IDocumentStore>(CreateStore, LazyThreadSafetyMode.PublicationOnly);
        }

        public RavenStoreFactory(IOptions<RavenStoreOptions> options, ILogger<RavenStoreFactory> logger)
            : this(options.Value)
        {
            this.logger = logger;
        }

        public IDocumentStore Store => this.store.Value;

        public void Dispose()
        {
            if (this.store.IsValueCreated)
            {
                this.store.Value.Dispose();
            }
        }

        private IDocumentStore CreateStore()
        {
            logger.LogTrace($"Creating Raven Store with options: {JsonConvert.SerializeObject(options, Formatting.Indented)}");

            if (string.IsNullOrWhiteSpace(options.Url) || string.IsNullOrWhiteSpace(options.DatabaseName))
            {
                throw new InvalidOperationException("Please specify configuration for Raven Store.");
            }

            try
            {
                var documentStore = new DocumentStore
                {
                    Urls = new string[] { options.Url },
                    Database = options.DatabaseName
                };

                documentStore.Conventions.CustomizeJsonSerializer =
                    serializer => serializer.ObjectCreationHandling = ObjectCreationHandling.Replace;

                documentStore.Conventions.UseOptimisticConcurrency = true;

                documentStore.Initialize();

                if (!documentStore.DatabaseExists(options.DatabaseName))
                {
                    documentStore.CreateDatabase(options.DatabaseName);
                }

                documentStore.AddIndexes(RavenStoreOptions.GetIndexes());
                return documentStore;
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException($"Can not create document store with url {options.Url} and database name {options.DatabaseName} with {ex.Message}");
            }
        }
    }
}