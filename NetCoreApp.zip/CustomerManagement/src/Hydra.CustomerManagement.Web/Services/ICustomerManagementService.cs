﻿using System;
using System.Threading.Tasks;
using Hydra.CustomerManagement.Web.Domain;
using Hydra.CustomerManagement.Web.Domain.SwedenPrivateLines;

namespace Hydra.CustomerManagement.Web.Services
{
    public interface ICustomerManagementService
    {
        Task<SwedenPrivateLinesCustomer> CreateCustomerAsync(SwedenPrivateLinesCustomer customer, bool isIdentificationNumberUnique, string correlationId);

        Task<SwedenPrivateLinesCustomer> GetCustomerByIdAsync(string id);

        Task<Guid> GetCustomerIdByIdentificationNumberAsync(string identificationNumber);

        Task<SwedenPrivateLinesCustomer> UpdateCustomerAsync(string id, string correlationId, Action<SwedenPrivateLinesCustomer> updater);

        Task<SwedenPrivateLinesCustomer> UpdateCustomerAsync(string id, string correlationId, ContextUserDetails contextUserDetails, Action<SwedenPrivateLinesCustomer> updater);

        Task<int> AddPolicyToCustomerAsync(string id, PolicySummary policy, string correlationId);

        Task<SwedenPrivateLinesCustomer> UpdateCustomerPolicyAsync(string id, Guid policyId, int policyVersion, PolicyChange policyChange, string correlationId);

        Task<int> RemovePolicyFromCustomerAsync(string id, Guid policyId, int policyVersion, string correlationId);
    }
}