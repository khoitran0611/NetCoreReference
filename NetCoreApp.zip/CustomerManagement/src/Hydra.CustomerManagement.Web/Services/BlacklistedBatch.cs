﻿using System;
using System.Linq;

namespace Hydra.CustomerManagement.Web.Services
{
    public class BlacklistedBatch
    {
        public const string LastBlacklistedBatchId = "LastProcessed";
        public string Name { get; set; }
        public string Delimiter { get; set; }
        public DateTimeOffset BatchDate { get; set; }
    }
}