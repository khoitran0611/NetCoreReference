﻿namespace Hydra.CustomerManagement.Web
{
    public static class HydraClaimTypes
    {
        public const string Tenant = "http://schemas.microsoft.com/identity/claims/tenantid";
        public const string Organisation = "http://schemas.contemi.com/ws/2014/04/identity/claims/organisation/scope";
    }
}