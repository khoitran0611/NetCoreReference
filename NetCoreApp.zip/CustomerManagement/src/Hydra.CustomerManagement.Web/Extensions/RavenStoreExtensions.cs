﻿using System;
using System.Collections.Generic;
using System.Linq;
using Raven.Client.Documents;
using Raven.Client.Documents.Indexes;
using Raven.Client.ServerWide;
using Raven.Client.ServerWide.Operations;

namespace Hydra.CustomerManagement.Web.Extensions
{
    public static class RavenStoreExtensions
    {
        public static IDocumentStore AddIndexes(this IDocumentStore store, IEnumerable<AbstractIndexCreationTask> indexCreationTasks)
        {
            foreach(var indexCreationTask in indexCreationTasks)
            {
                IndexCreation.CreateIndexes(indexCreationTask.GetType().Assembly, store);
            }
            return store;
        }

        public static bool DatabaseExists(this IDocumentStore store, string databaseName)
        {
            return store.Maintenance.Server.Send(new GetDatabaseNamesOperation(start: 0, pageSize: 100)).Contains(databaseName);
        }

        public static DatabasePutResult CreateDatabase(this IDocumentStore store, string databaseName)
        {
            var databaseRecord = new DatabaseRecord(databaseName);
            return store.Maintenance.Server.Send(new CreateDatabaseOperation(databaseRecord));
        }
    }
}
