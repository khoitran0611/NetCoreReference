﻿using Hydra.CustomerManagement.Web.Mappers;
using Hydra.CustomerManagement.Web.ResourceMapping;
using Hydra.CustomerManagement.Web.Services;
using Hydra.CustomerManagement.Web.ViewModelFactories;
using Microsoft.Extensions.Configuration;

namespace Microsoft.Extensions.DependencyInjection
{
    public static class CoreServicesExtensions
    {
        public static IServiceCollection AddCustomerManagementCoreServices(this IServiceCollection services)
        {
            services.AddTransient<ICustomerMapper, CustomerMapper>();
            services.AddTransient<ICustomerEventsMapper, CustomerEventsMapper>();
            services.AddTransient(typeof(CustomerViewModelFactory));

            services.AddTransient<INinInformationResourceMapper, NinInformationResourceMapper>();
            services.AddTransient<ILicenseResourceMapper, LicenseResourceMapper>();
            services.AddTransient<ICreditCheckResultResourceMapper, CreditCheckResultResourceMapper>();

            services.AddTransient<INinManagmentService, RavenNinManagementService>();

            services.AddTransient<RavenCustomerManagementService>();
            services.AddTransient<ICustomerManagementService, EventPublishingCustomerManagementService>();
            services.AddTransient(typeof(CurrentUserDetailsService));
            services.AddTransient<IBlacklistingService, BlacklistingService>();
            return services;
        }

        public static IServiceCollection AddRavenStoreServices(this IServiceCollection services, IConfiguration configuration)
        {
            services.Configure<RavenStoreOptions>(configuration.GetSection("CustomerManagement:RavenStoreOptions"));
            services.AddSingleton<IRavenStoreFactory, RavenStoreFactory>();
            return services;
        }
    }
}