﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Hydra.Common.Integration.EventBus;
using Hydra.CustomerManagement.Web.IntegrationEventHandlers;
using Hydra.Insurance.IntegrationEvents;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace Hydra.CustomerManagement.Web
{
    public class EventBusSubscriber : IHostedService
    {
        private readonly IEventBus eventBus;
        private readonly ILogger<EventBusSubscriber> logger;
        private readonly IApplicationLifetime applicationLifetime;
        private readonly IOptions<SubscriberOptions> options;

        public EventBusSubscriber(
            IEventBus eventBus,
            ILogger<EventBusSubscriber> logger,
            IApplicationLifetime applicationLifetime,
            IOptions<SubscriberOptions> options)
        {
            this.eventBus = eventBus;
            this.logger = logger;
            this.applicationLifetime = applicationLifetime;
            this.options = options;
        }

        public Task StartAsync(CancellationToken cancellationToken)
        {
            logger.LogInformation($"{nameof(EventBusSubscriber)} has started");
            applicationLifetime.ApplicationStarted.Register(OnStarted);
            applicationLifetime.ApplicationStopping.Register(OnStopping);
            applicationLifetime.ApplicationStopped.Register(OnStopped);

            return Task.CompletedTask;
        }

        public Task StopAsync(CancellationToken cancellationToken)
        {
            return Task.CompletedTask;
        }

        private void OnStarted()
        {
            logger.LogInformation($"{nameof(EventBusSubscriber)} has started");

            if (this.options.Value.HandleExternalEvents)
            {
                eventBus.Subscribe<PolicyCreatedEvent, PolicyCreatedEventHandler>();
                eventBus.Subscribe<PolicyInceptionExecutedEvent, PolicyUpdatedEventHandler>();
                eventBus.Subscribe<PolicyDetailsUpdatedEvent, PolicyUpdatedEventHandler>();
                eventBus.Subscribe<PolicyExpiredEvent, PolicyUpdatedEventHandler>();
                eventBus.Subscribe<PolicyTerminatedEvent, PolicyUpdatedEventHandler>();
                eventBus.Subscribe<PolicyCancelledEvent, PolicyRemovedEventHandler>();
            }

            this.logger.LogInformation("Insurance events Handler {0}", this.options.Value.HandleExternalEvents ? "ENABLED" : "DISABLED");
        }

        private void OnStopping()
        {
            logger.LogWarning($"{nameof(EventBusSubscriber)} is stopping");

            //// On stop, we will not unsusbcribe as it'll also unbind the event from the queue.
            //// We can use it for some sort of un-install feature in future.
            //// var eventBus = serviceProvider.GetService<IEventBus>();
            //// eventBus.Unsubscribe<CustomerCreatedEvent, CustomerCreatedEventHandler>();
        }

        private void OnStopped()
        {
            logger.LogInformation($"{nameof(EventBusSubscriber)} has stopped");
        }

        public class SubscriberOptions
        {
            public bool HandleExternalEvents { get; set; } = false;
        }
    }
}
