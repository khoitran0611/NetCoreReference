var Hydra;
(function (Hydra) {
    var Interactions;
    (function (Interactions) {
        var Validation = /** @class */ (function () {
            function Validation($element) {
                this.$element = $element;
                if (!(this.hasLibraries && this.hasForm && this.controlHasPropertyName)) {
                    throw "Validation won't work for element " + $element.attr('id');
                }
            }
            Validation.prototype.invalidateField = function () {
                this.$element.attr('aria-invalid', 'true');
            };
            Validation.prototype.validateField = function () {
                this.$element.attr('aria-invalid', 'false');
            };
            Validation.prototype.showError = function (errorMessage) {
                var validator = this.$element.closest('form').validate();
                var elementName = this.$element.attr('name');
                var error = {};
                error[elementName] = errorMessage;
                validator.showErrors(error);
            };
            Validation.prototype.clearErrors = function () {
                this.showError(null);
            };
            Validation.prototype.setValueAndClearErrors = function (value) {
                this.$element.val(value);
                this.validateField();
                this.clearErrors();
            };
            Validation.prototype.clearValueAndClearErrors = function () {
                this.$element.val('');
                this.validateField();
                this.clearErrors();
            };
            Validation.prototype.invalidateFieldAndShowError = function (errorMessage) {
                this.invalidateField();
                this.showError(errorMessage);
            };
            Validation.prototype.hasLibraries = function () {
                return jQuery !== undefined // npm i @types/jquery
                    && jQuery.validator !== undefined // npm i @types/jquery.validation
                    && jQuery.validator.unobtrusive !== undefined; // npm i @types/jquery-validation-unobtrusive
            };
            Validation.prototype.hasForm = function () {
                return this.$element.closest('form').length >= 1;
            };
            Validation.prototype.controlHasPropertyName = function () {
                return this.$element.attr('name') !== undefined;
            };
            return Validation;
        }());
        Interactions.Validation = Validation;
        function AddValidation() {
            $.validator.addMethod('ariainvalid', function (value, element, params) {
                return $(element).attr('aria-invalid') === 'true';
            });
            $.validator.unobtrusive.adapters.add('ariainvalid', [], function (options) {
                options.rules['ariainvalid'] = options.params;
            });
        }
        Interactions.AddValidation = AddValidation;
    })(Interactions = Hydra.Interactions || (Hydra.Interactions = {}));
})(Hydra || (Hydra = {}));
//# sourceMappingURL=Hydra.Interactions.Validation.js.map