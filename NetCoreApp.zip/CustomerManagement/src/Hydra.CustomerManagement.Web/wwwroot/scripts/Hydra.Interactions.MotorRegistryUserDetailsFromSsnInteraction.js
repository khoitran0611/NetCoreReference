var Hydra;
(function (Hydra) {
    var Interactions;
    (function (Interactions) {
        var MotorRegistryInteractionElements = /** @class */ (function () {
            function MotorRegistryInteractionElements(contactRegistry, ssn, firstName, lastName, address, postCode, city) {
                if (this.hasRequiredElements([contactRegistry, ssn, firstName, lastName, address, postCode, city])) {
                    this.contactRegistryElement = this.getElementByName(contactRegistry);
                    this.ssnElement = this.getElementByName(ssn);
                    this.firstNameElement = this.getElementByName(firstName);
                    this.lastNameElement = this.getElementByName(lastName);
                    this.addressElement = this.getElementByName(address);
                    this.postCodeElement = this.getElementByName(postCode);
                    this.cityElement = this.getElementByName(city);
                }
                else {
                    throw "Not all elements needed for interaction exist";
                }
            }
            MotorRegistryInteractionElements.prototype.hasRequiredElements = function (requiredElementNames) {
                var _this = this;
                return requiredElementNames.every(function (name) { return _this.elementExistsByName(name); });
            };
            MotorRegistryInteractionElements.prototype.elementExistsByName = function (name) {
                return this.getElementByName(name).length === 1;
            };
            MotorRegistryInteractionElements.prototype.getElementByName = function (name) {
                return $("[name='" + name + "']");
            };
            return MotorRegistryInteractionElements;
        }());
        Interactions.MotorRegistryInteractionElements = MotorRegistryInteractionElements;
        var MotorRegistryUserDetailsFromSsnInteraction = /** @class */ (function () {
            function MotorRegistryUserDetailsFromSsnInteraction(interactionElements, ninServiceManager) {
                this.interactionElements = interactionElements;
                this.ninServiceManager = ninServiceManager;
                this.bindInteraction();
            }
            MotorRegistryUserDetailsFromSsnInteraction.prototype.bindInteraction = function () {
                var self = this;
                this.interactionElements.contactRegistryElement.focusout(function () {
                    self.RepopulateNinBasedFields(self.interactionElements.contactRegistryElement, self.interactionElements);
                });
                this.interactionElements.ssnElement.focusout(function () {
                    self.RepopulateNinBasedFields(self.interactionElements.ssnElement, self.interactionElements);
                });
                if (this.interactionElements.ssnElement.val()) {
                    self.RepopulateNinBasedFields(self.interactionElements.ssnElement, self.interactionElements);
                }
            };
            MotorRegistryUserDetailsFromSsnInteraction.prototype.clearWarning = function () {
                $("#motorregistry_nin_error").remove();
            };
            MotorRegistryUserDetailsFromSsnInteraction.prototype.addWarning = function (sourceElement, errorText) {
                sourceElement.after("<div id='motorregistry_nin_error' class='alert alert-warning' role='alert'>" + errorText + "</div>");
            };
            MotorRegistryUserDetailsFromSsnInteraction.prototype.clearResults = function (interactionElements) {
                interactionElements.addressElement.val('');
                interactionElements.cityElement.val('');
                interactionElements.postCodeElement.val('');
                interactionElements.firstNameElement.val('');
                interactionElements.lastNameElement.val('');
            };
            MotorRegistryUserDetailsFromSsnInteraction.prototype.setupMotorRegistryFields = function (interactionElements, result) {
                interactionElements.addressElement.val(result.addressLineOne);
                interactionElements.cityElement.val(result.city);
                interactionElements.postCodeElement.val(result.postCode);
                interactionElements.firstNameElement.val(result.firstName);
                interactionElements.lastNameElement.val(result.lastName);
            };
            MotorRegistryUserDetailsFromSsnInteraction.prototype.lookupDetailsFromRegistry = function (interactionElements) {
                var lookupInRegistry = false;
                if (this.interactionElements.ssnElement.val() &&
                    this.interactionElements.contactRegistryElement.val() === "Yes") {
                    lookupInRegistry = true;
                }
                return lookupInRegistry;
            };
            MotorRegistryUserDetailsFromSsnInteraction.prototype.RepopulateNinBasedFields = function (sourceElement, interactionElements) {
                var self = this;
                self.clearWarning();
                if (self.lookupDetailsFromRegistry(interactionElements)) {
                    var ssnValue = self.interactionElements.ssnElement.val();
                    if (ssnValue) {
                        self.ninServiceManager
                            .fetchLicenseDetails(ssnValue)
                            .then(function (result) {
                            if (result.isFailure === true) {
                                if (result.isValidNin === true) {
                                    // Clear values and setup MR related warning message only if the nin is valid.
                                    self.clearResults(interactionElements);
                                    self.addWarning(sourceElement, result.errorText);
                                }
                            }
                            else {
                                // Setup values
                                self.setupMotorRegistryFields(interactionElements, result);
                            }
                        })
                            .catch(function () { self.addWarning(sourceElement, "Could not connect to server for nin lookup"); });
                    }
                }
            };
            return MotorRegistryUserDetailsFromSsnInteraction;
        }());
        Interactions.MotorRegistryUserDetailsFromSsnInteraction = MotorRegistryUserDetailsFromSsnInteraction;
    })(Interactions = Hydra.Interactions || (Hydra.Interactions = {}));
})(Hydra || (Hydra = {}));
//# sourceMappingURL=Hydra.Interactions.MotorRegistryUserDetailsFromSsnInteraction.js.map