var Hydra;
(function (Hydra) {
    var Interactions;
    (function (Interactions) {
        var SsnAndDateOfBirthInteraction = /** @class */ (function () {
            function SsnAndDateOfBirthInteraction(ssn, dateOfBirth, ninServiceManager) {
                this.ssn = ssn;
                this.dateOfBirth = dateOfBirth;
                this.ninServiceManager = ninServiceManager;
                if (this.hasRequiredElements([ssn, dateOfBirth])) {
                    this.bindInteraction();
                }
                else {
                    throw "Not all elements needed for interaction exist";
                }
            }
            SsnAndDateOfBirthInteraction.prototype.bindInteraction = function () {
                var self = this;
                var $ssn = this.getElementByName(this.ssn);
                var validationSsn = new Interactions.Validation($ssn);
                var $dateOfBirth = this.getElementByName(this.dateOfBirth);
                var validationDateOfBirth = new Interactions.Validation($dateOfBirth);
                var isReadOnly = $ssn.prop('readonly') || $ssn.attr('readonly');
                if (!isReadOnly) {
                    $ssn.focusout(function () { return self.update($ssn, self.formatSwedishDate, validationSsn, validationDateOfBirth); });
                    if ($ssn.val()) {
                        self.update($ssn, self.formatSwedishDate, validationSsn, validationDateOfBirth);
                    }
                }
            };
            SsnAndDateOfBirthInteraction.prototype.update = function ($ssn, scopedFormatSwedishDate, validationSsn, validationDateOfBirth) {
                if ($ssn.val()) {
                    var ssnValue = $ssn.val();
                    this.ninServiceManager
                        .fetchBasicNinDetailsAsync(ssnValue)
                        .then(function (result) {
                        if (result.isValid === true
                            && result.alreadyExists === false
                            && result.dateOfBirth !== null) {
                            var formattedDateOfBirth = scopedFormatSwedishDate(result.dateOfBirth);
                            validationSsn.clearErrors();
                            validationDateOfBirth.setValueAndClearErrors(formattedDateOfBirth);
                        }
                        else {
                            validationSsn.invalidateFieldAndShowError(result.localisedMessage);
                            validationDateOfBirth.clearValueAndClearErrors();
                        }
                    })
                        .catch(function () {
                        validationSsn.invalidateFieldAndShowError("Couldn't connect to server for validation");
                    });
                }
                else {
                    validationSsn.clearValueAndClearErrors();
                    validationDateOfBirth.clearValueAndClearErrors();
                }
            };
            SsnAndDateOfBirthInteraction.prototype.elementExistsByName = function (name) {
                return this.getElementByName(name).length === 1;
            };
            SsnAndDateOfBirthInteraction.prototype.formatSwedishDate = function (date) {
                var year = date.substring(0, 4);
                var month = date.substring(5, 7);
                var day = date.substring(8, 10);
                return year + "-" + month + "-" + day;
            };
            SsnAndDateOfBirthInteraction.prototype.getElementByName = function (name) {
                return $("[name='" + name + "']");
            };
            SsnAndDateOfBirthInteraction.prototype.hasRequiredElements = function (requiredElementNames) {
                var _this = this;
                return requiredElementNames.every(function (name) { return _this.elementExistsByName(name); });
            };
            return SsnAndDateOfBirthInteraction;
        }());
        Interactions.SsnAndDateOfBirthInteraction = SsnAndDateOfBirthInteraction;
    })(Interactions = Hydra.Interactions || (Hydra.Interactions = {}));
})(Hydra || (Hydra = {}));
//# sourceMappingURL=Hydra.Interactions.SsnAndDateOfBirthInteraction.js.map