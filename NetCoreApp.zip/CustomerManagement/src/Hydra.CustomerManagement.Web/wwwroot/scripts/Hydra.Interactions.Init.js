var Hydra;
(function (Hydra) {
    var Interactions;
    (function (Interactions) {
        function Init() {
            Interactions.AddValidation();
            AddNinBasedInteractions();
        }
        Interactions.Init = Init;
        function AddNinBasedInteractions() {
            var ninServiceManager = new Interactions.ninManager();
            AddSsnAndDateOfBirthInteraction(ninServiceManager);
            AddMotorRegistryUserDetailsFromSsnInteraction(ninServiceManager);
        }
        function AddSsnAndDateOfBirthInteraction(ninServiceManager) {
            var $interactions = $('interactions > ssn-and-dateofbirth-interaction');
            if ($interactions) {
                if ($interactions.length !== 1) {
                    throw "There are more than 1 SSN and Date of birth interaction";
                }
                var $interaction = $interactions.first();
                var ssn = $interaction.attr('ssn');
                var dateOfBirth = $interaction.attr('date-of-birth');
                new Interactions.SsnAndDateOfBirthInteraction(ssn, dateOfBirth, ninServiceManager);
            }
        }
        function AddMotorRegistryUserDetailsFromSsnInteraction(ninServiceManager) {
            var $interactions = $('interactions > motorregistry-userdetails-from-ssn-interaction');
            if ($interactions) {
                if ($interactions.length !== 1) {
                    throw "There are more than 1 MotorRegistry UserDetails Retrival interactions";
                }
                var $interaction = $interactions.first();
                var ssn = $interaction.attr('ssn');
                var dateOfBirth = $interaction.attr('date-of-birth');
                var registryElements = new Interactions.MotorRegistryInteractionElements($interaction.attr('contact-registry'), $interaction.attr('ssn'), $interaction.attr('first-name'), $interaction.attr('last-name'), $interaction.attr('address'), $interaction.attr('post-code'), $interaction.attr('city'));
                new Interactions.MotorRegistryUserDetailsFromSsnInteraction(registryElements, ninServiceManager);
            }
        }
    })(Interactions = Hydra.Interactions || (Hydra.Interactions = {}));
})(Hydra || (Hydra = {}));
//# sourceMappingURL=Hydra.Interactions.Init.js.map