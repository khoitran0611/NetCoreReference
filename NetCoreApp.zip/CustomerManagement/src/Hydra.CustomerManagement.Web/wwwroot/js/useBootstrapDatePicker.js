﻿$(function () {
    $('.input-group.date').datetimepicker({
        locale: 'en-gb',
        format: 'YYYY-MM-DD'
    });
});