﻿// NOTE: This validator won't work if it is put in document.ready
//
$.validator.unobtrusive.adapters.add('swedenninvalidation', [], function (options) {
    options.rules['swedenninvalidation'] = options.params;
    options.messages['swedenninvalidation'] = options.message;
});
$.validator.addMethod('swedenninvalidation', function (value, element, params) {
    let nin = $(element).inputmask('unmaskedvalue');
    return 10 <= nin.length && nin.length <= 12;
});

// Interactions
$(document).ready(function () {
    if (typeof Hydra.Interactions.Init === 'function') {
        Hydra.Interactions.Init();
    }
});