$(function () {
    $('.input-group.date').datetimepicker({
        locale: 'en-gb',
        format: 'YYYY-MM-DD'
    });
});
$(document).ready(function () {
    $('[data-inputmask]').inputmask();
});