﻿$(document).ready(function () {
    $('[data-inputmask]').inputmask();
});