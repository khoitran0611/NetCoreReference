﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using AutoMapper;
using CentralSequences.Client;
using Hangfire;
using Hangfire.MemoryStorage;
using Hydra.Common.AspNetCore.Http.Cors;
using Hydra.Common.AspNetCore.Http.Integration;
using Hydra.Common.Integration.Http;
using Hydra.CustomerManagement.Web.IntegrationEventHandlers;
using Hydra.CustomerManagement.Web.ModelBinding;
using Hydra.CustomerManagement.Web.ResourceMapping;
using Hydra.CustomerManagement.Web.Services;
using Hydra.MotorRegistry.Client.CountrySpecific.Sweden;
using IdentityModel;
using IdentityServer4.AccessTokenValidation;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication.OpenIdConnect;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.Tokens;
using Morcatko.AspNetCore.JsonMergePatch;
using Newtonsoft.Json.Linq;
using Swashbuckle.AspNetCore.Swagger;

namespace Hydra.CustomerManagement.Web
{
    public class Startup
    {
        private const string ApplicationName = "CustomerManagement";
        private const string AuthenticationSchemeCustomer = "customer";

        public Startup(IConfiguration configuration, ILoggerFactory loggerFactory)
        {
            Configuration = configuration;
            LoggerFactory = loggerFactory;
        }

        public IConfiguration Configuration { get; }
        public ILoggerFactory LoggerFactory { get; }
        private string ApiName => Configuration.GetValue<string>("ApiName");
        private string AuthorityUri => Configuration.GetValue<string>("OpenIdConnect:Authority");

        private string CustomerAuthenticationAuthorityUri => Configuration.GetValue<string>("CustomerAuthentication-Authority");

        private bool IsCustomerAuthenticationAuthorityEnabled => Configuration.GetValue<bool>("CustomerAuthenticationAuthorityEnabled", false);

        public virtual void ConfigureServices(IServiceCollection services)
        {
            services.Configure<CookiePolicyOptions>(options =>
            {
                options.CheckConsentNeeded = context => false;
                options.MinimumSameSitePolicy = SameSiteMode.Strict;
            });

            AddAuthentication(services);

            AddIntegrationServices(services);
            AddSwagger(services);

            services.AddHangfire(x =>
            {
                x.UseMemoryStorage();
            });
            services.AddTransient<IBlacklistingJobMonitor, BlacklistingJobStatusMonitor>();
            services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();

            services
                .AddCustomerManagementCoreServices()
                .AddSwedenSpecificServices()
                .AddRavenStoreServices(Configuration)
                .AddHydraTelemetry(Configuration.GetSection("Telemetry"));

            services.AddMvc(setupAction =>
            {
                setupAction.ReturnHttpNotAcceptable = true;
                setupAction.Filters.Add(new AutoValidateAntiforgeryTokenAttribute());
                setupAction.ModelBinderProviders.Insert(0, new DateTimeOffsetModelBinderProvider());
            })
            .AddJsonMergePatch()
            .SetCompatibilityVersion(CompatibilityVersion.Version_2_1);

            services.Configure<CorsConfiguration>(Configuration.GetSection("Cors"));
            services
                .AddCors()
                .AddAutoMapper()
                .AddApiVersioning(setupAction =>
                {
                    setupAction.ReportApiVersions = true;
                    setupAction.AssumeDefaultVersionWhenUnspecified = true;
                });
            SetAutoMapperProfilesForApi();

            services.Configure<EventBusSubscriber.SubscriberOptions>(Configuration.GetSection("EventBusSubscriber"));
        }

        public virtual void Configure(IApplicationBuilder app, IHostingEnvironment env, ILoggerFactory loggerFactory)
        {
            app.UseReverseProxyHeaderForwarding(Configuration, loggerFactory);
            app.UsePathBase(Configuration.GetValue<string>("CustomerManagement:PathBase", "/CustomerManagement"));

            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler($"/Home/Error");
                app.UseHsts();
            }

            app
                .UseAuthentication() // Authentication before Global resources or User won't be populated in HttpContext and we won't get the locale claim for localization
                .UseGlobalResourcesLocalization()
                .UseHydraTelemetry(builder => builder
                    .WithStandardTags(ApplicationName)
                    .WithFilteringOutOfFastDependencies()
                    .WithHttp400sNotAsFailure()
                    .Build());

            app.UseHangfireDashboard();
            app.UseHangfireServer(new BackgroundJobServerOptions
            {
                WorkerCount = 1,
            });

            var corsConfiguration = Configuration.GetSection("Cors").Get<CorsConfiguration>();
            app.UseCors(corsConfiguration.Build);

            UseSwagger(app);

            app.UseStaticFiles();

            app.UseMvc(routes =>
            {
                routes.MapRoute(
                    name: "default",
                    template: "{controller=Home}/{action=Index}/{id?}");
            });
        }

        protected virtual void AddIntegrationServices(IServiceCollection services)
        {
            services
                .AddCentralSequences(Configuration.GetSection("CentralSequencesClientOptions"))
                .AddGlobalResourcesLocalization(Configuration.GetSection("GlobalResourcesClientOptions"))
                .AddHostedService<EventBusSubscriber>()
                .AddRabbitMQEventBusServices(Configuration.GetSection("EventBusOptions"))
                .AddMotorRegistryClient()
                .AddSingleton<ITokenSource, HttpContextTokenSource>()
                .AddHttpIntegrationClients(Configuration.GetSection("ClientFactoryOptions"), AuthorityUri);

            AddInsuranceEventHandlers(services);
        }

        protected void AddInsuranceEventHandlers(IServiceCollection services)
        {
            services.AddTransient<PolicyCreatedEventHandler>();
            services.AddTransient<PolicyUpdatedEventHandler>();
            services.AddTransient<PolicyRemovedEventHandler>();
        }

        private static void SetAutoMapperProfilesForApi()
        {
            Mapper.Reset();
            Mapper.Initialize(cfg =>
            {
                cfg.AddProfile<CustomerDomainToResourceMapping>();
                cfg.AddProfile<CustomerResourceToDomainMapping>();
            });
        }

        private void AddAuthentication(IServiceCollection services)
        {
            JwtSecurityTokenHandler.DefaultInboundClaimTypeMap.Clear();
            services.AddAuthorization(options =>
            {
                options.AddPolicy(
                    AuthorisationPolicies.Api,
                    policy =>
                        policy.AddAuthenticationSchemes(GetApiAuthenticationSchemes().ToArray())
                              .RequireAuthenticatedUser());

                options.AddPolicy("ManagementApi", policy => policy
                    .AddAuthenticationSchemes(OpenIdConnectDefaults.AuthenticationScheme)
                    .RequireAuthenticatedUser()
                    .RequireRole(Roles.ConfigurationAdmin));
            });

            var authenticationBuilder = services.AddAuthentication(options =>
            {
                options.DefaultAuthenticateScheme = CookieAuthenticationDefaults.AuthenticationScheme;
                options.DefaultChallengeScheme = OpenIdConnectDefaults.AuthenticationScheme;
                options.DefaultSignInScheme = CookieAuthenticationDefaults.AuthenticationScheme;
            })
            .AddCookie(options => options.SlidingExpiration = true)
            .AddOpenIdConnect(options =>
            {
                Configuration.GetSection("OpenIdConnect").Bind(options);
                options.Events = new OpenIdConnectEvents()
                {
                    OnUserInformationReceived = (context) =>
                    {
                        ClaimsIdentity claimsId = context.Principal.Identity as ClaimsIdentity;

                        var roles = context.User.Children().FirstOrDefault(j => j.Path == JwtClaimTypes.Role).Values().ToList();
                        claimsId.AddClaims(roles.Select(r => new Claim(JwtClaimTypes.Role, r.Value<String>())));

                        return Task.FromResult(0);
                    }
                };
                options.TokenValidationParameters = new TokenValidationParameters
                {
                    NameClaimType = JwtClaimTypes.Name,
                    RoleClaimType = JwtClaimTypes.Role,
                };
            })
            .AddIdentityServerAuthentication(options =>
            {
                options.Authority = AuthorityUri;
                options.ApiName = ApiName;
                options.RequireHttpsMetadata = Configuration.GetValue<bool>("RequireHttpsMetadata");
            });
            if (IsCustomerAuthenticationAuthorityEnabled)
            {
                LoggerFactory.CreateLogger<Startup>().LogInformation("Enabling Customer Authentication at '{0}'", CustomerAuthenticationAuthorityUri);
                authenticationBuilder.AddIdentityServerAuthentication(AuthenticationSchemeCustomer, options =>
                {
                    options.ApiName = ApiName;
                    options.Authority = CustomerAuthenticationAuthorityUri;
                    options.RequireHttpsMetadata = false;
                });
            }
        }

        private IEnumerable<string> GetApiAuthenticationSchemes()
        {
            yield return OpenIdConnectDefaults.AuthenticationScheme;
            yield return IdentityServerAuthenticationDefaults.AuthenticationScheme;
            if (IsCustomerAuthenticationAuthorityEnabled)
            {
                yield return AuthenticationSchemeCustomer;
            }
        }

        private void AddSwagger(IServiceCollection services)
        {
            services.AddSwaggerGen(setupAction =>
            {
                setupAction.SwaggerDoc("v1", new Info
                {
                    Version = "v1",
                    Title = "CustomerManagement API",
                    Description = "Service for registering and getting customer info."
                });

                setupAction.OperationFilter<JsonMergePatchDocumentOperationFilter>();

                setupAction.AddSecurityDefinition("OAuth2", new OAuth2Scheme
                {
                    Type = "oauth2",
                    Flow = "implicit",
                    AuthorizationUrl = new Uri(new Uri(AuthorityUri), $"/connect/authorize").AbsoluteUri,
                    Scopes = new Dictionary<string, string>
                    {
                        { ApiName, "CustomerManagement API Scope" }
                    }
                });

                setupAction.AddSecurityRequirement(new Dictionary<string, IEnumerable<string>>
                {
                   { "OAuth2", new string[]{ } }
                });
            });
        }

        private void UseSwagger(IApplicationBuilder app)
        {
            app.UseSwagger();
            app.UseSwaggerUI(setupAction =>
            {
                setupAction.SwaggerEndpoint($"/swagger/v1/swagger.json", "CustomerManagement API V1");
                setupAction.OAuthClientId("your-client-id");
            });
        }
    }
}