﻿using System;
using AutoMapper;
using CustomerManagement.IntegrationEvents;
using Hydra.Common.Integration.EventBus.Events;
using Hydra.CustomerManagement.Web.Domain;
using Hydra.CustomerManagement.Web.Domain.SwedenPrivateLines;
using Hydra.CustomerManagement.Web.Models.SwedenPrivateLines;
using Integration = CustomerManagement.IntegrationEvents.Entities;

namespace Hydra.CustomerManagement.Web.Mappings
{
    public class SwedenPrivateLinesCustomerMappingsProfile : Profile
    {
        public SwedenPrivateLinesCustomerMappingsProfile()
        {
            MapViewModelToCustomer();
            MapCustomerToViewModel();
            MapEventEntities();
            MapCustomerCreatedEvent();
            MapCustomerUpdatedEvent();            
        }

        private void MapViewModelToCustomer()
        {
            CreateMap<SwedenPrivateLinesCustomerViewModel, SwedenPrivateLinesCustomer>()
                .ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.CustomerId))
                .ForMember(dest => dest.Type, opt => opt.UseValue("Customers"))
                .ForMember(dest => dest.SourceName, opt => opt.MapFrom(src => src.SourceName))
                .ForMember(dest => dest.CustomerNames, opt => opt.MapFrom(src => src.CustomerNames))
                .ForMember(dest => dest.CustomerDetails, opt => opt.MapFrom(src => src.CustomerDetails))
                .ForMember(dest => dest.DefaultAddressDetails, opt => opt.MapFrom(src => src.DefaultAddressDetails))
                .ForMember(dest => dest.InsuranceDefaults, opt => opt.MapFrom(src => src.InsuranceDefaults))
                .ForMember(dest => dest.AdditionalDetails, opt => opt.MapFrom(src => src.AdditionalDetails))
                .ForMember(dest => dest.ContactMotorRegistry, opt => opt.MapFrom(src => src.ContactMotorRegistryFlag));
        }        

        private void MapCustomerToViewModel()
        {
            CreateMap<SwedenPrivateLinesCustomer, SwedenPrivateLinesCustomerViewModel>()
                .ForMember(dest => dest.CustomerId, opt => opt.MapFrom(src => src.Id))
                .ForMember(dest => dest.CustomerNames, opt => opt.MapFrom(src => src.CustomerNames))
                .ForMember(dest => dest.CustomerDetails, opt => opt.MapFrom(src => src.CustomerDetails))
                .ForMember(dest => dest.DefaultAddressDetails, opt => opt.MapFrom(src => src.DefaultAddressDetails))
                .ForMember(dest => dest.InsuranceDefaults, opt => opt.MapFrom(src => src.InsuranceDefaults))
                .ForMember(dest => dest.AdditionalDetails, opt => opt.MapFrom(src => src.AdditionalDetails))
                .ForMember(dest => dest.ContactMotorRegistry, opt => opt.MapFrom(src => ContactMotorRegistryFalgToOption(src)));
        }

        private string ContactMotorRegistryFalgToOption(SwedenPrivateLinesCustomer src)
        {
            return src.ContactMotorRegistry ? SwedenPrivateLinesCustomerViewModel.ContactMotorRegistryOptionYes : SwedenPrivateLinesCustomerViewModel.ContactMotorRegistryOptionNo;
        }

        private void MapEventEntities()
        {
            CreateMap<CustomerNames, Integration.CustomerNames>();
            CreateMap<CustomerDetails, Integration.CustomerDetails>();
            CreateMap<AddressDetails, Integration.AddressDetails>();
            CreateMap<InsuranceDefaults, Integration.InsuranceDefaults>();

            CreateMap<SwedenPrivateLinesCustomer, Integration.CustomerInformation>()
                .ForMember(dest => dest.CustomerId, opt => opt.MapFrom(src => src.Id))
                .ForMember(dest => dest.CustomerReference, opt => opt.MapFrom(src => src.Reference))
                .ForMember(dest => dest.CustomerType, opt => opt.UseValue("PL"));

            CreateMap<SwedenPrivateLinesCustomer, EventMetaData>()
                .ForMember(dest => dest.CorrelationId, opt => opt.UseValue(Guid.NewGuid()))
                .ForMember(dest => dest.Scope, opt => opt.UseValue(string.Empty));

            CreateMap<PolicySummary, Integration.PolicySummary>();
        }

        private void MapCustomerCreatedEvent()
        {
            CreateMap<SwedenPrivateLinesCustomer, CustomerCreatedEvent>()
                .ForMember(dest => dest.EventUuid, opt => opt.UseValue(Guid.NewGuid()))
                .ForMember(dest => dest.CustomerInformation, opt => opt.MapFrom(src => src))
                .ForMember(dest => dest.MetaData, opt => opt.MapFrom(src => src))
                .ForMember(dest => dest.CustomerNames, opt => opt.MapFrom(src => src.CustomerNames))
                .ForPath(dest => dest.CustomerNames.FullName, opt => opt.MapFrom(
                    src => $"{src.CustomerNames.FirstName.Trim()} {src.CustomerNames.LastName.Trim()}"))
                .ForMember(dest => dest.CustomerDetails, opt => opt.MapFrom(src => src.CustomerDetails))
                .ForMember(dest => dest.DefaultAddressDetails, opt => opt.MapFrom(src => src.DefaultAddressDetails))
                .ForMember(dest => dest.InsuranceDefaults, opt => opt.MapFrom(src => src.InsuranceDefaults));
        }

        private void MapCustomerUpdatedEvent()
        {
            CreateMap<SwedenPrivateLinesCustomer, CustomerUpdatedEvent>()
                .ForMember(dest => dest.EventUuid, opt => opt.UseValue(Guid.NewGuid()))
                .ForMember(dest => dest.CustomerInformation, opt => opt.MapFrom(src => src))
                .ForMember(dest => dest.MetaData, opt => opt.MapFrom(src => src))
                .ForMember(dest => dest.CustomerNames, opt => opt.MapFrom(src => src.CustomerNames))
                .ForPath(dest => dest.CustomerNames.FullName, opt => opt.MapFrom(
                    src => $"{src.CustomerNames.FirstName.Trim()} {src.CustomerNames.LastName.Trim()}"))
                .ForMember(dest => dest.CustomerDetails, opt => opt.MapFrom(src => src.CustomerDetails))
                .ForMember(dest => dest.DefaultAddressDetails, opt => opt.MapFrom(src => src.DefaultAddressDetails))
                .ForMember(dest => dest.InsuranceDefaults, opt => opt.MapFrom(src => src.InsuranceDefaults));
        }
    }
}