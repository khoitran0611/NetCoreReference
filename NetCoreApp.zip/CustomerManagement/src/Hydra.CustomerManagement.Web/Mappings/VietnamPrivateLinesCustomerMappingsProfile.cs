﻿using AutoMapper;

namespace Hydra.CustomerManagement.Web.Mappings
{
    public class VietnamPrivateLinesCustomerMappingsProfile : Profile
    {
        public VietnamPrivateLinesCustomerMappingsProfile()
        {
            // Create the code
        }
    }
}