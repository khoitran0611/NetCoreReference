﻿using System;
using System.Linq;
using CsvHelper.Configuration;
using Hydra.CustomerManagement.Web.Services;

namespace Hydra.CustomerManagement.Web.Mappings
{
    public class BlacklistedNinMap : ClassMap<BlacklistedNin>
    {
        public BlacklistedNinMap()
        {
            Map(m => m.Nin).Index(0);
        }
    }
}