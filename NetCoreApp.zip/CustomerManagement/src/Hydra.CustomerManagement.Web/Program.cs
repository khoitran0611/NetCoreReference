﻿using System;
using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Serilog;

namespace Hydra.CustomerManagement.Web
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var host = BuildWebHost(args);
            host.Run();
        }

        public static IWebHost BuildWebHost(string[] args) =>
            WebHost.CreateDefaultBuilder(args)
            .UseUrls("http://*:60001")
            .ConfigureLogging((context, logging) =>
            {
                logging.ClearProviders();
                logging.AddConfiguration(context.Configuration.GetSection("Logging"));
                logging.AddConsole();
                logging.AddDebug();
                logging.AddSerilog(CreateSerilogLogger(context.Configuration), dispose: true);
            })
            .UseStartup<Startup>()
            .Build();

        private static Serilog.Core.Logger CreateSerilogLogger(IConfiguration config)
        {
            const int FileSizeLimit20MB = 20_971_520;
            return new LoggerConfiguration()
                .Enrich.FromLogContext()
                .MinimumLevel.Verbose()
                .WriteTo
                    .RollingFile(
                        config.GetValue("Logging:RollingFile:FilePath", "logs/CM-rolling_log-{Date}.txt"),
                        fileSizeLimitBytes: FileSizeLimit20MB,
                        retainedFileCountLimit: config.GetValue("Logging:RollingFile:RetainedFileCountLimit", 10),
                        buffered: config.GetValue("Logging:RollingFile:IsBuffered", true),
                        flushToDiskInterval: config.GetValue("Logging:RollingFile:FlushToDiskIntervalInSeconds", TimeSpan.FromSeconds(5)))
                .CreateLogger();
        }
    }
}