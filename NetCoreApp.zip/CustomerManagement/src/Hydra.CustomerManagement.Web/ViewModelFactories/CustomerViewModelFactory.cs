﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Hydra.CustomerManagement.Web.Domain.SwedenPrivateLines;
using Hydra.CustomerManagement.Web.I18n;
using Hydra.CustomerManagement.Web.Mappers;
using Hydra.CustomerManagement.Web.Models;
using Hydra.CustomerManagement.Web.Models.SwedenPrivateLines;
using Hydra.CustomerManagement.Web.Models.VietnamPrivateLines;
using Hydra.GlobalResources.Client;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Localization;

namespace Hydra.CustomerManagement.Web.ViewModelFactories
{
    public class CustomerViewModelFactory
    {
        private readonly ICustomerMapper customerMapper;
        private readonly IGlobalResourcesClient globalResourcesClient;

        public CustomerViewModelFactory(
            ICustomerMapper customerMapper,
            IGlobalResourcesClient globalResourcesClient,
            IStringLocalizer localizer)
        {
            this.customerMapper = customerMapper;
            this.globalResourcesClient = globalResourcesClient;
            ResourceStrings.Initialise(localizer);
        }

        public async Task<SwedenPrivateLinesCustomerViewModel> GetSwedenPrivateLinesCreateCustomerViewModel(string identificationNumber, bool isEmbedded, bool usePostMessage, string[] linkParameters, HttpContext httpContext)
        {
            var viewModel = new SwedenPrivateLinesCustomerViewModel
            {
                CustomerId = Guid.NewGuid(),
                DefaultAddressDetails = new AddressDetails() { AddressId = Guid.NewGuid() },
                IsEmbedded = isEmbedded,
                LinkParameters = linkParameters,
                UsePostMessage = usePostMessage,
            };

            viewModel.CustomerDetails.IdentificationNumber = identificationNumber;

            PopulateLists(viewModel);
            await SetReturnLinks(viewModel, httpContext, linkParameters);
            return viewModel;
        }

        public async Task<SwedenPrivateLinesCustomerViewModel> GetSwedenPrivateLinesCustomerViewModelFromCustomer(SwedenPrivateLinesCustomer customer, bool isEmbedded, HttpContext httpContext)
        {
            var viewModel = customerMapper.MapToViewModel(customer, true);
            viewModel.IsEmbedded = isEmbedded;
            PopulateLists(viewModel);
            await SetReturnLinks(viewModel, httpContext, Enumerable.Empty<object>());
            return viewModel;
        }

        public SwedenPrivateLinesCustomer GetCustomerFromViewModel(SwedenPrivateLinesCustomerViewModel viewModel)
        {
            return customerMapper.MapToCustomer(viewModel);
        }

        public VietnamPrivateLinesCustomerViewModel GetVietnamPrivateLinesCustomerViewModel(bool isEmbedded)
        {
            return new VietnamPrivateLinesCustomerViewModel()
            {
                IsEmbedded = isEmbedded
            };
        }

        public void FillNonPostedModelData(SwedenPrivateLinesCustomerViewModel viewModel, ModelStateDictionary modelState)
        {
            PopulateLists(viewModel);
        }

        public void UpdateCustomerFromViewModel(
            SwedenPrivateLinesCustomerViewModel viewModel,
            SwedenPrivateLinesCustomer customerFromRepository)
        {
            var isBlackListed = customerFromRepository.CustomerDetails.IsBlacklisted;
            customerMapper.UpdateCustomerProperties(viewModel, customerFromRepository);
            customerFromRepository.CustomerDetails.IsBlacklisted = isBlackListed;
        }

        private void PopulateLists(SwedenPrivateLinesCustomerViewModel viewModel)
        {
            viewModel.PaymentMethods = GetPaymentMethods();
            SetSelectedByValue(viewModel.PaymentMethods, viewModel.InsuranceDefaults.PaymentMethod ?? SwedenPrivateLinesCustomerViewModel.PaymentMethodMonthlyGiro);

            viewModel.MotorRegistryContactOptions = GetContactMotorRegistryOptions();
            SetSelectedByValue(viewModel.MotorRegistryContactOptions, viewModel.ContactMotorRegistry ?? SwedenPrivateLinesCustomerViewModel.ContactMotorRegistryOptionYes);
        }

        private async Task SetReturnLinks(SwedenPrivateLinesCustomerViewModel viewModel, HttpContext httpContext, IEnumerable<object> extraParameters)
        {
            viewModel.ReturnSystemId = httpContext.Request.Query["returnSystemId"].ToString();
            viewModel.ReturnSuccessLink = httpContext.Request.Query["returnSuccessLink"].ToString();

            if (!string.IsNullOrEmpty(viewModel.ReturnSystemId))
            {
                var returnSuccessLinkValue = httpContext.Request.Query["returnSuccessLink"].ToString();
                var returnCancelLinkValue = httpContext.Request.Query["returnCancelLink"].ToString();

                var parameters = new object[]
                {
                    viewModel.CustomerId,
                    viewModel.SourceName
                }
                .Concat(extraParameters)
                .ToArray();
                viewModel.ReturnSuccessLink = await globalResourcesClient.ResolveLink(viewModel.ReturnSystemId, returnSuccessLinkValue, parameters);
                viewModel.ReturnCancelLink = await globalResourcesClient.ResolveLink(viewModel.ReturnSystemId, returnCancelLinkValue, parameters);
            }
        }

        private SelectList GetPaymentMethods()
        {
            var items = new List<SelectListItem>
           {
               new SelectListItem { Value= SwedenPrivateLinesCustomerViewModel.PaymentMethodAnnualGiro, Text= ResourceStrings.PaymentMethods.AnnualGiro },
               new SelectListItem { Value= SwedenPrivateLinesCustomerViewModel.PaymentMethodMonthlyGiro, Text= ResourceStrings.PaymentMethods.MonthlyGiro }
            };
            return new SelectList(items);
        }

        private SelectList GetContactMotorRegistryOptions()
        {
            var items = new List<SelectListItem>
            {
               new SelectListItem { Value= SwedenPrivateLinesCustomerViewModel.ContactMotorRegistryOptionYes, Text= ResourceStrings.DisplayOptions.Yes },
               new SelectListItem { Value= SwedenPrivateLinesCustomerViewModel.ContactMotorRegistryOptionNo, Text= ResourceStrings.DisplayOptions.No }
            };
            return new SelectList(items);
        }

        private void SetSelectedByValue(SelectList selectList, string value)
        {
            var items = (List<SelectListItem>)selectList.Items;
            items.Single(item => item.Value == value).Selected = true;
        }
    }
}