﻿using System;
using AutoMapper;
using CustomerManagement.IntegrationEvents;
using CustomerManagement.IntegrationEvents.Entities;
using Hydra.Common.CountrySpecific;
using Hydra.CustomerManagement.Web.Domain.SwedenPrivateLines;

namespace Hydra.CustomerManagement.Web.Mappers
{
    public interface ICustomerEventsMapper
    {
        CustomerCreatedEvent MapToCustomerCreatedEvent(SwedenPrivateLinesCustomer customer, Guid scope, string salesPersonName, string correlationId);

        CustomerUpdatedEvent MapToCustomerUpdatedEvent(SwedenPrivateLinesCustomer customer, Guid scope, string salesPersonName, string correlationId);

        CustomerPolicyAddedEvent MapToCustomerPolicyAddedEvent(string customerId, int version, Domain.PolicySummary policy, string correlationId);

        CustomerPolicyUpdatedEvent MapToCustomerPolicyUpdatedEvent(string customerId, int version, Domain.PolicySummary policy, string correlationId);

        CustomerPolicyRemovedEvent MapToCustomerPolicyRemovedEvent(string customerId, int version, Guid policyId, string correlationId);
    }

    public class CustomerEventsMapper : ICustomerEventsMapper
    {
        private readonly IMapper mapper;
        private readonly ICountryIntegrationClock systemClock;

        public CustomerEventsMapper(
            IMapper mapper,
            ICountryIntegrationClock systemClock)
        {
            this.mapper = mapper;
            this.systemClock = systemClock;
        }

        public CustomerCreatedEvent MapToCustomerCreatedEvent(SwedenPrivateLinesCustomer customer, Guid scope, string salesPersonName, string correlationId)
        {
            var customerCreatedEvent = mapper.Map<SwedenPrivateLinesCustomer, CustomerCreatedEvent>
                (customer, opt => opt.AfterMap((src, dest) =>
                {
                    dest.CreationDate = systemClock.GetNow();
                    dest.MetaData.CorrelationId = correlationId;
                    dest.MetaData.Scope = scope.ToString();
                    dest.SalesPersonName = salesPersonName;
                    dest.CustomerDetails.LeadContext = scope;
                }));
            return customerCreatedEvent;
        }

        public CustomerUpdatedEvent MapToCustomerUpdatedEvent(SwedenPrivateLinesCustomer customer, Guid scope, string salesPersonName, string correlationId)
        {
            var customerUpdatedEvent = mapper.Map<SwedenPrivateLinesCustomer, CustomerUpdatedEvent>
                (customer, opt => opt.AfterMap((src, dest) =>
                {
                    dest.CreationDate = systemClock.GetNow();
                    dest.MetaData.CorrelationId = correlationId;
                    dest.MetaData.Scope = scope.ToString();
                    dest.SalesPersonName = salesPersonName;
                    dest.CustomerDetails.LeadContext = scope;
                }));
            return customerUpdatedEvent;
        }

        public CustomerPolicyAddedEvent MapToCustomerPolicyAddedEvent(string customerId, int version, Domain.PolicySummary policy, string correlationId)
        {
            var policyAddedEvent = new CustomerPolicyAddedEvent
            {
                CustomerId = customerId,
                Version = version,
                NewPolicy = mapper.Map<Domain.PolicySummary, PolicySummary>(policy),
            };
            policyAddedEvent.WithMetaData(
                correlationId,
                policy.Scope,
                policy.OrganisationContext);

            return policyAddedEvent;
        }

        public CustomerPolicyUpdatedEvent MapToCustomerPolicyUpdatedEvent(string customerId, int version, Domain.PolicySummary policy, string correlationId)
        {
            var policyUpdatedEvent = new CustomerPolicyUpdatedEvent
            {
                CustomerId = customerId,
                Version = version,
                UpdatedPolicy = mapper.Map<Domain.PolicySummary, PolicySummary>(policy),
            };
            policyUpdatedEvent.WithMetaData(
                correlationId,
                policy.Scope,
                policy.OrganisationContext);

            return policyUpdatedEvent;
        }

        public CustomerPolicyRemovedEvent MapToCustomerPolicyRemovedEvent(string customerId, int version, Guid policyId, string correlationId)
        {
            var policyRemovedEvent = new CustomerPolicyRemovedEvent
            {
                CustomerId = customerId,
                Version = version,
                RemovedPolicyId = policyId,
            };
            policyRemovedEvent.WithMetaData(
                correlationId,
                string.Empty,
                string.Empty);

            return policyRemovedEvent;
        }
    }
}