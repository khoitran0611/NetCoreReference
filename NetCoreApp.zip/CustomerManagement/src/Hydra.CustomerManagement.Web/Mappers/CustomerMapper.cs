﻿using AutoMapper;
using Hydra.CustomerManagement.Web.Domain.SwedenPrivateLines;
using Hydra.CustomerManagement.Web.Models.SwedenPrivateLines;

namespace Hydra.CustomerManagement.Web.Mappers
{
    public interface ICustomerMapper
    {
        SwedenPrivateLinesCustomer MapToCustomer(SwedenPrivateLinesCustomerViewModel viewModel);

        SwedenPrivateLinesCustomerViewModel MapToViewModel(SwedenPrivateLinesCustomer customer, bool isUpdating);

        void UpdateCustomerProperties(SwedenPrivateLinesCustomerViewModel viewModel, SwedenPrivateLinesCustomer customerFromRepository);
    }

    public class CustomerMapper : ICustomerMapper
    {
        private readonly IMapper mapper;

        public CustomerMapper(
            IMapper mapper)
        {
            this.mapper = mapper;
        }

        public SwedenPrivateLinesCustomer MapToCustomer(SwedenPrivateLinesCustomerViewModel viewModel)
        {
            var customer = mapper.Map<SwedenPrivateLinesCustomerViewModel, SwedenPrivateLinesCustomer>(viewModel, opt =>
                opt.BeforeMap((src, dest) =>
                {
                    src.DefaultAddressDetails.IsDefault = true;
                    src.DefaultAddressDetails.Country = "SE";
                    src.InsuranceDefaults.RenewalMode = "Automatic";
                }));
            return customer;
        }

        public SwedenPrivateLinesCustomerViewModel MapToViewModel(SwedenPrivateLinesCustomer customer, bool isUpdating)
        {
            var viewModel = mapper.Map<SwedenPrivateLinesCustomer, SwedenPrivateLinesCustomerViewModel>(customer, opt =>
                opt.AfterMap((src, dest) =>
                {
                    dest.IsUpdating = isUpdating;
                }));
            return viewModel;
        }

        public void UpdateCustomerProperties(SwedenPrivateLinesCustomerViewModel viewModel, SwedenPrivateLinesCustomer customerFromRepository)
        {
            mapper.Map(viewModel, customerFromRepository);
        }
    }
}