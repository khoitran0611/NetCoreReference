﻿using System;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc.ModelBinding;

namespace Hydra.CustomerManagement.Web.ModelBinding
{
    public class DateTimeOffsetModelBinder : IModelBinder
    {
        public static readonly Type[] SupportedTypes = new[] { typeof(DateTimeOffset), typeof(DateTimeOffset?) };
        public static readonly string DateFormat = "yyyy-MM-dd";

        public Task BindModelAsync(ModelBindingContext bindingContext)
        {
            if (bindingContext == null)
            {
                throw new ArgumentNullException(nameof(bindingContext));
            }

            if (!SupportedTypes.Contains(bindingContext.ModelType))
            {
                return Task.CompletedTask;
            }

            var modelName = bindingContext.ModelName;
            var valueProviderResult = bindingContext.ValueProvider.GetValue(modelName);
            if (valueProviderResult != ValueProviderResult.None)
            {
                bindingContext.ModelState.SetModelValue(bindingContext.ModelName, valueProviderResult);
                var valueAsString = valueProviderResult.FirstValue;
                if (string.IsNullOrEmpty(valueAsString))
                {
                    return Task.CompletedTask;
                }
                if (DateTimeOffset.TryParseExact(valueAsString, DateFormat, CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTimeOffset validDate))
                {
                    bindingContext.Result = ModelBindingResult.Success(validDate);
                }
            }
            return Task.CompletedTask;
        }
    }
}