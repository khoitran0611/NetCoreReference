﻿using System;
using System.Linq;
using Microsoft.AspNetCore.Mvc.ModelBinding;

namespace Hydra.CustomerManagement.Web.ModelBinding
{
    public class DateTimeOffsetModelBinderProvider : IModelBinderProvider
    {
        public IModelBinder GetBinder(ModelBinderProviderContext context)
        {
            if (DateTimeOffsetModelBinder.SupportedTypes.Contains(context.Metadata.ModelType))
            {
                return new Microsoft.AspNetCore.Mvc.ModelBinding.Binders.BinderTypeModelBinder(typeof(DateTimeOffsetModelBinder));
            }
            return null;
        }
    }
}