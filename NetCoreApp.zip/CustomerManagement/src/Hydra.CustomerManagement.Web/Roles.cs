﻿using System;
using System.Linq;

namespace Hydra.CustomerManagement.Web
{
    public static class Roles
    {
        public const string ConfigurationAdmin = "Configuration Admin";
    }
}