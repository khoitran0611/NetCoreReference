﻿namespace Hydra.CustomerManagement.Web
{
    public static class AuthorisationPolicies
    {
        public const string Api = "api";
    }
}