﻿using System;
using CustomerManagement.IntegrationEvents.Entities;

namespace CustomerManagement.IntegrationEvents
{
    public class CustomerPolicyAddedEvent : VersionedIntegrationEvent
    {
        public override DateTimeOffset CreationDate { get; set; } = DateTimeOffset.Now;

        public string CustomerId { get; set; }
        public PolicySummary NewPolicy { get; set; }        
    }
}