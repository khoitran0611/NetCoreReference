﻿namespace CustomerManagement.IntegrationEvents.Entities
{
    public class CustomerInformation
    {
        public string CustomerType { get; set; }
        public string CustomerId { get; set; }
        public string CustomerReference { get; set; }
        public string SourceName { get; set; }
    }
}