﻿using System;

namespace CustomerManagement.IntegrationEvents.Entities
{
    public class CustomerDetails
    {
        public string IdentificationNumber { get; set; }
        public string TelephoneNumber { get; set; }
        public string MobileNumber { get; set; }
        public string Email { get; set; }
        public Guid LeadContext { get; set; }
        public string ParentOrganisationNumber { get; set; }
        public DateTimeOffset? DateOfBirth { get; set; }
        public bool IsBlacklisted { get; set; }
    }
}