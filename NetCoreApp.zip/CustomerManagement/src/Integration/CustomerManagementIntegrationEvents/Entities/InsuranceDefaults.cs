﻿namespace CustomerManagement.IntegrationEvents.Entities
{
    public class InsuranceDefaults
    {
        public string RenewalMode { get; set; }
        public string PaymentMethod { get; set; }
        public string InvoiceEmail { get; set; }
        public bool PrintedInvoice { get; set; }
        public string BankAccountNumber { get; set; }
    }
}