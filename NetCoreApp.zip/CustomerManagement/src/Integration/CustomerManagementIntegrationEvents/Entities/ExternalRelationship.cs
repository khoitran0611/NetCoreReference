﻿namespace CustomerManagement.IntegrationEvents.Entities
{
    public class ExternalRelationship
    {
        public string RelationshipName { get; set; }
        public string RelationshipId { get; set; }
    }
}