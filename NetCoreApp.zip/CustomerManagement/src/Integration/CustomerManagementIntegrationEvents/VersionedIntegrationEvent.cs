﻿using Hydra.Common.Integration.EventBus.Events;

namespace CustomerManagement.IntegrationEvents
{
    public abstract class VersionedIntegrationEvent : BaseIntegrationEvent
    {
        public int Version { get; set; }
    }
}