﻿using System;
using CustomerManagement.IntegrationEvents.Entities;

namespace CustomerManagement.IntegrationEvents
{
    public class CustomerPolicyUpdatedEvent : VersionedIntegrationEvent
    {
        public override DateTimeOffset CreationDate { get; set; } = DateTimeOffset.Now;

        public string CustomerId { get; set; }
        public PolicySummary UpdatedPolicy { get; set; }
    }
}