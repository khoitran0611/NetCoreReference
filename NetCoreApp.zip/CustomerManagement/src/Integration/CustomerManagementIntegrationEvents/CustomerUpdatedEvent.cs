﻿using System;
using CustomerManagement.IntegrationEvents.Entities;

namespace CustomerManagement.IntegrationEvents
{
    public class CustomerUpdatedEvent : VersionedIntegrationEvent
    {
        public override DateTimeOffset CreationDate { get; set; } = DateTimeOffset.Now;

        public CustomerInformation CustomerInformation { get; set; }
        public CustomerDetails CustomerDetails { get; set; }
        public CustomerNames CustomerNames { get; set; }
        public AddressDetails DefaultAddressDetails { get; set; }
        public AddressDetails[] NamedAddresses { get; set; }
        public InsuranceDefaults InsuranceDefaults { get; set; }
        public ExternalRelationship[] ExternalRelationships { get; set; }
        public string SalesPersonName { get; set; }
    }
}