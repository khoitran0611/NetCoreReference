﻿using System;

namespace CustomerManagement.IntegrationEvents
{
    public class CustomerPolicyRemovedEvent : VersionedIntegrationEvent
    {
        public override DateTimeOffset CreationDate { get; set; } = DateTimeOffset.Now;

        public string CustomerId { get; set; }
        public Guid RemovedPolicyId { get; set; }
    }
}