﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AngleSharp.Dom.Html;
using CustomerManagement.IntegrationEvents;
using Hydra.CustomerManagement.Web.Tests.Setup;
using Hydra.Insurance.IntegrationEvents;
using TechTalk.SpecFlow;
using TechTalk.SpecFlow.Assist;
using Xunit;

namespace Hydra.CustomerManagement.Web.Tests.Steps
{
    [Binding]
    public class PolicySteps
    {
        private const string DateFormat = "dd/MM/yyyy HH:mm";
        private readonly TestContext testContext;
        private readonly TrackPoliciesContext policiesContext;
        private readonly CustomerContext customerContext;

        public PolicySteps(TestContext testContext, TrackPoliciesContext policiesContext, CustomerContext customerContext)
        {
            this.testContext = testContext;
            this.policiesContext = policiesContext;
            this.customerContext = customerContext;
        }

        [Given(@"Some Policy was created")]
        public async Task GivenSomePolicyCreated()
        {
            var policyCreatedEvent = new PolicyCreatedEvent(
                new PolicyIdentity(customerContext.CustomerId, policiesContext.PolicyId, 1),
                new InsuredProduct(Guid.Parse("BC480D3D-7136-4903-9D4E-FCB0917B8C22"), "Test Product"),
                DateTimeOffset.ParseExact("01/01/2019 00:00", DateFormat, CultureInfo.InvariantCulture),
                DateTimeOffset.ParseExact("31/12/2019 23:59", DateFormat, CultureInfo.InvariantCulture),
                "50000155",
                new PolicyPremium(100M, "USD", "100.00$"),
                policiesContext.PartnerId);

            policyCreatedEvent.WithMetaData(Guid.NewGuid().ToString(), policiesContext.PartnerId.ToString(), policiesContext.PartnerId.ToString());

            await policiesContext.SimulatePolicyCreation(policyCreatedEvent);
        }

        [Given(@"Policy with following values was created")]
        [When(@"Policy with following values is created")]
        public async Task WhenPolicyIsCreated(Table policyDetails)
        {
            dynamic details = policyDetails.CreateDynamicInstance(doTypeConversion: false);
            var policyCreatedEvent = new PolicyCreatedEvent(
                new PolicyIdentity(customerContext.CustomerId, Guid.Parse(details.PolicyId), int.Parse(details.PolicyVersion)),
                new InsuredProduct(Guid.Parse(details.ProductProfileId), details.ProductName),
                DateTimeOffset.ParseExact(details.PolicyStart, DateFormat, CultureInfo.InvariantCulture),
                DateTimeOffset.ParseExact(details.PolicyEnd, DateFormat, CultureInfo.InvariantCulture),
                details.PolicyReference,
                new PolicyPremium(decimal.Parse(details.Amount), details.Currency, details.FormattedAmount),
                policiesContext.PartnerId);

            policyCreatedEvent.WithMetaData(Guid.NewGuid().ToString(), policiesContext.PartnerId.ToString(), policiesContext.PartnerId.ToString());

            await policiesContext.SimulatePolicyCreation(policyCreatedEvent);
        }

        [Given(@"Policy was incepted")]
        [When(@"Policy is incepted")]
        public async Task WhenPolicyIsIncepted(Table policyDetails)
        {
            dynamic details = policyDetails.CreateDynamicInstance(doTypeConversion: false);
            var policyInceptedEvent = new PolicyInceptionExecutedEvent(
                new PolicyIdentity(customerContext.CustomerId, Guid.Parse(details.PolicyId), int.Parse(details.PolicyVersion)),
                hasInceptedSuccessfully: true);

            await policiesContext.SimulatePolicyInception(policyInceptedEvent);
        }

        [Given(@"Policy premium and period was updated to")]
        [When(@"Policy premium and period is updated to")]
        public async Task WhenPolicyPremiumIsUpdated(Table policyDetails)
        {
            dynamic details = policyDetails.CreateDynamicInstance(doTypeConversion: false);

            var updatedStart = DateTimeOffset.ParseExact(details.PolicyStart, DateFormat, CultureInfo.InvariantCulture);
            var updatedEnd = DateTimeOffset.ParseExact(details.PolicyEnd, DateFormat, CultureInfo.InvariantCulture);

            var policyDetailsUpdatedEvent = new PolicyDetailsUpdatedEvent(
                new PolicyIdentity(customerContext.CustomerId, Guid.Parse(details.PolicyId), int.Parse(details.PolicyVersion)),
                new PolicyPeriodChange(DateTimeOffset.MinValue, DateTimeOffset.MaxValue, updatedStart, updatedEnd),
                new PolicyPremiumChange(
                    new PolicyPremium(0, "SEK", "0 kr"),
                    new PolicyPremium(decimal.Parse(details.Amount), details.Currency, details.FormattedAmount)));

            await policiesContext.SimulatePolicyDetailsUpdate(policyDetailsUpdatedEvent);
        }

        [When(@"Policy expires")]
        public async Task WhenPolicyExpires(Table policyDetails)
        {
            dynamic details = policyDetails.CreateDynamicInstance(doTypeConversion: false);
            var policyExpiredEvent = new PolicyExpiredEvent(
                new PolicyIdentity(customerContext.CustomerId, Guid.Parse(details.PolicyId), int.Parse(details.PolicyVersion)));

            await policiesContext.SimulatePolicyExpiry(policyExpiredEvent);
        }

        [When(@"Policy is terminated")]
        public async Task WhenPolicyIsTermianted(Table policyDetails)
        {
            dynamic details = policyDetails.CreateDynamicInstance(doTypeConversion: false);

            var updatedStart = DateTimeOffset.ParseExact(details.PolicyStart, DateFormat, CultureInfo.InvariantCulture);
            var updatedEnd = DateTimeOffset.ParseExact(details.PolicyEnd, DateFormat, CultureInfo.InvariantCulture);

            var policyTerminatedEvent = new PolicyTerminatedEvent(
                new PolicyIdentity(customerContext.CustomerId, Guid.Parse(details.PolicyId), int.Parse(details.PolicyVersion)),
                new PolicyPeriodChange(DateTimeOffset.MinValue, DateTimeOffset.MaxValue, updatedStart, updatedEnd),
                new PolicyPremiumChange(
                    new PolicyPremium(0, "SEK", "0 kr"),
                    new PolicyPremium(decimal.Parse(details.Amount), details.Currency, details.FormattedAmount)));

            await policiesContext.SimulatePolicyTermination(policyTerminatedEvent);
        }

        [When(@"Policy is cancelled")]
        public async Task WhenPolicyIsCancelled(Table policyDetails)
        {
            dynamic details = policyDetails.CreateDynamicInstance(doTypeConversion: false);
            var policyCancelledEvent = new PolicyCancelledEvent(
                new PolicyIdentity(customerContext.CustomerId, Guid.Parse(details.PolicyId), int.Parse(details.PolicyVersion)));

            await policiesContext.SimulatePolicyCancellation(policyCancelledEvent);
        }

        [Then("Published details of newly created Policy include")]
        public void ThenPublishedDetailsOfNewlyCreatedPolicyInclude(Table expectedDetails)
        {
            var actualEvent = ((CustomerPolicyAddedEvent)this.testContext.EventBus.IntegrationEvent);
            var actualPolicy = actualEvent.NewPolicy;
            AssertPolicyDetails(expectedDetails, actualPolicy);
        }


        [Then("Published details of updated Policy include")]
        public void ThenPublishedPolicyDetailsInclude(Table expectedDetails)
        {
            var actualEvent = ((CustomerPolicyUpdatedEvent)this.testContext.EventBus.IntegrationEvent);
            var actualPolicy = actualEvent.UpdatedPolicy;
            AssertPolicyDetails(expectedDetails, actualPolicy);
        }

        private static void AssertPolicyDetails(Table expectedDetails, global::CustomerManagement.IntegrationEvents.Entities.PolicySummary actualPolicy)
        {
            dynamic expectedPolicy = expectedDetails.CreateDynamicInstance(doTypeConversion: false);
            Assert.Equal(expectedPolicy.PolicyId, actualPolicy.PolicyId.ToString().ToUpperInvariant());
            Assert.Equal(expectedPolicy.Version, actualPolicy.Version.ToString());
            Assert.Equal(expectedPolicy.ProductId, actualPolicy.ProductId.ToString().ToUpperInvariant());
            Assert.Equal(expectedPolicy.ProductName, actualPolicy.ProductName);
            Assert.Equal(expectedPolicy.PolicyStart, actualPolicy.PolicyStart.ToString(DateFormat));
            Assert.Equal(expectedPolicy.PolicyEnd, actualPolicy.PolicyEnd.ToString(DateFormat));
            Assert.Equal(expectedPolicy.PolicyReference, actualPolicy.PolicyReference);
            Assert.Equal(expectedPolicy.Premium, actualPolicy.Premium.ToString("#"));
            Assert.Equal(expectedPolicy.Currency, actualPolicy.Currency);
            Assert.Equal(expectedPolicy.FormattedPremium, actualPolicy.FormattedPremium);
            Assert.Equal(expectedPolicy.IsActive, actualPolicy.IsActive.ToString());
            Assert.Equal(expectedPolicy.PartnerId, actualPolicy.PartnerId.ToString().ToUpperInvariant());
            Assert.Equal(expectedPolicy.Scope, actualPolicy.Scope.ToUpperInvariant());
            Assert.Equal(expectedPolicy.Context, actualPolicy.OrganisationContext.ToUpperInvariant());
        }
    }
}
