﻿using System.Threading.Tasks;
using AngleSharp.Dom.Html;
using Hydra.CustomerManagement.Web.Tests.Setup;
using Hydra.CustomerManagement.Web.Tests.Utilities;
using TechTalk.SpecFlow;
using Xunit;

namespace Hydra.CustomerManagement.Web.Tests.Steps
{
    [Binding]
    public sealed class CreateAndEditCustomerSteps : TechTalk.SpecFlow.Steps
    {
        private readonly CustomerContext customerContext;
        private readonly TestContext testContext;

        public CreateAndEditCustomerSteps(
            CustomerContext customerContext,
            TestContext testContext)
        {
            this.customerContext = customerContext;
            this.testContext = testContext;
        }

        [Given(@"a Sweden Private Lines form for new customer with the following values")]
        public async Task GivenASwedenPrivateLinesFormForNewCustomerWithTheFollowingValues(Table table)
        {
            var customerViewPage = await testContext.HttpClient.GetAsync("Customers/SE/PL/Create");
            var content = await HtmlHelpers.GetDocumentAsync(customerViewPage);
            customerContext.HtmlDocument = content;
            customerContext.FormValues = table;
        }

        [Given(@"Some existing Sweden Private Lines customer")]
        public async Task GivenSomeSwedenPrivateLinesCustomer()
        {
            var customerViewPage = await testContext.HttpClient.GetAsync("Customers/SE/PL/Create");
            var content = await HtmlHelpers.GetDocumentAsync(customerViewPage);

            var sampleData = new Table("ElementName", "Value");
            sampleData.AddRow("CustomerDetails.IdentificationNumber", "197811100275");
            sampleData.AddRow("CustomerDetails.DateOfBirth", "10/11/1978");
            sampleData.AddRow("CustomerNames.FirstName", "John");
            sampleData.AddRow("CustomerNames.LastName", "Smith");
            sampleData.AddRow("DefaultAddressDetails.AddressLineOne", "My address");
            sampleData.AddRow("DefaultAddressDetails.PostCode", "18600");
            sampleData.AddRow("DefaultAddressDetails.City", "Vallentuna");
            sampleData.AddRow("CustomerDetails.MobileNumber", "123456789");
            sampleData.AddRow("CustomerDetails.Email", "test@test.com");

            customerContext.HtmlDocument = content;
            customerContext.FormValues = sampleData;

            await WhenTheCustomerIsCreated();
        }

        [When(@"the customer is created")]
        public async Task WhenTheCustomerIsCreated()
        {
            var form = (IHtmlFormElement)customerContext.HtmlDocument.QuerySelector("form");
            var formValues = customerContext.FormValues;

            var customerViewPage = await testContext.HttpClient.SendAsync(form, formValues.AsKeyValuePairs());
            var content = await HtmlHelpers.GetDocumentAsync(customerViewPage);

            customerContext.HtmlDocument = content;
            customerContext.SaveCustomerId();
        }

        [Given(@"a Sweden Private Lines customer created with the following values")]
        public async Task GivenASwedenPrivateLinesCustomerCreatedWithTheFollowingValues(Table table)
        {
            await GivenASwedenPrivateLinesFormForNewCustomerWithTheFollowingValues(table);
            await WhenTheCustomerIsCreated();
        }

        [When(@"we edit the following values")]
        public async Task WhenWeEditTheFollowingValues(Table table)
        {
            var customerId = customerContext.HtmlDocument.QuerySelector("#CustomerId").Attributes["value"].Value;
            var customerEditPage = await testContext.HttpClient.GetAsync($"Customers/SE/PL/Edit/{customerId}");
            var content = await HtmlHelpers.GetDocumentAsync(customerEditPage);

            var editForm = (IHtmlFormElement)content.QuerySelector("form");

            var customerViewPage = await testContext.HttpClient.SendAsync(editForm, table.AsKeyValuePairs());
            var updatedContent = await HtmlHelpers.GetDocumentAsync(customerViewPage);

            customerContext.HtmlDocument = updatedContent;
        }

        [Then(@"the same customer opened for Edit shows the same values in the form")]
        public void ThenTheSameCustomerOpenedForEditShowsTheSameValuesInTheForm()
        {
            var expectedValues = customerContext.FormValues;
            var actualDocument = customerContext.HtmlDocument;
            var actualForm = (IHtmlFormElement)actualDocument.QuerySelector("form");
            AssertElements(expectedValues, actualForm);
        }

        [Then(@"the customer form has following details")]
        public void ThenTheCustomerFormHasFollowingDetails(Table table)
        {
            var actualDocument = customerContext.HtmlDocument;
            var actualForm = (IHtmlFormElement)actualDocument.QuerySelector("form");
            AssertElements(table, actualForm);
        }

        private void AssertElements(Table expected, IHtmlFormElement actual)
        {
            foreach (var element in expected.AsDictionary())
            {
                var actualElement = actual.QuerySelector($"[name='{element.Key}']");
                Assert.Equal(element.Value, actualElement.Attributes["value"].Value);
            }
        }
    }
}