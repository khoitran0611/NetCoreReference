﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CustomerManagement.IntegrationEvents;
using Hydra.CustomerManagement.Web.Tests.Setup;
using TechTalk.SpecFlow;
using Xunit;

namespace Hydra.CustomerManagement.Web.Tests.Steps
{
    [Binding]
    public class IntegrationEventsSteps
    {
        private readonly TestContext testContext;

        public IntegrationEventsSteps(TestContext testContext)
        {
            this.testContext = testContext;
        }

        [Then(@"the (.*) is published with version (.*)")]
        public void ThenTheEventIsPublishedWithVersion(string @event, int version)
        {
            Assert.NotNull(testContext.EventBus.IntegrationEvent);
            Assert.Equal(version, ((VersionedIntegrationEvent)testContext.EventBus.IntegrationEvent).Version);
            Assert.Equal(testContext.EventBus.IntegrationEvent.GetType().Name, @event);
        }


        [Then(@"no new events published")]
        public void ThenNoNewEventsPublished()
        {
            Assert.Null(testContext.EventBus.IntegrationEvent);
        }
    }
}
