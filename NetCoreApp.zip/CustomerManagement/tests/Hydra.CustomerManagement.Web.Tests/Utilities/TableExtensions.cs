﻿using System.Collections.Generic;
using System.Linq;
using TechTalk.SpecFlow;

namespace Hydra.CustomerManagement.Web.Tests.Utilities
{
    public static class TableExtensions
    {
        public static string[] AsStringArray(this Table table, string columnName)
        {
            return table.Rows.Select(row => row[columnName]).ToArray();
        }

        public static Dictionary<string, string> AsDictionary(this Table table)
        {
            return table.Rows.ToDictionary(column => column[0], column => column[1]);
        }

        public static KeyValuePair<string, string>[] AsKeyValuePairs(this Table table)
        {
            return table.Rows.Select(column => new KeyValuePair<string, string>(column[0], column[1])).ToArray();
        }
    }
}
