﻿using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading;
using System.Threading.Tasks;
using AngleSharp;
using AngleSharp.Dom.Html;
using AngleSharp.Network;

namespace Hydra.CustomerManagement.Web.Tests.Utilities
{
    public static class HtmlHelpers
    {
        public static async Task<IHtmlDocument> GetDocumentAsync(HttpResponseMessage response)
        {
            var content = await response.Content.ReadAsStringAsync();
            var document = await BrowsingContext.New().OpenAsync(
                virtualResponse => {
                    virtualResponse
                        .Address(response.RequestMessage.RequestUri)
                        .Status(response.StatusCode);

                    MapHeaders(virtualResponse, response.Headers);
                    MapHeaders(virtualResponse, response.Content.Headers);

                    virtualResponse.Content(content);
                }, 
                CancellationToken.None);

            return (IHtmlDocument)document;            
        }        

        private static void MapHeaders(VirtualResponse virtualResponse, HttpHeaders headers)
        {
            foreach (var header in headers)
            {
                foreach (var value in header.Value)
                {
                    virtualResponse.Header(header.Key, value);
                }
            }
        }
    }
}
