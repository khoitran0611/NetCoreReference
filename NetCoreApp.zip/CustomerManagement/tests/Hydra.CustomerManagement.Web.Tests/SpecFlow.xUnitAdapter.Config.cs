﻿// This configuration is required by SpecFlow.xUnitAdapter. See https://github.com/gasparnagy/SpecFlow.xUnitAdapter for details.

[assembly: Xunit.TestFramework("SpecFlow.xUnitAdapter.SpecFlowPlugin.SpecFlowTestFramework", "SpecFlow.xUnitAdapter.SpecFlowPlugin")]