﻿using System;
using System.Diagnostics;
using Microsoft.Extensions.Logging;
using Xunit.Abstractions;

namespace Hydra.CustomerManagement.Web.Tests
{
    public sealed class XunitLoggerProvider : ILoggerProvider
    {
        private readonly ITestOutputHelper output;

        public XunitLoggerProvider(ITestOutputHelper output)
        {
            this.output = output;
        }

        public ILogger CreateLogger(string categoryName)
        {
            return new XunitLogger(output, categoryName);
        }

        public void Dispose()
        {
            // No action needed
        }

        public sealed class XunitLogger : ILogger, IDisposable
        {
            private readonly ITestOutputHelper output;
            private readonly string categoryName;

            public XunitLogger(ITestOutputHelper output, string categoryName)
            {
                this.output = output;
                this.categoryName = categoryName;
            }

            public void Log<TState>(LogLevel logLevel, EventId eventId, TState state, Exception exception, Func<TState, Exception, string> formatter)
            {
                try
                {
                    string fakeClockTime = DateTime.Now.Date.ToString("yyyy/MM/dd");
                    string realClockTime = DateTime.Now.ToString("HH:mm:ss");
                    output.WriteLine($"{logLevel}: {realClockTime} (FakeClock={fakeClockTime}) {categoryName}");
                    output.WriteLine(formatter(state, exception));
                }
                catch (InvalidOperationException ex)
                {
                    // We can't crash while logging and ITestOutputHelper is not valid during startup when there is no active test yet
                    Debug.WriteLine($"Warning: Test Output couldn't log below message because of an error '{ex.Message}'");
                    Debug.WriteLine(formatter(state, exception));
                }
            }

            public bool IsEnabled(LogLevel logLevel)
            {
                return true;
            }

            public IDisposable BeginScope<TState>(TState state)
            {
                return this;
            }

            public void Dispose()
            {
                // No action needed
            }
        }
    }
}