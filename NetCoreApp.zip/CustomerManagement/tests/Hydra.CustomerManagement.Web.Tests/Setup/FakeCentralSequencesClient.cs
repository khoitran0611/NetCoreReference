﻿using System.Threading.Tasks;
using CentralSequences.Client;

namespace Hydra.CustomerManagement.Web.Tests.Setup
{
    public class FakeCentralSequencesClient : ICentralSequencesClient
    {
        private int value = 1000000;

        public Task<int> GetNextSequenceAsync(string key)
        {
            return Task.FromResult(++value);
        }
    }
}
