﻿using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;

namespace Hydra.CustomerManagement.Web.Tests.Setup
{
    public class AuthorizeAllRequestsMiddleware
    {
        private const string testScope = "00000000-0000-0000-0000-000000000000";
        private readonly RequestDelegate next;

        public AuthorizeAllRequestsMiddleware(RequestDelegate next)
        {
            this.next = next;
        }

        public async Task Invoke(HttpContext context)
        {
            var claims = new Claim[]
            {
                new Claim(ClaimTypes.Name, "test"),
                new Claim(ClaimTypes.NameIdentifier, "test"),
                new Claim(ClaimTypes.Email, "test@example.com"),
                new Claim(HydraClaimTypes.Tenant, testScope),
                new Claim(HydraClaimTypes.Organisation, testScope)
            };

            ClaimsIdentity claimsIdentity = new ClaimsIdentity(claims, "test");
            ClaimsPrincipal claimsPrincipal = new ClaimsPrincipal(claimsIdentity);
            context.User = claimsPrincipal;

            await this.next(context);
        }
    }
}