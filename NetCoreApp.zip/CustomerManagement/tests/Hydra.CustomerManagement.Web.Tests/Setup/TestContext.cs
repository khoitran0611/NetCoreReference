﻿using System;
using System.IO;
using System.Net.Http;
using Hydra.Common.CountrySpecific.Sweden;
using Hydra.Common.Integration.EventBus;
using Hydra.CustomerManagement.Web.Services;
using Hydra.CustomerManagement.Web.Services.Indexes;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.TestHost;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Raven.Client.Documents;
using Raven.TestDriver;
using Xunit.Abstractions;

namespace Hydra.CustomerManagement.Web.Tests.Setup
{
    public sealed class TestContext : RavenTestDriver, IDisposable
    {
        private readonly TestServer server;

        public TestContext(ITestOutputHelper testOutputHelper)
        {
            var executePath = Directory.GetCurrentDirectory();
            var path = @"..\..\..\..\..\src\Hydra.CustomerManagement.Web";
            var contentRootPath = Path.GetFullPath(Path.Combine(executePath, path));

            var webHostBuilder = new WebHostBuilder()
                .ConfigureLogging((context, builder) =>
                {
                    builder.ClearProviders();
                    builder.SetMinimumLevel(LogLevel.Debug);
                    builder.AddDebug();
                    builder.AddProvider(new XunitLoggerProvider(testOutputHelper));
                })
                .UseContentRoot(contentRootPath)
                .UseStartup(typeof(TestStartup))
                .ConfigureServices(ConfigureServices);

            server = new TestServer(webHostBuilder);

            Services = server.Host.Services;
            HttpClient = server.CreateClient();
            SwedenNinService = (ISwedenNinService)Services.GetService(typeof(ISwedenNinService));
            EventBus = (FakeEventBus)Services.GetService(typeof(IEventBus));
        }

        public IServiceProvider Services { get; private set; }

        public HttpClient HttpClient { get; }

        public ISwedenNinService SwedenNinService { get; }

        public FakeEventBus EventBus { get; }

        public override void Dispose()
        {
            base.Dispose();
            HttpClient?.Dispose();
            server?.Dispose();
        }

        protected override void PreInitialize(IDocumentStore documentStore)
        {
            base.PreInitialize(documentStore);
            documentStore.Conventions.UseOptimisticConcurrency = true;
        }

        private void ConfigureServices(IServiceCollection services)
        {
            services.AddSingleton<IRavenStoreFactory>(provider =>
                new TestRavenStoreFactory(() =>
                {
                    var store = base.GetDocumentStore(database: "CustomerManagementTest");
                    store.ExecuteIndex(new IndexSwedenPrivateLinesCustomerByNin());
                    return store;
                }
                ));
        }


    }
}