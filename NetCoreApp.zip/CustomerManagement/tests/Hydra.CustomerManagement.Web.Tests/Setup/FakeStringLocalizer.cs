﻿using System;
using System.Collections.Generic;
using System.Globalization;
using Hydra.GlobalResources.Client;
using Microsoft.Extensions.Localization;

namespace Hydra.CustomerManagement.Web.Tests.Setup
{
    public class FakeStringLocalizer : IStringLocalizer
    {
        private readonly IGlobalResourcesClient client;

        public FakeStringLocalizer(IGlobalResourcesClient client)
        {
            this.client = client;
        }

        public CultureInfo SelectedCulture { get; set; }

        public LocalizedString this[string name] => Translate(name);

        public LocalizedString this[string name, params object[] arguments] => Translate(name, arguments);

        public IEnumerable<LocalizedString> GetAllStrings(bool includeParentCultures)
        {            
            throw new NotSupportedException();
        }

        public IStringLocalizer WithCulture(CultureInfo culture)
        {
            var cultureSpecificLocalizer = new FakeStringLocalizer(client);
            cultureSpecificLocalizer.SelectedCulture = culture;

            return cultureSpecificLocalizer;
        }

        private LocalizedString Translate(string key, params object[] arguments)
        {
            var culture = this.SelectedCulture ?? System.Threading.Thread.CurrentThread.CurrentCulture;
            var translation = this.client.Translate(culture.Name, key, arguments)
                .ConfigureAwait(false)
                .GetAwaiter()
                .GetResult();
            return new LocalizedString(key, translation);
        }
    }
}
