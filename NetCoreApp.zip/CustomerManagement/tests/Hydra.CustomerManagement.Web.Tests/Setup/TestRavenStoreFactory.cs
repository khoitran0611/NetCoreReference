﻿using System;
using Hydra.CustomerManagement.Web.Services;
using Raven.Client.Documents;

namespace Hydra.CustomerManagement.Web.Tests.Setup
{
    public sealed class TestRavenStoreFactory : IRavenStoreFactory
    {
        private readonly Lazy<IDocumentStore> store;

        public TestRavenStoreFactory(Func<IDocumentStore> getDocumentStore)
        {
            store = new Lazy<IDocumentStore>(getDocumentStore);
        }

        public IDocumentStore Store => this.store.Value;

        public void Dispose()
        {
            if (this.store.IsValueCreated)
            {
                this.store.Value.Dispose();
            }
        }
    }
}