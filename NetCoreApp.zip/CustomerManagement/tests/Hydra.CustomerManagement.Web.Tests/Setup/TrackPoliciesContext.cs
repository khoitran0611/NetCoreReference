﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Hydra.CustomerManagement.Web.IntegrationEventHandlers;
using Hydra.Insurance.IntegrationEvents;

namespace Hydra.CustomerManagement.Web.Tests.Setup
{
    public class TrackPoliciesContext
    {
        private readonly PolicyCreatedEventHandler policyCreatedEventHandler;
        private readonly PolicyUpdatedEventHandler policyUpdatedEventHandler;
        private readonly PolicyRemovedEventHandler policyRemovedEventHandler;
        private readonly TestContext testContext;

        public TrackPoliciesContext(TestContext testContext)
        {
            this.policyCreatedEventHandler = (PolicyCreatedEventHandler)testContext.Services.GetService(typeof(PolicyCreatedEventHandler));
            this.policyUpdatedEventHandler = (PolicyUpdatedEventHandler)testContext.Services.GetService(typeof(PolicyUpdatedEventHandler));
            this.policyRemovedEventHandler = (PolicyRemovedEventHandler)testContext.Services.GetService(typeof(PolicyRemovedEventHandler));
            this.testContext = testContext;
        }

        public Guid PolicyHolderId { get; internal set; }
        public Guid PolicyId { get; internal set; } = Guid.NewGuid();
        public Guid PartnerId { get; internal set; } = Guid.Parse("708F226C-8165-407A-868C-FBCC206D95EB");

        public async Task SimulatePolicyCreation(PolicyCreatedEvent @event)
        {
            this.testContext.EventBus.ResetIntegrationEvents();

            await this.policyCreatedEventHandler.Handle(@event);
        }

        public async Task SimulatePolicyInception(PolicyInceptionExecutedEvent @event)
        {
            this.testContext.EventBus.ResetIntegrationEvents();

            await this.policyUpdatedEventHandler.Handle(@event);
        }

        internal async Task SimulatePolicyDetailsUpdate(PolicyDetailsUpdatedEvent @event)
        {
            this.testContext.EventBus.ResetIntegrationEvents();

            await this.policyUpdatedEventHandler.Handle(@event);
        }

        internal async Task SimulatePolicyExpiry(PolicyExpiredEvent @event)
        {
            this.testContext.EventBus.ResetIntegrationEvents();

            await this.policyUpdatedEventHandler.Handle(@event);
        }

        internal async Task SimulatePolicyTermination(PolicyTerminatedEvent @event)
        {
            this.testContext.EventBus.ResetIntegrationEvents();

            await this.policyUpdatedEventHandler.Handle(@event);
        }
        internal async Task SimulatePolicyCancellation(PolicyCancelledEvent @event)
        {
            this.testContext.EventBus.ResetIntegrationEvents();

            await this.policyRemovedEventHandler.Handle(@event);
        }
    }
}
