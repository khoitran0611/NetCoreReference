﻿using AutoMapper;
using CentralSequences.Client;
using Hydra.Common.Integration.EventBus;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Localization;
using Microsoft.Extensions.Logging;

namespace Hydra.CustomerManagement.Web.Tests.Setup
{
    public class TestStartup : Startup
    {
        public TestStartup(IHostingEnvironment env, ILoggerFactory loggerFactory)
            : base(BuildConfiguration(env), loggerFactory)
        {
        }

        public override void Configure(IApplicationBuilder app, IHostingEnvironment env, ILoggerFactory loggerFactory)
        {
            app.UseMiddleware<AuthorizeAllRequestsMiddleware>();
            app.UseMvc();
        }

        public override void ConfigureServices(IServiceCollection services)
        {
            services.AddMvc(setupAction =>
            {
                setupAction.ReturnHttpNotAcceptable = true;
            })
            .AddApplicationPart(typeof(Startup).Assembly)
            .AddControllersAsServices()
            .SetCompatibilityVersion(CompatibilityVersion.Version_2_1);

            services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();
            services.AddAutoMapper();
            services.AddCustomerManagementCoreServices();
            services.AddSwedenSpecificServices();
            AddIntegrationServices(services);

            services.AddAuthorization(options =>
            {
                options.AddPolicy(AuthorisationPolicies.Api, policy => policy.RequireAssertion(ctx => true));
                options.AddPolicy("ManagementApi", policy => policy.RequireAssertion(ctx => true));
            });
        }

        protected override void AddIntegrationServices(IServiceCollection services)
        {
            services.AddGlobalResourcesLocalization(new FakeGlobalResourcesClient(), options => options.ServiceUri = "");
            services.AddSingleton<IStringLocalizer, FakeStringLocalizer>();
            services.AddSingleton<ICentralSequencesClient, FakeCentralSequencesClient>();
            services.AddSingleton<IEventBus, FakeEventBus>();

            AddInsuranceEventHandlers(services);
        }

        private static IConfiguration BuildConfiguration(IHostingEnvironment env)
        {
            var builder = new ConfigurationBuilder()
                .SetBasePath(env.ContentRootPath);

            return builder.Build();
        }
    }
}