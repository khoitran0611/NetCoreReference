﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AngleSharp.Dom.Html;
using TechTalk.SpecFlow;

namespace Hydra.CustomerManagement.Web.Tests.Setup
{
    public class CustomerContext
    {
        public IHtmlDocument HtmlDocument { get; set; }

        public Table FormValues { get; set; }

        public Guid CustomerId { get; set; }

        internal void SaveCustomerId()
        {
            var actualDocument = this.HtmlDocument;
            var actualForm = (IHtmlFormElement)actualDocument.QuerySelector("form");
            var actualElement = actualForm.QuerySelector($"[name='CustomerId']");

            this.CustomerId = Guid.Parse(actualElement.Attributes["value"].Value);
        }
    }
}
