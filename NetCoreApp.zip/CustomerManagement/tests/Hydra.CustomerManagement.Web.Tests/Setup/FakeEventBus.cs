﻿using System;
using Hydra.Common.Integration.EventBus;
using Hydra.Common.Integration.EventBus.Events;

namespace Hydra.CustomerManagement.Web.Tests.Setup
{
    public class FakeEventBus : IEventBus
    {
        public BaseIntegrationEvent IntegrationEvent { get; set; }

        public bool IsConnected => true;

        public void Publish(BaseIntegrationEvent @event)
        {
            IntegrationEvent = @event;
        }

        public void Publish(BaseIntegrationEvent @event, string exchangeName = null)
        {
            IntegrationEvent = @event;
        }

        public void Subscribe<TEvent, TEventHandler>()
            where TEvent : BaseIntegrationEvent
            where TEventHandler : IIntegrationEventHandler<TEvent>
        {
            // We don't need to act on this
        }

        public void Unsubscribe<TEvent, TEventHandler>()
            where TEvent : BaseIntegrationEvent
            where TEventHandler : IIntegrationEventHandler<TEvent>
        {
            // We don't need to act on this
        }

        internal void ResetIntegrationEvents()
        {
            this.IntegrationEvent = null;
        }
    }
}