﻿using System.Threading.Tasks;
using Hydra.GlobalResources.Client;

namespace Hydra.CustomerManagement.Web.Tests.Setup
{
    public class FakeGlobalResourcesClient : IGlobalResourcesClient
    {
        public Task<string> ResolveLink(string sourceSystem, string resourceKey, params object[] parameters)
        {
            return Task.FromResult($"https://TEST_CLIENT_URI/RESOLVED:{resourceKey}");
        }

        public Task<string> Translate(string language, string resourceKey, params object[] parameters)
        {
            return Task.FromResult($"TRANSLATED[{language}]:{resourceKey}");
        }
    }
}
