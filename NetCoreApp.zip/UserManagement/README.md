# User Management - Single Sign On Service

User Management is an ASP.NET Core MVC Website that hosts IdentityServer4. IdentityServer4 supports OAuth 2.0 and Open Connect ID Provider protocols.
The website uses ASP.NET Identity with Entity Framework Core storage to persist users and their profiles. User Management is the service that handles
user passwords, including storage, change of password and forgotten password process. Sub-systems like Insurance may store a representation of a User
but this should only act as a link between central, shared User identity and sub-system specific User context. In case of Insurance users are given 
Insurance specific permissions by assigning them to a Role Profile within a given Organisation Unit.

To find more information on relavant technologies please follow links below:
* [Identity Server](https://identityserver.io/)
* [ASP.NET MVC Core](https://www.asp.net/core)
* [ASP.NET Identity](https://www.asp.net/identity)

## Usage
Clients that want to connect to the service must be registered. It is possible to register Client URIs in appsettings.json in "ValidClients" section. The URI provided in there
must match the local URI of the client, e.g. when running Insurance Web locally from Visual Studio it has URI of "http://localhost:49631/".

User Management is seeded with a special user - Security Admin - when it is first run. You can log in as Security Admin using following credentials:
    
    email: security_admin@contemi.com
    password: Passw0rd!

Procedure to get Insurance Web running consists of following steps:
1. Start User Management (by default runs on http://localhost:9000)
2. Start Insurance Web (by default runs on http://localhost:49631)
3. Log in as Security Admin
4. Import a bundle or create a new Organisation Structure (or if you want to use existing internal users, please see the next section.)
5. If creating new you will have to specify Organisation Admin user and if using a bundle it will contain this user's details
6. Log off and when presented with Login page register a new user with email address matching that of Organisation Admin,e.g. triton.norway.admin@contemi.com
7. After successful registration and login, that user can access Insurance Web and create more Organisation Units, Role Profiles and Users.
   (There is an existing issue that after you log in, you need to enter the insurance web url to enter the insurance website.)
8. Each new user has to register with matching email address in User Management before they can access Insurance Web (_Register_ link on the Login page)
9. User Management has to be running in the background all the time as it may also be used to authenticate access to APIs

## Migrating existing Internal Users to External
For systems that have previously created internal users below script can be executed to migrate them to External Users. After then the user with matching email
still needs to be Registered on User Management website just like any new user.

``` sql
INSERT INTO [dbo].[ExternalMemberships]
 ([Id]
 ,[UserName]
 ,[ProviderId]
 ,[User_Id])
 SELECT Id, Email, 'hydra.usermanagement', Id
	FROM dbo.Users u
	WHERE NOT EXISTS (SELECT Id FROM [dbo].[ExternalMemberships] existing
	WHERE existing.Id = u.Id)

GO
```

## Configuration
### Signing Certificate
Following options are available when choosing how Tokens issued by User Management should be signed:
1. TemporarySigningCredential
```json
  // AppSettings
  "HydraUserManagement": {
    "SigningCertStrategy": {
      "Type": "Hydra.UserManagement.Services.TemporarySigningCredential"
    }
  }
 ```
 ```
 REM Environmental Variables
 HydraUserManagement:SigningCertStrategy:Type = Hydra.UserManagement.Services.TemporarySigningCredential
 ```
 
2. FromCertificateStore
```json
  // AppSettings
  "HydraUserManagement": {
    "SigningCertStrategy": {
      "Type": "Hydra.UserManagement.Services.FromCertificateStore",
      "Params": {
        "StoreLocation": "LocalMachine|CurrentUser (defaults to LocalMachine)",
        "SubjectDistinguishedName": "CN=UserManagementSigningCert"
      }
    }
  }
 ```
 ```
 REM Environmental Variables
 HydraUserManagement:SigningCertStrategy:Type = Hydra.UserManagement.Services.FromCertificateStore
 HydraUserManagement:SigningCertStrategy:Params:StoreLocation = LocalMachine|CurrentUser (defaults to LocalMachine)
 HydraUserManagement:SigningCertStrategy:Params:SubjectDistinguishedName = CN=UserManagementSigningCert
 ``` 
 
3. FromEmbeddedResource
```json
  // AppSettings
  "HydraUserManagement": {
    "SigningCertStrategy": {
      "Type": "Hydra.UserManagement.Services.FromEmbeddedResource",
      "Params": {
        "SigningCertPassword": "certificate-password"
      }
    }
  }
 ```
 ```
 REM Environmental Variables
 HydraUserManagement:SigningCertStrategy:Type = Hydra.UserManagement.Services.FromEmbeddedResource
 HydraUserManagement:SigningCertStrategy:Params:SigningCertPassword = <cerificate password>
 ``` 

## Deployment
### Overview
The build process is called UserManagement Release (https://contemi.visualstudio.com/Kraken/_build/index?context=allDefinitions&path=%5C&definitionId=192&_a=completed) that triggers on every commit to master.
The release process is called User Management (https://contemi.visualstudio.com/Kraken/_apps/hub/ms.vss-releaseManagement-web.hub-explorer?definitionId=3&_a=definitionoverview) that triggers on every succesful build.

### To an existing Environment
1. Find the release you want to deploy at https://contemi.visualstudio.com/Kraken/_apps/hub/ms.vss-releaseManagement-web.hub-explorer?_a=releases
2. Double click the title of the release.
3. Find the environment from the list and click the ellipsis (...) then click Deploy or Redeploy as appropriate.
4. Click Logs to watch it being deployed.

### To a new Windows Server Environment
#### Prerequisites
The following must already be installed on the target machine (a lot of this can be done by following the steps on https://docs.asp.net/en/latest/publishing/iis.html):
* IIS
* .Net Core Windows Server Hosting
* Web Deploy 3.5+ (use the Web Platform Installer)
* Windows Remote Management configured to allow access from the agent that will be deploying to the new environment (see https://msdn.microsoft.com/en-us/library/aa384372(v=vs.85).aspx)
* A user that deploy the application.

#### Steps
1. Go to https://contemi.visualstudio.com/Kraken/_apps/hub/ms.vss-releaseManagement-web.hub-explorer?definitionId=3&_a=environments-editor
2. Select an environment to clone.
3. Click "Add Environment" and "Clone Selected Environment".
4. Configure as needed. In most cases this should be by configuring variables (can be found in the ellipsis menu for the environment).
    * targetMachine - FQDN of target machine
    * adminlogin - Username of deployment user
    * adminPassword - Password of deployment user, this is edit only, untick the padlock to enter a new value, tick again to hide.
    * websiteName - The IIS name of the website to deploy to
    * targetStagingDirectory - The folder on the target machine to stage the deployment
5. Check the correct deployment queue has been chosen (may need to click on the box named "Run on agent" to see). Default is Ares in Reading, Hosted is hosted by Microsoft.
We will need agents within doorway if we can't open the WinRM ports on the boxes.
6. Save.
7.  Make a folder c:\staging\usermanagement (this can be configured for each environment as a variable) and make sure the deploy user can copy to it.
8. Make a website to deploy and configure the release with that website name
    * Give it a https binding at least
    * Application Pool can be set to No Managed Code
    * If neccessary make a logs folder that the machinename\IIS_IUSRS group can write to
9. Ensure Deploy user is an admin or has delegated rights to deploy web applications (go to IIS Manage Permissions on the website).
10. Set environment variables.
11. Run the following to refresh environment for IIS:
```
    net stop was /y
    net start w3svc
```
12. Deploy to the new environment as above.
 
### To a new Azure Environment
TBC