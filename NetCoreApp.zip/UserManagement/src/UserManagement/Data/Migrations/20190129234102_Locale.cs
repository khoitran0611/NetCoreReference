﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Hydra.UserManagement.Data.Migrations
{
    public partial class Locale : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "Locale",
                table: "AspNetUsers",
                nullable: true,
                defaultValue: "en-GB");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Locale",
                table: "AspNetUsers");
        }
    }
}
