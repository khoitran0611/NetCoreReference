﻿using System.Collections.Generic;
using Hydra.UserManagement.Models;

namespace Hydra.UserManagement.Data
{
    public class SeedDataOptions
    {
        public List<string> Roles { get; set; }
        public List<Organisation> Organisations { get; set; }
        public List<SeedUser> Users { get; set; }

        public class SeedUser
        {
            public string Email { get; set; }
            public string FirstName { get; set; }
            public string LastName { get; set; }
            public string Organisation { get; set; }
            public bool IsVirtual { get; set; }
            public List<string> Roles { get; set; }
        }
    }
}