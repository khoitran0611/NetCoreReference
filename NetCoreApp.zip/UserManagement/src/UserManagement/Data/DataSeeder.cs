﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Hydra.GlobalResources.Client;
using Hydra.UserManagement.Configuration;
using Hydra.UserManagement.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace Hydra.UserManagement.Data
{
    public class DataSeeder
    {
        private readonly IServiceProvider services;
        private readonly ILogger<DataSeeder> logger;

        public DataSeeder(IServiceProvider services, ILogger<DataSeeder> logger)
        {
            this.services = services;
            this.logger = logger;
        }
        public async Task SeedData()
        {
            this.logger.LogInformation("Starting seeding...");
            var options = services.GetRequiredService<IOptions<SeedDataOptions>>().Value ?? new SeedDataOptions();

            var context = services.GetService<ApplicationDbContext>();
            context.Database.Migrate();

            await SeedRoles(services, options.Roles ?? Enumerable.Empty<string>());

            await SeedSecurityAdminUser(services);

            await SeedOrganisations(context, options.Organisations ?? Enumerable.Empty<Organisation>());

            await context.SaveChangesAsync();

            await SeedUsers(services, context, options.Users ?? Enumerable.Empty<SeedDataOptions.SeedUser>());

            await context.SaveChangesAsync();
            this.logger.LogInformation("Finished seeding.");
        }

        private async Task SeedSecurityAdminUser(IServiceProvider services)
        {
            var userManager = services.GetRequiredService<UserManager<ApplicationUser>>();
            var user = (await userManager.GetUsersInRoleAsync(SecurityAdminUserBuilder.SecurityAdminRole)).SingleOrDefault();

            if (user == null)
            {
                var builder = new SecurityAdminUserBuilder(
                    services.GetService<IOptions<SecurityAdminSettings>>(),
                    services.GetService<IOptions<GlobalResourcesClientOptions>>());
                user = builder.Create();
                this.logger.LogInformation("Seeding security admin as {0}", user.Email);
                await userManager.CreateAsync(user, builder.GetPassword());
            }

            await userManager.AddToRoleAsync(user, SecurityAdminUserBuilder.SecurityAdminRole);
            await userManager.AddToRoleAsync(user, Roles.UserAdmin);
        }

        private async Task SeedUsers(IServiceProvider services, ApplicationDbContext context, IEnumerable<SeedDataOptions.SeedUser> users)
        {
            this.logger.LogInformation("Seeding {0} users", users.Count());
            foreach (var user in users)
            {
                await AddOrganisationUser(services, context, user);
            }
        }

        private async Task SeedRoles(IServiceProvider services, IEnumerable<string> roles)
        {
            this.logger.LogInformation("Seeding {0} roles", roles.Count());
            var roleManager = services.GetRequiredService<RoleManager<IdentityRole>>();

            await AddRole(roleManager, SecurityAdminUserBuilder.SecurityAdminRole);
            await AddRole(roleManager, Roles.UserAdmin);
            await AddRole(roleManager, Roles.Support);

            foreach (var role in roles)
            {
                await AddRole(roleManager, role);
            }
        }

        private async Task AddRole(RoleManager<IdentityRole> roleManager, string role)
        {
            if (!await roleManager.RoleExistsAsync(role))
            {
                this.logger.LogDebug("Seeding role: {0}", role);
                await roleManager.CreateAsync(new IdentityRole(role));
            }
        }

        private async Task AddOrganisationUser(
            IServiceProvider services,
            ApplicationDbContext context,
            SeedDataOptions.SeedUser seedUser)
        {
            var userManager = services.GetRequiredService<UserManager<ApplicationUser>>();
            var user = await userManager.FindByNameAsync(seedUser.Email);

            if (user == null)
            {
                try
                {
                    this.logger.LogDebug("Seeding user {0} for {1}", seedUser.Email, seedUser.Organisation);
                    var organisation = context.Organisations.Single(org => org.Name == seedUser.Organisation);

                    var globalResourcesClientOptions = services.GetRequiredService<IOptions<GlobalResourcesClientOptions>>().Value;
                    var systemConfiguration = services.GetRequiredService<IOptions<SystemConfiguration>>().Value;

                    var builder = new OrganisationUserBuilder()
                        .WithEmail(seedUser.Email)
                        .WithName(seedUser.FirstName, seedUser.LastName)
                        .WithOrganisation(organisation)
                        .WithIsVirtual(seedUser.IsVirtual)
                        .WithTwoFactorEnabled(systemConfiguration.Default2FA)
                        .WithLocale(globalResourcesClientOptions.DefaultCulture);

                    user = builder.Create();
                    await userManager.CreateAsync(user, builder.GetDefaultPassword());
                    await userManager.AddToRolesAsync(user, seedUser.Roles);
                }
                catch (Exception ex)
                {
                    this.logger.LogError(ex, ex.Message);
                }
            }
        }

        private async Task SeedOrganisations(ApplicationDbContext context, IEnumerable<Organisation> organisations)
        {
            await AddOrUpdateOrganisation(context, organisations);
        }

        private async Task AddOrUpdateOrganisation(ApplicationDbContext context, IEnumerable<Organisation> requiredOrganisations)
        {
            var existingOrganisations = await context.Organisations.ToArrayAsync();

            foreach (var organisation in requiredOrganisations)
            {
                var organisationToUpdate = GetMatchingOrganisation(organisation, existingOrganisations);

                if (organisationToUpdate != null)
                {
                    organisationToUpdate.Name = organisation.Name;
                    organisationToUpdate.OrganisationContext = organisation.OrganisationContext;
                    context.Organisations.Update(organisationToUpdate);
                }
                else
                {
                    await context.Organisations.AddAsync(organisation);
                }
            }
        }

        private Organisation GetMatchingOrganisation(Organisation organisation, IEnumerable<Organisation> existingOrganisations)
        {
            try
            {
                return existingOrganisations.SingleOrDefault(x => x.Name == organisation.Name || x.OrganisationContext == organisation.OrganisationContext);
            }
            catch (InvalidOperationException ex)
            {
                throw new InvalidOperationException("There are more than one organisations partially matched with the name or the context.", ex);
            }
        }
    }
}