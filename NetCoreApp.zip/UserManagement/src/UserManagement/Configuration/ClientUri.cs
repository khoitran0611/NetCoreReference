﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Hydra.UserManagement.Configuration
{
    public class ClientUri
    {
        public Uri BaseUri { get; set; }

        public string RelativeUri { get; set; }
    }
}