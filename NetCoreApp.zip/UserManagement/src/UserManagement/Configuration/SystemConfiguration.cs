﻿namespace Hydra.UserManagement.Configuration
{
    public class SystemConfiguration
    {
        public bool Default2FA { get; set; }

        public bool DefaultIsVirtual { get; set; }

        public string[] RolesAllowedOnlyForSecurityAdmin { get; set; }
    }
}
