﻿using System;
using System.Linq;

namespace Hydra.UserManagement.Configuration
{
    public class ValidClients
    {
        public ValidClients()
        {
            this.InsuranceUris = Array.Empty<string>();
            this.CrmUris = Array.Empty<string>();
            this.TestClientUris = Array.Empty<string>();
            this.TestTokenClientUris = Array.Empty<string>();
            this.SwaggerUiClientUris = Array.Empty<Uri>();
            this.CpsTestClientUris = Array.Empty<ClientUri>();
            this.CcsClientUris = Array.Empty<string>();
            this.CustomerClientUris = Array.Empty<string>();
            this.DocumentWebUris = Array.Empty<string>();
            this.MotorRegistryWebUris = Array.Empty<string>();
            this.CustomerAuthenticationWebUris = Array.Empty<string>();
        }

        public string[] InsuranceUris { get; set; }

        public string[] CrmUris { get; set; }

        public ClientUri[] CrsClientUris { get; set; }

        public string[] TestClientUris { get; set; }

        public Uri[] SwaggerUiClientUris { get; set; }

        public string[] TestTokenClientUris { get; set; }

        public ClientUri[] CpsTestClientUris { get; set; }

        public string[] CcsClientUris { get; set; }

        public string[] CustomerClientUris { get; set; }

        public string[] DocumentWebUris { get; set; }

        public string[] MotorRegistryWebUris { get; set; }

        public string[] CustomerAuthenticationWebUris { get; set; }

        /// <summary>
        /// Returns configured links to top-level applications to allow users that go to UM directly to get back to one of the applications.
        /// This should NOT include all possible microservices which are still being configured as valid clients but don't need to be navigated to directly.
        /// </summary>
        public string[] GetApplicationUris() => 
            InsuranceUris
            .Union(CrmUris)
            .Union(CrsClientUris.Select(uri => uri.BaseUri.AbsoluteUri))
            .Union(CcsClientUris)
            .ToArray();
    }
}