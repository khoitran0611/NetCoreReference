﻿namespace Hydra.UserManagement.Configuration
{
    public class SecurityAdminSettings
    {
        public string Email { get; set; }

        public string DefaultPassword { get; set; }

        public bool TwoFactorEnabled { get; set; }
    }
}
