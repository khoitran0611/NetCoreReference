﻿using System.Collections.Generic;
using Hydra.UserManagement.Models;
using IdentityModel;
using IdentityServer4.Models;

namespace Hydra.UserManagement
{
    public static class ResourcesConfig
    {
        public static IEnumerable<IdentityResource> GetIdentityResources()
        {
            return new List<IdentityResource>
            {
                new IdentityResources.OpenId(),
                new IdentityResources.Profile(),
                new IdentityResources.Email(),
                new IdentityResource("user.management", "User Management", new [] { SecurityAdminUserBuilder.SecurityAdminRole, ApplicationUser.DisplayNameClaimType }),
                new IdentityResource(HydraScopes.OrganisationContext, "Organisation Context", new []
                {
                    ApplicationUser.OrganisationClaimType,
                    ApplicationUser.TenantIdClaimType,
                    JwtClaimTypes.Role,
                    ApplicationUser.DisplayNameClaimType,
                    ApplicationUser.IsVirtualClaimType
                })
            };
        }

        public static IEnumerable<ApiResource> GetApiResources()
        {
            return new List<ApiResource>
            {
                new ApiResource(HydraScopes.HydraCpsApi, "CPS API", 
                    new [] {
                        JwtClaimTypes.Subject,
                        JwtClaimTypes.Name,
                        JwtClaimTypes.Email,
                        JwtClaimTypes.Role,
                        JwtClaimTypes.Locale,
                        ApplicationUser.OrganisationClaimType,
                        ApplicationUser.TenantIdClaimType,
                        ApplicationUser.DisplayNameClaimType,
                        ApplicationUser.IsVirtualClaimType,
                        JwtClaimTypes.Role,
                    })
                {
                    Description = "Insurance service API"
                },

                new ApiResource(HydraScopes.HydraCrsApi, "CRS API",
                    new []
                    {
                        ApplicationUser.OrganisationClaimType,
                        ApplicationUser.TenantIdClaimType,
                        ApplicationUser.DisplayNameClaimType,
                        JwtClaimTypes.Role,
                    })
                {
                    Description = "Re-insurance service API"
                },

                new ApiResource(HydraScopes.HydraCrsWeb, "CRS Frontend")
                {
                    Description = "Re-insurance Frontend"
                },

                new ApiResource(HydraScopes.CrmTasksApi, "CRM Tasks API")
                {
                    Description = "Tasks service for CRM"
                },

                new ApiResource(HydraScopes.HydraEventHistoryApi, "Hydra EventHistory API")
                {
                    Description = "Event History API"
                },

                new ApiResource(HydraScopes.HydraDocumentsApi, "Hydra Documents API",
                    new []
                    {
                        ApplicationUser.OrganisationClaimType,
                        ApplicationUser.TenantIdClaimType,
                        ApplicationUser.DisplayNameClaimType,
                        JwtClaimTypes.Role,
                    })
                {
                    Description = "Documents API"
                },

                new ApiResource(HydraScopes.PegasusCustomerSearch, "Push searchable customer API")
                {
                    Description = "Push searchable customer data to CRM"
                },

                new ApiResource(HydraScopes.ChimeraCcsWeb, "CCS Frontend")
                {
                    Description = "Claims Frontend"
                },

                new ApiResource(HydraScopes.ChimeraCcsApi, "CCS API")
                {
                    Description = "CCS service API",
                    UserClaims = new []
                    {
                        ApplicationUser.OrganisationClaimType,
                        ApplicationUser.TenantIdClaimType
                    }
                },

                new ApiResource(HydraScopes.CustomerManagementApi, "Customer Management API")
                {
                    Description = "Customer Management Microservices",
                    UserClaims = new []
                    {
                        ApplicationUser.OrganisationClaimType,
                        ApplicationUser.TenantIdClaimType,
                        ApplicationUser.DisplayNameClaimType,
                        JwtClaimTypes.Role,
                    }
                },
                new ApiResource(HydraScopes.HydraMotorRegistryApi, "Hydra MotorRegistry API")
                {
                    Description = "Hydra MotorRegistry API",
                    UserClaims = new []
                    {
                        ApplicationUser.OrganisationClaimType,
                        ApplicationUser.TenantIdClaimType,
                        ApplicationUser.DisplayNameClaimType,
                        JwtClaimTypes.Role,
                    }
                },
                new ApiResource(HydraScopes.HydraCustomerAuthentication, "Hydra CustomerAuthentication")
                {
                    Description = "Customer Authentication"
                }
            };
        }
    }
}