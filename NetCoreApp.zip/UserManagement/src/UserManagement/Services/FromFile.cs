﻿using System.Security.Cryptography.X509Certificates;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Hydra.UserManagement.Services
{
    public class FromFile : SigningCertStrategy
    {
        private readonly string filename;
        private readonly string password;

        public FromFile(IConfiguration configuration) : base(configuration)
        {
            this.filename = configuration.GetValue<string>("HydraUserManagement:SigningCertStrategy:Params:Filename");
            this.password = configuration.GetValue<string>("HydraUserManagement:SigningCertStrategy:Params:Password");
        }

        protected override void SetSigningCredentialInternal(IIdentityServerBuilder identityServerBuilder)
        {
            var certificate = new X509Certificate2(filename, password);
            identityServerBuilder.AddSigningCredential(certificate);
        }
    }
}