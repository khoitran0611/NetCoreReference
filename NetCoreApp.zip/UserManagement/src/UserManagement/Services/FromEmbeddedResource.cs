﻿using System;
using System.IO;
using System.Reflection;
using System.Security.Cryptography.X509Certificates;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Hydra.UserManagement.Services
{
    public class FromEmbeddedResource : SigningCertStrategy
    {
        private readonly string password;

        public FromEmbeddedResource(IConfiguration configuration)
        : base(configuration)
        {
            this.password = configuration.GetValue<string>("HydraUserManagement:SigningCertStrategy:Params:SigningCertPassword");
        }

        protected override void SetSigningCredentialInternal(IIdentityServerBuilder identityServerBuilder)
        {
            var signingCert = LoadCertificate();
            identityServerBuilder.AddSigningCredential(signingCert);
        }

        private X509Certificate2 LoadCertificate()
        {
            var assembly = Assembly.GetEntryAssembly();
            using (var stream = assembly.GetManifestResourceStream("UserManagement.UserManagementSigningCert.pfx"))
            {
                return new X509Certificate2(
                    ReadEntireStream(stream),
                    password,
                    X509KeyStorageFlags.MachineKeySet | X509KeyStorageFlags.PersistKeySet | X509KeyStorageFlags.Exportable);
            }
        }

        private byte[] ReadEntireStream(Stream stream)
        {
            using (var reader = new BinaryReader(stream))
            {
                if (stream.Length > int.MaxValue)
                {
                    throw new ArgumentOutOfRangeException(nameof(stream), "Stream is too long to read all its bytes in one go.");
                }
                return reader.ReadBytes((int)stream.Length);
            }
        }
    }
}