﻿using System;
using System.Threading.Tasks;
using Hydra.UserManagement.Configuration;
using MailKit.Net.Smtp;
using Microsoft.Extensions.Options;
using MimeKit;

namespace Hydra.UserManagement.Services
{
    // This class is used by the application to send Email and SMS
    // when you turn on two-factor authentication in ASP.NET Identity.
    // For more details see this link http://go.microsoft.com/fwlink/?LinkID=532713
    public class AuthMessageSender : IEmailSender, ISmsSender
    {
        private readonly MailSettings mailSettings;

        public AuthMessageSender(IOptions<MailSettings> mailSettingsOptions)
        {
            this.mailSettings = mailSettingsOptions.Value;
        }

        public async Task SendEmailAsync(string email, string subject, string message)
        {
            var emailMessage = CreateEmailMessage(email, subject, message);

            using (var client = new SmtpClient())
            {
                await client.ConnectAsync(mailSettings.Host, mailSettings.Port, useSsl: false).ConfigureAwait(false);

                if (mailSettings.RequiresAuthentication)
                {
                    AssertUserNameAndPassword();
                    await client.AuthenticateAsync(mailSettings.UserName, mailSettings.Password).ConfigureAwait(false);                    
                }

                await client.SendAsync(emailMessage).ConfigureAwait(false);
                await client.DisconnectAsync(true).ConfigureAwait(false);
            }
        }

        private void AssertUserNameAndPassword()
        {
            if (string.IsNullOrEmpty(mailSettings.UserName) || string.IsNullOrEmpty(mailSettings.Password))
            {
                throw new ArgumentException("SMTP userName and password can not be empty.");
            }
        }

        public Task SendSmsAsync(string number, string message)
        {
            // Plug in your SMS service here to send a text message.
            return Task.FromResult(0);
        }

        private MimeMessage CreateEmailMessage(string toAddress, string subject, string message)
        {
            var emailMessage = new MimeMessage();

            emailMessage.From.Add(new MailboxAddress(this.mailSettings.From));
            emailMessage.To.Add(new MailboxAddress(toAddress));
            emailMessage.Subject = subject;

            BodyBuilder bodyBuilder = new BodyBuilder();
            bodyBuilder.HtmlBody = message;

            emailMessage.Body = bodyBuilder.ToMessageBody();

            return emailMessage;
        }
    }
}