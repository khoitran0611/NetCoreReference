﻿using System;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Hydra.UserManagement.Services
{
    public class SigningCertStrategy
    {
        private readonly IConfiguration configuration;

        public SigningCertStrategy(IConfiguration configuration)
        {
            this.configuration = configuration;
        }

        public void SetSigningCredential(IIdentityServerBuilder identityServerBuilder)
        {
            var strategy = this.Create();
            strategy.SetSigningCredentialInternal(identityServerBuilder);
        }

        protected virtual void SetSigningCredentialInternal(IIdentityServerBuilder identityServerBuilder)
        {
        }

        private SigningCertStrategy Create()
        {
            var strategyName = this.configuration.GetValue<string>("HydraUserManagement:SigningCertStrategy:Type");

            var strategy = (SigningCertStrategy)Activator.CreateInstance(Type.GetType(strategyName), this.configuration);
            return strategy;
        }
    }
}