﻿using System;
using System.Collections.Generic;
using System.Linq;
using Hydra.UserManagement.Data;
using Hydra.UserManagement.Models;
using Microsoft.EntityFrameworkCore;

namespace Hydra.UserManagement.Services
{
    public interface IOrganisationSerivce
    {
        List<Organisation> GetOrganisations();

        Organisation GetOrganisationByContext(string organisationContext);

        Organisation GetOrganisationById(int id);

        void SetOrganisation(ApplicationUser user, int organisationId);

        void UpdateOrganisation(Organisation organisation);
    }

    public class OrganisationService : IOrganisationSerivce
    {
        private readonly ApplicationDbContext dbContext;

        public OrganisationService(ApplicationDbContext dbContext)
        {
            this.dbContext = dbContext;
        }        

        public List<Organisation> GetOrganisations()
        {
            return dbContext.Organisations.AsNoTracking().ToList();
        }

        public void SetOrganisation(ApplicationUser user, int organisationId)
        {
            var organisation = GetOrganisations().SingleOrDefault(x => x.Id == organisationId);

            if (organisation != null)
            {
                user.SetOrganisation(organisation.Id, organisation.OrganisationContext);
            }
        }

        public Organisation GetOrganisationByContext(string organisationContext)
        {
            return dbContext.Organisations.SingleOrDefault(x => x.OrganisationContext.Equals(organisationContext, StringComparison.InvariantCultureIgnoreCase));
        }

        public Organisation GetOrganisationById(int id)
        {
            return dbContext.Organisations.SingleOrDefault(x => x.Id == id);
        }

        public void UpdateOrganisation(Organisation organisation)
        {
            dbContext.Organisations.Attach(organisation);
            dbContext.SaveChanges();
        }
    }
}