﻿using System.Security.Cryptography.X509Certificates;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Hydra.UserManagement.Services
{
    public class FromCertificateStore : SigningCertStrategy
    {
        private readonly StoreLocation storeLocation;
        private readonly string subjectDistinguishedName;

        public FromCertificateStore(IConfiguration configuration)
            : base(configuration)
        {
            this.storeLocation = configuration.GetValue<StoreLocation>(
                "HydraUserManagement:SigningCertStrategy:Params:StoreLocation",
                StoreLocation.LocalMachine);
            this.subjectDistinguishedName = configuration.GetValue<string>("HydraUserManagement:SigningCertStrategy:Params:SubjectDistinguishedName");
        }

        protected override void SetSigningCredentialInternal(IIdentityServerBuilder identityServerBuilder)
        {
            identityServerBuilder.AddSigningCredential(this.subjectDistinguishedName, this.storeLocation);
        }
    }
}