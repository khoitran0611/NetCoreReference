﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Hydra.UserManagement.Services
{
    public class TemporarySigningCredential : SigningCertStrategy
    {
        public TemporarySigningCredential(IConfiguration configuration)
            : base(configuration)
        {
        }

        protected override void SetSigningCredentialInternal(IIdentityServerBuilder identityServerBuilder)
        {
            identityServerBuilder.AddDeveloperSigningCredential(true);
        }
    }
}