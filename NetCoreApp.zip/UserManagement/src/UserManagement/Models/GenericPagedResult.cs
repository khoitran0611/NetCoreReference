﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Hydra.UserManagement.Models
{
    public class GenericPagedResult<TResult>
    {
        public GenericPagedResult()
        {
            this.Results = new List<TResult>();
            this.PaginationContext = new PagingContext();
        }

        public GenericPagedResult(IEnumerable<TResult> totalResults, PagingContext pagingContext)
        {
            this.Results = totalResults
                .Skip(pagingContext.Skip)
                .Take(pagingContext.ItemsPerPage);

            this.PaginationContext = pagingContext;
        }

        public IEnumerable<TResult> Results { get; set; }

        public PagingContext PaginationContext { get; set; }

        public static GenericPagedResult<TResult> WrapWithGenericPagedResult(IEnumerable<TResult> results, PagingContext paginationContext)
        {
            return new GenericPagedResult<TResult>()
            {
                Results = results,
                PaginationContext = paginationContext
            };
        }

        public GenericPagedResult<TResult> MaterializeResults()
        {
            this.Results = this.Results.ToArray();
            return this;
        }

        public GenericPagedResult<TNewResultType> Transform<TNewResultType>(Func<TResult, TNewResultType> transform)
        {
            return new GenericPagedResult<TNewResultType>()
            {
                Results = this.Results.Select(transform),
                PaginationContext = this.PaginationContext
            };
        }
    }
}
