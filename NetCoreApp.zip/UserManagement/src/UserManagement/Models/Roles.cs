﻿namespace Hydra.UserManagement.Models
{
    public static class Roles
    {
        public const string UserAdmin = "UserAdmin";
        public const string Agent = "Agent";
        public const string SuperUser = "Super User";
        public const string CallCentre = "Call Centre";
        public const string Support = "Support";
    }
}