﻿namespace Hydra.UserManagement.Models
{
    public class Language
    {
        public string Locale { get; set; }
        public string Description { get; set; }
    }
}
