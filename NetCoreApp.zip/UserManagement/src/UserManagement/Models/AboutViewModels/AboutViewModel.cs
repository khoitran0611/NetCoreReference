﻿using System.ComponentModel.DataAnnotations;

namespace Hydra.UserManagement.Models.AboutViewModels
{
    public class AboutViewModel
    {
        public string Version { get; set; }

        public string StoreStatus { get; set; }
    }
}