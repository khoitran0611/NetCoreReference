﻿using Hydra.GlobalResources.Client;
using Hydra.UserManagement.Configuration;
using Microsoft.Extensions.Options;

namespace Hydra.UserManagement.Models
{
    public class SecurityAdminUserBuilder
    {
        public const string SecurityAdminRole = "security_admin";
        public const string SecurityAdminEmail = "security_admin@contemi.com";
        private readonly ApplicationUser securityAdminUser;
        private readonly SecurityAdminSettings settings;

        public SecurityAdminUserBuilder(
            IOptions<SecurityAdminSettings> settings,
            IOptions<GlobalResourcesClientOptions> globalResourcesClientOptions)
        {
            this.settings = settings.Value;
            this.securityAdminUser = new ApplicationUser();
            this.securityAdminUser.UserName = GetEmail();
            this.securityAdminUser.Email = GetEmail();
            this.securityAdminUser.EmailConfirmed = true;
            this.securityAdminUser.TwoFactorEnabled = this.settings.TwoFactorEnabled;
            this.securityAdminUser.Locale = globalResourcesClientOptions.Value.DefaultCulture;

            this.securityAdminUser.SetNames("Security", "Admin");
        }

        public ApplicationUser Create()
        {
            return this.securityAdminUser;
        }

        public string GetPassword()
        {
            // TODO: Replace with safe storage mechanism
            return string.IsNullOrWhiteSpace(settings.DefaultPassword) ? "Passw0rd!" : settings.DefaultPassword;
        }

        private string GetEmail()
        {
            return string.IsNullOrWhiteSpace(settings.Email) ? SecurityAdminEmail : settings.Email;            
        }
    }
}