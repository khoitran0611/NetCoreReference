﻿using System.Linq;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace Hydra.UserManagement.Models.ManageViewModels
{
    public class IndexViewModel
    {
        public bool HasPassword { get; set; }
        public bool CanChangePassword { get; set; }

        [Required]
        [Display(Name = "First Name")]
        public string FirstName { get; set; }

        [Required]
        [Display(Name = "Last Name")]
        public string LastName { get; set; }

        public string Email { get; set; }

        [Display(Name = "Organisation")]
        public int OrganisationId { get; set; }

        [Display(Name = "Language")]
        public string Locale { get; set; }

        [Display(Name = "Is Virtual")]
        public bool IsVirtual { get; set; }

        [Display(Name = "Roles")]
        public IList<string> Roles { get; set; } = new List<string>();

        [Display(Name = "Two-factor Authentication")]
        public bool TwoFactorEnabled { get; set; }

        public bool ShowOrganisation => !Roles.Any(x => x == SecurityAdminUserBuilder.SecurityAdminRole);

        public List<string> AllRoles { get; set; } = new List<string>();

        public IEnumerable<SelectListItem> Languages { get; set; } = Enumerable.Empty<SelectListItem>();

        public IEnumerable<SelectListItem> Organisations { get; set; } = Enumerable.Empty<SelectListItem>();
    }
}