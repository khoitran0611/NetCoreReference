﻿using System.Collections.Generic;

namespace Hydra.UserManagement.Models.OrganisationViewModels
{
    public class ManageOrganisationViewModel
    {
        public IList<Organisation> Organisations { get; set; } = new List<Organisation>();
    }
}
