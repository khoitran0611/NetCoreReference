﻿namespace Hydra.UserManagement.Models.OrganisationViewModels
{
    public class OrganisationViewModel
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public string OrganisationContext { get; set; }
    }
}
