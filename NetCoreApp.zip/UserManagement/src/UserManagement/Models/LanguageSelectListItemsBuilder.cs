﻿using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace Hydra.UserManagement.Models
{
    public class LanguageSelectListItemsBuilder
    {
        public IEnumerable<SelectListItem> Build()
        {
            return GetLanguages()
                .Select(language => new SelectListItem(language.Description, language.Locale));            
        }

        private IEnumerable<Language> GetLanguages()
        {
            var list = new List<Language>();
            list.Add(new Language { Locale = "en-GB", Description = "English" });
            list.Add(new Language { Locale = "sv-SE", Description = "Swedish" });
            return list;
        }
    }
}
