﻿namespace Hydra.UserManagement.Models
{
    public class OrganisationUserBuilder
    {
        private readonly ApplicationUser user;
        private readonly string defaultPassword = "Passw0rd!";

        public OrganisationUserBuilder()
        {
            this.user = new ApplicationUser();
        }

        public OrganisationUserBuilder WithEmail(string email)
        {
            this.user.EmailConfirmed = true;
            this.user.Email = email;
            this.user.UserName = email;            
            return this;
        }

        public OrganisationUserBuilder WithName(string firstName, string lastName)
        {
            this.user.SetNames(firstName, lastName);
            return this;
        }

        public OrganisationUserBuilder WithOrganisation(Organisation organisation)
        {
            this.user.SetOrganisation(organisation.Id, organisation.OrganisationContext);
            return this;
        }

        public OrganisationUserBuilder WithIsVirtual(bool isVirtual)
        {
            this.user.SetIsVirtual(isVirtual);
            return this;
        }

        public OrganisationUserBuilder WithTwoFactorEnabled(bool twoFactorEnabled)
        {
            this.user.TwoFactorEnabled = twoFactorEnabled;
            return this;
        }

        public OrganisationUserBuilder WithLocale(string locale)
        {
            this.user.SetLocale(locale);
            return this;
        }

        public ApplicationUser Create()
        {
            return this.user;
        }

        public string GetDefaultPassword()
        {
            return defaultPassword;
        }
    }
}