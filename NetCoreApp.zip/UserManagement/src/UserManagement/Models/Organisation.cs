﻿namespace Hydra.UserManagement.Models
{
    public class Organisation
    {
        public int Id { get; set; }

        public string OrganisationContext { get; set; }

        public string Name { get; set; }        
    }
}