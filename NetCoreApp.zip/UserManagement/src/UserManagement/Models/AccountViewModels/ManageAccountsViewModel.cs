﻿namespace Hydra.UserManagement.Models.AccountViewModels
{
    public class ManageAccountsViewModel
    {
        public GenericPagedResult<ApplicationUser> Users { get; set; } = new GenericPagedResult<ApplicationUser>();
    }
}
