﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace Hydra.UserManagement.Models
{
    public class OrganisationSelectListItemsBuilder
    {
        private readonly IEnumerable<Organisation> organisations;
        private readonly Dictionary<string, SelectListGroup> parentContexts;
        private readonly SelectListGroup agencyParent = new SelectListGroup { Name = "Agency" };

        public OrganisationSelectListItemsBuilder(IEnumerable<Organisation> organisations)
        {
            this.organisations = organisations;
            this.parentContexts = organisations.ToDictionary(org => org.OrganisationContext, org => new SelectListGroup { Name = org.Name });
        }

        public IEnumerable<SelectListItem> Build()
        {
            return organisations.Select(org => new SelectListItem(org.Name, org.Id.ToString())
            {
                Group = GetGroup(org)
            });
        }

        private SelectListGroup GetGroup(Organisation org)
        {
            var parentContext = org.OrganisationContext.Substring(0, Math.Max(org.OrganisationContext.LastIndexOf(','), 0));
            return !string.IsNullOrEmpty(parentContext) ? parentContexts[parentContext] : agencyParent;
        }
    }
}