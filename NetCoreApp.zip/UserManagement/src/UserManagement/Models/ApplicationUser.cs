﻿using System.Collections.Generic;
using System.Linq;
using IdentityModel;
using Microsoft.AspNetCore.Identity;

namespace Hydra.UserManagement.Models
{
    public static class IdentityExtensions
    {
    }

    public class ApplicationUser : IdentityUser
    {
        public const string DisplayNameClaimType = "unique_name";
        public const string OrganisationClaimType = "http://schemas.contemi.com/ws/2014/04/identity/claims/organisation/scope";
        public const string TenantIdClaimType = "http://schemas.microsoft.com/identity/claims/tenantid";
        public const string IsVirtualClaimType = "is_virtual";

        public string FirstName { get; internal set; }

        public string LastName { get; internal set; }

        public int? OrganisationId { get; internal set; }

        public Organisation Organisation { get; set; }

        public bool IsVirtual { get; set; }

        public string Locale { get; set; }

        public virtual ICollection<IdentityUserClaim<string>> Claims { get; } = new List<IdentityUserClaim<string>>();

        public virtual ICollection<IdentityUserLogin<string>> Logins { get; } = new List<IdentityUserLogin<string>>();

        public void SetNames(string firstname, string lastname)
        {
            this.FirstName = firstname;
            this.LastName = lastname;

            AddOrUpdateClaim(JwtClaimTypes.GivenName, firstname);
            AddOrUpdateClaim(JwtClaimTypes.FamilyName, lastname);
            AddOrUpdateClaim(DisplayNameClaimType, GetDisplayName());
        }

        public void SetOrganisation(int organisationId, string organisationContext)
        {
            this.OrganisationId = organisationId;

            AddOrUpdateClaim(OrganisationClaimType, organisationContext);

            var agencyContext = organisationContext.Split(',').First();
            AddOrUpdateClaim(TenantIdClaimType, agencyContext);
        }

        public string GetDisplayName()
        {
            return $"{this.FirstName} {this.LastName}";
        }
        
        internal void SetIsVirtual(bool isVirtual)
        {
            this.IsVirtual = isVirtual;
            AddOrUpdateClaim(IsVirtualClaimType, isVirtual.ToString());
        }

        internal void SetLocale(string locale)
        {
            this.Locale = locale;
            AddOrUpdateClaim(JwtClaimTypes.Locale, locale);
        }        

        private void AddOrUpdateClaim(string claimType, string claimValue)
        {
            var matchingClaim = this.Claims.SingleOrDefault(c => c.ClaimType == claimType);
            if (matchingClaim == null)
            {
                this.Claims.Add(new IdentityUserClaim<string> { ClaimType = claimType, ClaimValue = claimValue });
            }
            else
            {
                matchingClaim.ClaimValue = claimValue;
            }
        }
    }
}