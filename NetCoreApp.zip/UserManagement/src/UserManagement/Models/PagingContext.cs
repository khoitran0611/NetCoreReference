﻿using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace Hydra.UserManagement.Models
{
    public class PagingContext
    {
        public const int DefaultItemsPerPage = 10;
        public const int MaxItemsPerPage = 100;

        public PagingContext()
        {
            this.IsPageAdjustable = false;
            this.Page = 1;
            this.ItemsPerPage = DefaultItemsPerPage;
        }

        public PagingContext(int page, int itemsPerPage = DefaultItemsPerPage)
            : this()
        {
            this.Page = page;
            if (itemsPerPage > 0 && itemsPerPage <= MaxItemsPerPage)
            {
                this.ItemsPerPage = itemsPerPage;
            }
        }

        public static PagingContext FirstPage
        {
            get
            {
                return new PagingContext(1);
            }
        }

        public int TotalItems { get; private set; }

        public int Page { get; set; }


        public int ItemsPerPage { get; private set; }

        public int TotalPages { get; private set; }

        public bool IsPageAdjustable { get; set; }

        public bool HasPages
        {
            get
            {
                return this.TotalPages > 1;
            }
        }

        public IEnumerable<SelectListItem> ItemsPerPageOptions
        {
            get
            {
                var range = new string[] { "10", "15", "25", "50", "100" };

                foreach (var linesPerPage in range)
                {
                    yield return new SelectListItem()
                    {
                        Text = linesPerPage,
                        Value = linesPerPage,
                        Selected = linesPerPage == ItemsPerPage.ToString()
                    };
                }
            }
        }

        public int Skip
        {
            get
            {
                return (this.Page - 1) * this.ItemsPerPage;
            }
        }        

        public void SetCount(int totalItems)
        {
            this.TotalItems = totalItems;
            this.TotalPages = (int)System.Math.Ceiling((double)totalItems / this.ItemsPerPage);
        }
    }
}
