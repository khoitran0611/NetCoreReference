﻿using System;
using Hydra.GlobalResources.Client;
using Hydra.UserManagement.Configuration;
using Hydra.UserManagement.Data;
using Hydra.UserManagement.Models;
using Hydra.UserManagement.Services;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace Hydra.UserManagement
{
    public class Startup
    {
        internal const string AuthenticationCookieLifetimeInHoursSetting = "AuthenticationCookieLifetimeInHours";
        private const string ApplicationName = "UserManagement";
        private readonly ILoggerFactory loggerFactory;

        public Startup(IConfiguration configuration, ILoggerFactory loggerFactory)
        {
            Configuration = configuration;
            this.loggerFactory = loggerFactory;
        }

        public IConfiguration Configuration { get; }

        public void ConfigureServices(IServiceCollection services)
        {
            services.AddDbContext<ApplicationDbContext>(options =>
                options.UseSqlServer(Configuration.GetConnectionString("DefaultConnection")));

            services.AddIdentity<ApplicationUser, IdentityRole>(config =>
            {
                config.SignIn.RequireConfirmedEmail = true;
            })
            .AddEntityFrameworkStores<ApplicationDbContext>()
            .AddDefaultTokenProviders();

            services.ConfigureApplicationCookie(options =>
            {
                options.Cookie.Expiration = TimeSpan.FromHours(Configuration.GetValue<double>(AuthenticationCookieLifetimeInHoursSetting, 12));
                options.SlidingExpiration = true;
            });

            services.Configure<SeedDataOptions>(Configuration.GetSection("SeedData"));
            services.Configure<SecurityAdminSettings>(Configuration.GetSection("SecurityAdminSettings"));
            services.Configure<MailSettings>(Configuration.GetSection("MailSettings"));
            services.Configure<ValidClients>(Configuration.GetSection("ValidClients"));
            services.Configure<GlobalResourcesClientOptions>(Configuration.GetSection("GlobalResourcesClientOptions"));
            services.Configure<SystemConfiguration>(Configuration.GetSection("SystemConfiguration"));

            services.AddTransient<IEmailSender, AuthMessageSender>();
            services.AddTransient<ISmsSender, AuthMessageSender>();
            services.AddScoped<IOrganisationSerivce, OrganisationService>();

            ConfigureIdentityServer(services);
            services.AddGlobalResourcesLocalization(Configuration.GetSection("GlobalResourcesClientOptions"));

            services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_2_1);

            services.AddHydraTelemetry(Configuration.GetSection("Telemetry"));

            ConfigureLockout(services);
        }

        public void Configure(IApplicationBuilder app, IHostingEnvironment env, ILoggerFactory loggerFactory)
        {
            app.UseReverseProxyHeaderForwarding(Configuration, loggerFactory);
            app.UsePathBase(Configuration.GetValue<string>("SSO:PathBase", "/Sso"));

            app.UseHydraTelemetry(builder => builder
                    .WithStandardTags(ApplicationName)
                    .WithFilteringOutOfFastDependencies()
                    .WithHttp400sNotAsFailure()
                    .Build());

            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                app.UseDatabaseErrorPage();
                app.UseBrowserLink();               
            }
            else
            {
                app.UseExceptionHandler($"/Home/Error");
            }

            app.UseStaticFiles();

            app.UseIdentityServer();
            app.UseGlobalResourcesLocalization();

            app.UseMvc(routes =>
            {
                routes.MapRoute(
                    name: "default",
                    template: "{controller=Manage}/{action=Index}/{id?}");
            });            
        }

        private void ConfigureIdentityServer(IServiceCollection services)
        {
            var identityServerBuilder = services.AddIdentityServer(options =>
                {
                    var configuredPublicOrigin = Configuration.GetValue<string>("SSO-PublicOrigin", string.Empty);
                    if (!string.IsNullOrWhiteSpace(configuredPublicOrigin))
                    {
                        options.PublicOrigin = configuredPublicOrigin;
                    }
                })
                .AddInMemoryPersistedGrants()
                .AddInMemoryIdentityResources(ResourcesConfig.GetIdentityResources())
                .AddInMemoryApiResources(ResourcesConfig.GetApiResources())
                .AddInMemoryClients(ClientsConfig.GetClients(this.Configuration, this.loggerFactory))
                .AddAspNetIdentity<ApplicationUser>()
                .AddExtensionGrantValidator<DelegationGrantValidator>();

            new SigningCertStrategy(this.Configuration)
                .SetSigningCredential(identityServerBuilder);
        }

        private void ConfigureLockout(IServiceCollection services)
        {
            services.Configure<IdentityOptions>(options => {
                options.Lockout.MaxFailedAccessAttempts = 10;
            });
        }
    }
}