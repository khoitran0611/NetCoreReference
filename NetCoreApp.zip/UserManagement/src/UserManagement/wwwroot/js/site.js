﻿$(function () {
    $('#itemsPerPage').change(function () {
        let searchParams = new URLSearchParams(window.location.search);

        if (searchParams.has("page")) {
            searchParams.set("page", "1");
        }
        else {
            searchParams.append("page", "1");
        }

        if (searchParams.has("itemsPerPage")) {
            searchParams.set("itemsPerPage", $(this).val());
        }
        else {
            searchParams.append("itemsPerPage", $(this).val());
        }

        window.location.href = `${window.location.pathname}?${searchParams}`;
    });    
})