﻿To read the logs content use following command:
'''ps
type stdout<rest_of_filename>
'''