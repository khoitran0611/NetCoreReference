﻿using System;
using System.Collections.Generic;
using System.Linq;
using Hydra.UserManagement.Configuration;
using IdentityServer4;
using IdentityServer4.Models;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;

namespace Hydra.UserManagement
{
    public static class ClientsConfig
    {
        public static IEnumerable<Client> GetClients(IConfiguration configuration, ILoggerFactory loggerFactory)
        {
            var logger = loggerFactory.CreateLogger("ClientConfig");

            var validClientUris = new ValidClients();
            configuration.GetSection("ValidClients").Bind(validClientUris);

            // client credentials client
            var clients = new List<Client>
            {
                // OpenID Connect hybrid flow and client credentials client (MVC)
                new Client
                {
                    ClientId = "hydra.insurance.web",
                    ClientName = "Insurance Web Client",
                    AllowedGrantTypes = GrantTypes.HybridAndClientCredentials,
                    IdentityTokenLifetime = GetTokenExpiryInSeconds(configuration),
                    AccessTokenLifetime = GetTokenExpiryInSeconds(configuration),
                    RequireConsent = false,
                    RequireClientSecret = false,

                    RedirectUris = validClientUris.InsuranceUris
                        .Select(baseUri => baseUri + "signin-oidc")
                        .ToList(),
                    PostLogoutRedirectUris = validClientUris.InsuranceUris
                        .ToList(),
                    FrontChannelLogoutUri = validClientUris.InsuranceUris
                        .Select(baseUri => baseUri + "signout-oidc")
                        .FirstOrDefault(),

                    AllowedScopes = new List<string>
                    {
                        IdentityServerConstants.StandardScopes.OpenId,
                        IdentityServerConstants.StandardScopes.Profile,
                        IdentityServerConstants.StandardScopes.Email,
                        IdentityServerConstants.StandardScopes.OfflineAccess,
                        HydraScopes.UserManagement,
                        HydraScopes.CrmTasksApi,
                        HydraScopes.HydraEventHistoryApi,
                        HydraScopes.OrganisationContext,
                        HydraScopes.HydraMotorRegistryApi
                    },
                    AllowOfflineAccess = true,
                    AlwaysIncludeUserClaimsInIdToken = true,
                    AllowAccessTokensViaBrowser = true,
                    AllowedCorsOrigins = validClientUris.InsuranceUris
                }
            };

            clients.Add(
                new Client
                {
                    ClientId = "hydra.integration",
                    ClientName = "Hydra Integration",
                    ClientSecrets = new List<Secret>
                    {
                        new Secret("PAGE-DINNER-SAFETY-must".Sha256())
                    },
                    AllowedGrantTypes = new[] { GrantType.ResourceOwnerPassword, GrantType.ClientCredentials, "delegation" },
                    AllowedScopes = new List<string>
                    {
                        HydraScopes.HydraEventHistoryApi,
                        HydraScopes.PegasusCustomerSearch,
                        HydraScopes.HydraCrsApi,
                        HydraScopes.OrganisationContext,
                        HydraScopes.HydraCpsApi,
                        HydraScopes.HydraDocumentsApi,
                        HydraScopes.ChimeraCcsApi,
                        HydraScopes.HydraMotorRegistryApi,
                        HydraScopes.CustomerManagementApi
                    },
                    AllowOfflineAccess = true,
                    AlwaysIncludeUserClaimsInIdToken = true
                });

            if (validClientUris.TestClientUris.Any())
            {
                clients.Add(
                    new Client
                    {
                        ClientId = "hydra.test.web",
                        ClientName = "Test Web Client",
                        AllowedGrantTypes = GrantTypes.HybridAndClientCredentials,
                        RequireConsent = false,

                        AllowAccessTokensViaBrowser = true,

                        RedirectUris = validClientUris.TestClientUris
                            .Select(baseUri => baseUri + "signin-oidc")
                            .ToList(),
                        PostLogoutRedirectUris = validClientUris.TestClientUris
                            .ToList(),

                        AllowedScopes = new List<string>
                        {
                            IdentityServerConstants.StandardScopes.OpenId,
                            IdentityServerConstants.StandardScopes.Profile,
                            IdentityServerConstants.StandardScopes.Email,
                            IdentityServerConstants.StandardScopes.OfflineAccess,
                            HydraScopes.UserManagement,
                            HydraScopes.HydraCpsApi,
                            HydraScopes.HydraEventHistoryApi,
                            HydraScopes.HydraMotorRegistryApi
                        },

                        AllowOfflineAccess = true,
                        AlwaysIncludeUserClaimsInIdToken = true
                    });
            }

            if (validClientUris.TestTokenClientUris.Any())
            {
                clients.Add(
                    new Client
                    {
                        ClientId = "tokenclient",
                        ClientName = "Test Token Client",
                        AllowedGrantTypes = new[] { GrantType.AuthorizationCode, GrantType.ClientCredentials, GrantType.ResourceOwnerPassword },
                        RequireConsent = false,
                        RequireClientSecret = false,

                        AllowAccessTokensViaBrowser = true,

                        RedirectUris = validClientUris.TestTokenClientUris.ToList(),
                        PostLogoutRedirectUris = validClientUris.TestTokenClientUris.ToList(),

                        AllowedScopes = new List<string>
                        {
                            IdentityServerConstants.StandardScopes.OpenId,
                            IdentityServerConstants.StandardScopes.Profile,
                            IdentityServerConstants.StandardScopes.Email,
                            IdentityServerConstants.StandardScopes.OfflineAccess,
                            HydraScopes.UserManagement,
                            HydraScopes.HydraCpsApi,
                            HydraScopes.HydraEventHistoryApi,
                            HydraScopes.HydraCrsApi,
                            HydraScopes.OrganisationContext,
                            HydraScopes.CustomerManagementApi,
                            HydraScopes.ChimeraCcsApi,
                            HydraScopes.HydraDocumentsApi,
                            HydraScopes.HydraMotorRegistryApi,
                            HydraScopes.HydraCustomerAuthentication
                        },

                        AllowOfflineAccess = true,
                        AlwaysIncludeUserClaimsInIdToken = true
                    });
            }

            if (validClientUris.SwaggerUiClientUris.Any())
            {
                clients.Add(
                    new Client
                    {
                        ClientId = "your-client-id",
                        ClientName = "swagger ui",
                        AllowedGrantTypes = GrantTypes.Implicit,
                        RequireConsent = false,

                        AllowAccessTokensViaBrowser = true,

                        RedirectUris = validClientUris.SwaggerUiClientUris.SelectMany(baseUri => new[] {
                            new Uri(baseUri, "swagger/ui/o2c.html").AbsoluteUri,
                            new Uri(baseUri, "swagger/o2c.html").AbsoluteUri,
                            new Uri(baseUri, "swagger/oauth2-redirect.html").AbsoluteUri,
                            new Uri(baseUri, "swagger/ui/o2c-html").AbsoluteUri,
                        }).ToList(),

                        AllowedScopes = new List<string>
                        {
                            IdentityServerConstants.StandardScopes.OpenId,
                            IdentityServerConstants.StandardScopes.Profile,
                            IdentityServerConstants.StandardScopes.Email,
                            IdentityServerConstants.StandardScopes.OfflineAccess,
                            HydraScopes.UserManagement,
                            HydraScopes.HydraCpsApi,
                            HydraScopes.HydraEventHistoryApi,
                            HydraScopes.HydraCrsApi,
                            HydraScopes.OrganisationContext,
                            HydraScopes.CustomerManagementApi,
                            HydraScopes.HydraDocumentsApi,
                            HydraScopes.ChimeraCcsApi,
                            HydraScopes.HydraMotorRegistryApi
                        },

                        AllowOfflineAccess = true,
                        AlwaysIncludeUserClaimsInIdToken = true
                    });
            }

            if (validClientUris.CrmUris.Any())
            {
                clients.Add(
                    new Client
                    {
                        ClientId = "pegasus.crm.web",
                        ClientName = "CRM Web",
                        AllowedGrantTypes = GrantTypes.HybridAndClientCredentials,
                        RequireConsent = false,

                        AllowAccessTokensViaBrowser = true,

                        RedirectUris = validClientUris.CrmUris
                            .Select(baseUri => baseUri + "signin-oidc")
                            .ToList(),
                        PostLogoutRedirectUris = validClientUris.CrmUris
                            .ToList(),
                        FrontChannelLogoutUri = validClientUris.CrmUris
                            .Select(baseUri => baseUri + "signout-oidc")
                            .FirstOrDefault(),

                        AllowedScopes = new List<string>
                        {
                            IdentityServerConstants.StandardScopes.OpenId,
                            IdentityServerConstants.StandardScopes.Profile,
                            IdentityServerConstants.StandardScopes.Email,
                            IdentityServerConstants.StandardScopes.OfflineAccess,
                            HydraScopes.UserManagement,
                            HydraScopes.HydraCpsApi,
                            HydraScopes.HydraCrsApi,
                            HydraScopes.OrganisationContext,
                            HydraScopes.PegasusCustomerSearch,
                            HydraScopes.ChimeraCcsApi,
                            HydraScopes.OrganisationContext,
                            HydraScopes.HydraMotorRegistryApi,
                            HydraScopes.HydraCustomerAuthentication
                        },

                        AllowOfflineAccess = true,
                        AlwaysIncludeUserClaimsInIdToken = true
                    });
            }

            if (validClientUris.CrsClientUris.Any())
            {
                clients.Add(
                    new Client
                    {
                        ClientId = "hydra.crs.web",
                        ClientName = "CRS Frontend",
                        AllowedGrantTypes = GrantTypes.ImplicitAndClientCredentials,
                        RequireConsent = false,
                        RequireClientSecret = false,
                        AllowAccessTokensViaBrowser = true,
                        RedirectUris = validClientUris.CrsClientUris.Select(uri => new Uri(uri.BaseUri, uri.RelativeUri).AbsoluteUri).ToList(),
                        PostLogoutRedirectUris = validClientUris.CrsClientUris.Select(uri => uri.BaseUri.AbsoluteUri).ToList(),

                        AllowedCorsOrigins = validClientUris.CrsClientUris.Select(uri => uri.BaseUri.AbsoluteUri).ToList(),

                        AllowedScopes = new List<string>
                        {
                            IdentityServerConstants.StandardScopes.OpenId,
                            IdentityServerConstants.StandardScopes.Profile,
                            IdentityServerConstants.StandardScopes.Email,
                            IdentityServerConstants.StandardScopes.OfflineAccess,
                            HydraScopes.HydraCrsWeb,
                            HydraScopes.HydraCrsApi,
                            HydraScopes.OrganisationContext,
                            HydraScopes.HydraCpsApi,
                            HydraScopes.HydraDocumentsApi
                        },

                        AlwaysSendClientClaims = true,
                        AllowOfflineAccess = true,
                        AlwaysIncludeUserClaimsInIdToken = true
                    });
            }

            var cpsApiTestClientUris = validClientUris.CpsTestClientUris;
            if (cpsApiTestClientUris.Any())
            {
                clients.Add(
                    new Client
                    {
                        ClientId = "hydra.cps.api.testwebui",
                        ClientName = "CPS Test Frontend",
                        AllowedGrantTypes = GrantTypes.ImplicitAndClientCredentials,
                        RequireConsent = false,
                        RequireClientSecret = false,
                        AllowAccessTokensViaBrowser = true,
                        RedirectUris = cpsApiTestClientUris.Select(uri => new Uri(uri.BaseUri, uri.RelativeUri).AbsoluteUri).ToList(),
                        PostLogoutRedirectUris = cpsApiTestClientUris.Select(uri => uri.BaseUri.AbsoluteUri).ToList(),

                        AllowedCorsOrigins = cpsApiTestClientUris.Select(uri => uri.BaseUri.AbsoluteUri).ToList(),

                        AllowedScopes = new List<string>
                        {
                            IdentityServerConstants.StandardScopes.OpenId,
                            IdentityServerConstants.StandardScopes.Profile,
                            IdentityServerConstants.StandardScopes.Email,
                            IdentityServerConstants.StandardScopes.OfflineAccess,
                            HydraScopes.HydraCpsApi,
                            HydraScopes.OrganisationContext,
                            HydraScopes.HydraMotorRegistryApi
                        },

                        AllowOfflineAccess = true,
                        AlwaysIncludeUserClaimsInIdToken = true
                    });
            }

            if (validClientUris.CcsClientUris.Any())
            {
                clients.Add(new Client
                {
                    ClientId = "chimera.ccs.web",
                    ClientName = "Claims Client",
                    AllowedGrantTypes = new[] { GrantType.Hybrid, GrantType.ClientCredentials, GrantType.ResourceOwnerPassword },
                    IdentityTokenLifetime = GetTokenExpiryInSeconds(configuration),
                    AccessTokenLifetime = GetTokenExpiryInSeconds(configuration),
                    RequireConsent = false,

                    RedirectUris = validClientUris.CcsClientUris.ToList(),
                    PostLogoutRedirectUris = validClientUris.CcsClientUris.ToList(),
                    FrontChannelLogoutUri = validClientUris.CcsClientUris
                        .Select(baseUri => baseUri + "signout-oidc")
                        .FirstOrDefault(),

                    ClientSecrets = new List<Secret>
                    {
                        new Secret("CCS-CRS-Integration-RAND".Sha256())
                    },

                    AllowedScopes = new List<string>
                    {
                        IdentityServerConstants.StandardScopes.OpenId,
                        IdentityServerConstants.StandardScopes.Profile,
                        IdentityServerConstants.StandardScopes.Email,
                        IdentityServerConstants.StandardScopes.OfflineAccess,
                        HydraScopes.UserManagement,
                        HydraScopes.ChimeraCcsWeb,
                        HydraScopes.ChimeraCcsApi,
                        HydraScopes.HydraCrsApi,
                        HydraScopes.OrganisationContext,
                        HydraScopes.HydraDocumentsApi
                    },

                    AllowOfflineAccess = true,
                    AlwaysIncludeUserClaimsInIdToken = true,
                    AllowAccessTokensViaBrowser = true
                });
            }

            clients.Add(
                new Client
                {
                    ClientId = "customer.web",
                    ClientName = "Customer services",
                    AllowedGrantTypes = GrantTypes.HybridAndClientCredentials,
                    RequireConsent = false,
                    AllowAccessTokensViaBrowser = true,

                    RedirectUris = validClientUris.CustomerClientUris
                        .Select(baseUri => baseUri + "signin-oidc")
                        .ToList(),
                    PostLogoutRedirectUris = validClientUris.CustomerClientUris.ToList(),
                    FrontChannelLogoutUri = validClientUris.CustomerClientUris
                        .Select(baseUri => baseUri + "signout-oidc")
                        .FirstOrDefault(),

                    ClientSecrets = new List<Secret>
                    {
                        new Secret("testsecret".Sha256())
                    },
                    AllowedScopes = new List<string>
                    {
                        IdentityServerConstants.StandardScopes.OpenId,
                        IdentityServerConstants.StandardScopes.Profile,
                        IdentityServerConstants.StandardScopes.Email,
                        IdentityServerConstants.StandardScopes.OfflineAccess,
                        HydraScopes.CustomerManagementApi,
                        HydraScopes.HydraCpsApi,
                        HydraScopes.OrganisationContext,
                        HydraScopes.HydraMotorRegistryApi
                    },
                    AllowOfflineAccess = true,
                    AlwaysIncludeUserClaimsInIdToken = true,

                    AllowedCorsOrigins = validClientUris.CustomerClientUris
                });

            clients.Add(
                // OpenID Connect hybrid flow and client credentials client (MVC)
                new Client
                {
                    ClientId = "hydra.documents.web",
                    ClientName = "Documents Web Client",
                    AllowedGrantTypes = GrantTypes.HybridAndClientCredentials,
                    RequireConsent = false,
                    RequireClientSecret = false,

                    RedirectUris = validClientUris.DocumentWebUris
                        .Select(baseUri => baseUri + "signin-oidc")
                        .ToList(),
                    PostLogoutRedirectUris = validClientUris.DocumentWebUris
                        .ToList(),
                    FrontChannelLogoutUri = validClientUris.DocumentWebUris
                        .Select(baseUri => baseUri + "signout-oidc")
                        .FirstOrDefault(),

                    AllowedScopes = new List<string>
                    {
                        IdentityServerConstants.StandardScopes.OpenId,
                        IdentityServerConstants.StandardScopes.Profile,
                        IdentityServerConstants.StandardScopes.Email,
                        IdentityServerConstants.StandardScopes.OfflineAccess,
                        HydraScopes.UserManagement,
                        HydraScopes.OrganisationContext,
                        HydraScopes.HydraCustomerAuthentication
                    },
                    AllowOfflineAccess = true,
                    AlwaysIncludeUserClaimsInIdToken = true,
                    AllowAccessTokensViaBrowser = true
                });

            clients.Add(
                new Client
                {
                    ClientId = "hydra.motorregistry.web",
                    ClientName = "MotorRegistry Web Client",
                    AllowedGrantTypes = GrantTypes.HybridAndClientCredentials,
                    RequireConsent = false,
                    AllowAccessTokensViaBrowser = true,

                    RedirectUris = validClientUris.MotorRegistryWebUris
                        .Select(baseUri => baseUri + "signin-oidc")
                        .ToList(),
                    PostLogoutRedirectUris = validClientUris.MotorRegistryWebUris.ToList(),
                    FrontChannelLogoutUri = validClientUris.MotorRegistryWebUris
                        .Select(baseUri => baseUri + "signout-oidc")
                        .FirstOrDefault(),

                    ClientSecrets = new List<Secret>
                    {
                        new Secret("testsecret".Sha256())
                    },
                    AllowedScopes = new List<string>
                    {
                        IdentityServerConstants.StandardScopes.OpenId,
                        IdentityServerConstants.StandardScopes.Profile,
                        IdentityServerConstants.StandardScopes.Email,
                        IdentityServerConstants.StandardScopes.OfflineAccess,
                        HydraScopes.UserManagement,
                        HydraScopes.CustomerManagementApi,
                        HydraScopes.HydraMotorRegistryApi,
                        HydraScopes.HydraCpsApi,
                        HydraScopes.OrganisationContext
                    },
                    AllowOfflineAccess = true,
                    AlwaysIncludeUserClaimsInIdToken = true,

                    AllowedCorsOrigins = validClientUris.MotorRegistryWebUris
                });

            clients.Add(
                new Client
                {
                    ClientId = "hydra.customerauthentication.web",
                    ClientName = "Customer Authentication Web",
                    AllowedGrantTypes = GrantTypes.ClientCredentials,
                    RequireConsent = false,
                    AllowAccessTokensViaBrowser = true,

                    RedirectUris = validClientUris.CustomerAuthenticationWebUris
                        .Select(baseUri => baseUri + "signin-oidc")
                        .ToList(),
                    PostLogoutRedirectUris = validClientUris.CustomerAuthenticationWebUris.ToList(),

                    ClientSecrets = new List<Secret>
                    {
                        new Secret("testsecret".Sha256())
                    },
                    AllowedScopes = new List<string>
                    {
                        HydraScopes.CustomerManagementApi
                    },
                    AlwaysIncludeUserClaimsInIdToken = true,
                });

            logger.LogInformation($"Loaded Valid Clients: {JsonConvert.SerializeObject(validClientUris, Formatting.Indented)}");

            return clients;
        }

        private static int GetTokenExpiryInSeconds(IConfiguration configuration)
        {
            return (int)TimeSpan.FromHours(configuration.GetValue<double>(Startup.AuthenticationCookieLifetimeInHoursSetting, 12)).TotalSeconds;
        }
    }
}