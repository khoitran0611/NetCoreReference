﻿namespace Hydra.UserManagement
{
    public class LoggingEvents
    {
        public const int UserLoggedIn = 1;
        public const int AccountLockedOut = 2;
        public const int AccountManagement = 3;
        public const int StoreStatus = 4;
        public const int OrganisationManagement = 5;
    }
}
