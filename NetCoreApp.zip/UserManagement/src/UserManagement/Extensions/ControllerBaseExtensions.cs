﻿using System.Collections.Generic;
using System.Linq;
using Hydra.UserManagement.Configuration;
using Hydra.UserManagement.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace Hydra.UserManagement.Extensions
{
    public enum ManageMessageId
    {
        AddLoginSuccess,
        ChangePasswordSuccess,
        SetPasswordSuccess,
        RemoveLoginSuccess,
        UpdateProfileSuccess,
        UpdateOrganisationSuccess,
        Error,
    }

    public static class ControllerBaseExtensions
    {
        public static string GetStatusMessage(this ControllerBase controller, ManageMessageId? message)
        {
            switch (message)
            {
                case ManageMessageId.ChangePasswordSuccess:
                    return "Your password has been changed.";

                case ManageMessageId.SetPasswordSuccess:
                    return "Your password has been set.";

                case ManageMessageId.UpdateProfileSuccess:
                    return "Your profile has been updated.";

                case ManageMessageId.UpdateOrganisationSuccess:
                    return "The organisation has been updated.";

                case ManageMessageId.Error:
                    return "An error has occurred.";

                default:
                    return "";
            }
        }

        public static IEnumerable<string> GetRoles(this ControllerBase controller, RoleManager<IdentityRole> roleManager, SystemConfiguration systemConfiguration)
        {
            var roles = roleManager.Roles.Select(x => x.Name);
            if (!controller.HttpContext.User.IsInRole(SecurityAdminUserBuilder.SecurityAdminRole))
            {
                roles = roles.Except(systemConfiguration.RolesAllowedOnlyForSecurityAdmin);
            }

            return roles;
        }
    }
}
