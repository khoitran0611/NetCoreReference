﻿using System;
using System.Threading.Tasks;
using Hydra.UserManagement.Data;
using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Serilog;

namespace Hydra.UserManagement
{
    public class Program
    {
        public static async Task Main(string[] args)
        {
            var host = CreateWebHostBuilder(args).Build();
            using (var scope = host.Services.CreateScope())
            {
                var scopedServices = scope.ServiceProvider;
                var logger = scopedServices.GetRequiredService<ILogger<DataSeeder>>();

                try
                {
                    var seeder = new DataSeeder(scopedServices, logger);
                    await seeder.SeedData();
                }
                catch (Exception ex)
                {
                    logger.LogError(ex, "An error occurred seeding the DB.");
                }
            }
            await host.RunAsync();
        }

        public static IWebHostBuilder CreateWebHostBuilder(string[] args) =>
            WebHost.CreateDefaultBuilder(args)
                .ConfigureLogging((context, logging) =>
                {
                    logging.ClearProviders();
                    logging.AddConfiguration(context.Configuration.GetSection("Logging"));
                    logging.AddConsole();
                    logging.AddDebug();
                    logging.AddSerilog(CreateSerilogLogger(context.Configuration), dispose: true);
                })
                .UseStartup<Startup>();

        private static Serilog.Core.Logger CreateSerilogLogger(IConfiguration config)
        {
            const int FileSizeLimit20MB = 20_971_520;
            return new LoggerConfiguration()
                .Enrich.FromLogContext()
                .MinimumLevel.Verbose()
                .WriteTo
                    .RollingFile(
                        config.GetValue("Logging:RollingFile:FilePath", "logs/UM-rolling_log-{Date}.txt"),
                        fileSizeLimitBytes: FileSizeLimit20MB,
                        retainedFileCountLimit: config.GetValue("Logging:RollingFile:RetainedFileCountLimit", 10),
                        buffered: config.GetValue("Logging:RollingFile:IsBuffered", true),
                        flushToDiskInterval: config.GetValue("Logging:RollingFile:FlushToDiskIntervalInSeconds", TimeSpan.FromSeconds(5)))
                .CreateLogger();
        }
    }
}