﻿using System.Linq;
using System.Threading.Tasks;
using Hydra.UserManagement.Configuration;
using Hydra.UserManagement.Extensions;
using Hydra.UserManagement.Models;
using Hydra.UserManagement.Models.ManageViewModels;
using Hydra.UserManagement.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace Hydra.UserManagement.Controllers
{
    [Authorize]
    public class ManageController : Controller
    {
        private readonly UserManager<ApplicationUser> userManager;
        private readonly RoleManager<IdentityRole> roleManager;
        private readonly SignInManager<ApplicationUser> signInManager;
        private readonly ILogger logger;
        private readonly IOrganisationSerivce organisationService;
        private readonly SystemConfiguration systemConfiguration;

        public ManageController(
        UserManager<ApplicationUser> userManager,
        RoleManager<IdentityRole> roleManager,
        SignInManager<ApplicationUser> signInManager,
        ILoggerFactory loggerFactory,
        IOrganisationSerivce organisationService,
        IOptions<SystemConfiguration> systemConfiguration)
        {
            this.userManager = userManager;
            this.roleManager = roleManager;
            this.signInManager = signInManager;
            logger = loggerFactory.CreateLogger<ManageController>();
            this.organisationService = organisationService;
            this.systemConfiguration = systemConfiguration.Value;
        }        

        [HttpGet]
        public async Task<IActionResult> Index(ManageMessageId? message = null, string userName = "")
        {
            ViewData["StatusMessage"] = this.GetStatusMessage(message);

            var loggedInUser = await GetCurrentUserAsync();
            var selectedUser = await GetCurrentUserAsync(userName);
            if (selectedUser == null)
            {
                return View("Error");
            }

            if (loggedInUser != selectedUser && !User.IsInRole(Roles.UserAdmin))
            {
                return this.Forbid(); 
            }

            var roles = await userManager.GetRolesAsync(selectedUser);
            bool selectedUserHasPassword = await userManager.HasPasswordAsync(selectedUser);
            bool canChangePassword = selectedUserHasPassword && loggedInUser.Id.Equals(selectedUser.Id);
            var model = new IndexViewModel
            {
                HasPassword = selectedUserHasPassword,
                CanChangePassword = canChangePassword,
                FirstName = selectedUser.FirstName,
                LastName = selectedUser.LastName,
                Email = selectedUser.Email,
                OrganisationId = selectedUser.OrganisationId ?? 0,
                IsVirtual = selectedUser.IsVirtual,
                Locale = selectedUser.Locale,
                Roles = roles,
                AllRoles = this.GetRoles(roleManager, systemConfiguration).ToList(),
                Organisations = new OrganisationSelectListItemsBuilder(organisationService.GetOrganisations()).Build(),
                Languages = new LanguageSelectListItemsBuilder().Build(),
                TwoFactorEnabled = selectedUser.TwoFactorEnabled
            };
            
            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Index(IndexViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }
            var updatedUser = await GetCurrentUserWithClaimsAsync(model.Email);
            if (updatedUser != null)
            {
                updatedUser.SetNames(model.FirstName, model.LastName);

                if (User.IsInRole(Roles.UserAdmin))
                {
                    if (model.OrganisationId != 0 && model.ShowOrganisation)
                    {
                        organisationService.SetOrganisation(updatedUser, model.OrganisationId);
                    }
                    
                    updatedUser.SetLocale(model.Locale);

                    if (User.IsInRole(SecurityAdminUserBuilder.SecurityAdminRole))
                    {
                        updatedUser.SetIsVirtual(model.IsVirtual);
                        updatedUser.TwoFactorEnabled = model.TwoFactorEnabled;
                    }

                    var existingRoles = await userManager.GetRolesAsync(updatedUser);

                    await userManager.RemoveFromRolesAsync(updatedUser, existingRoles.Except(model.Roles));
                    await userManager.AddToRolesAsync(updatedUser, model.Roles.Except(existingRoles));
                }

                var result = await userManager.UpdateAsync(updatedUser);

                if (result.Succeeded)
                {
                    logger.LogInformation(LoggingEvents.AccountManagement, "User updated profile successfully.");
                    return RedirectToAction(nameof(Index), new { Message = ManageMessageId.UpdateProfileSuccess, userName = updatedUser.UserName });
                }
                AddErrors(result);
                return View(model);
            }
            return RedirectToAction(nameof(Index), new { Message = ManageMessageId.Error });
        }

        [HttpGet]
        public IActionResult ChangePassword()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ChangePassword(ChangePasswordViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }
            var user = await GetCurrentUserAsync();
            if (user != null)
            {
                var result = await userManager.ChangePasswordAsync(user, model.OldPassword, model.NewPassword);
                if (result.Succeeded)
                {
                    await signInManager.SignInAsync(user, isPersistent: false);
                    logger.LogInformation(LoggingEvents.AccountManagement, "User changed their password successfully.");
                    return RedirectToAction(nameof(Index), new { Message = ManageMessageId.ChangePasswordSuccess });
                }
                AddErrors(result);
                return View(model);
            }
            return RedirectToAction(nameof(Index), new { Message = ManageMessageId.Error });
        }

        [HttpGet]
        public IActionResult SetPassword()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> SetPassword(SetPasswordViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            var user = await GetCurrentUserAsync();
            if (user != null)
            {
                var result = await userManager.AddPasswordAsync(user, model.NewPassword);
                if (result.Succeeded)
                {
                    await signInManager.SignInAsync(user, isPersistent: false);
                    return RedirectToAction(nameof(Index), new { Message = ManageMessageId.SetPasswordSuccess });
                }
                AddErrors(result);
                return View(model);
            }
            return RedirectToAction(nameof(Index), new { Message = ManageMessageId.Error });
        }

        private void AddErrors(IdentityResult result)
        {
            foreach (var error in result.Errors)
            {
                ModelState.AddModelError(string.Empty, error.Description);
            }
        }

        private Task<ApplicationUser> GetCurrentUserAsync(string userName = "")
        {
            if (string.IsNullOrWhiteSpace(userName))
            {
                return userManager.GetUserAsync(HttpContext.User);
            }

            return userManager.FindByNameAsync(userName);
        }

        private Task<ApplicationUser> GetCurrentUserWithClaimsAsync(string userName = "")
        {
            var name = string.IsNullOrWhiteSpace(userName) ? HttpContext.User.Identity.Name : userName;
            return userManager.Users
                    .Where(u => u.UserName == name)
                    .Include(u => u.Claims)
                    .SingleAsync();
        }        
    }
}