﻿using System;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Hydra.UserManagement.Configuration;
using Hydra.UserManagement.Extensions;
using Hydra.UserManagement.Models;
using Hydra.UserManagement.Models.AccountViewModels;
using Hydra.UserManagement.Services;
using IdentityServer4.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace Hydra.UserManagement.Controllers
{
    [Authorize]
    public class AccountController : Controller
    {
        private readonly UserManager<ApplicationUser> userManager;
        private readonly SignInManager<ApplicationUser> signInManager;
        private readonly RoleManager<IdentityRole> roleManager;
        private readonly IEmailSender emailSender;
        private readonly ILogger logger;
        private readonly IIdentityServerInteractionService interaction;
        private readonly IOrganisationSerivce organisationService;
        private readonly SystemConfiguration systemConfiguration;

        public AccountController(
            IIdentityServerInteractionService interaction,
            UserManager<ApplicationUser> userManager,
            SignInManager<ApplicationUser> signInManager,
            RoleManager<IdentityRole> roleManager,
            IEmailSender emailSender,
            ILoggerFactory loggerFactory,
            IOrganisationSerivce organisationService,
            IOptions<SystemConfiguration> systemConfiguration)
        {
            this.interaction = interaction;
            this.userManager = userManager;
            this.signInManager = signInManager;
            this.roleManager = roleManager;
            this.emailSender = emailSender;
            logger = loggerFactory.CreateLogger<AccountController>();
            this.organisationService = organisationService;
            this.systemConfiguration = systemConfiguration.Value;
        }

        [HttpGet]
        [AllowAnonymous]
        public IActionResult Login(string returnUrl = null)
        {
            ViewData["ReturnUrl"] = returnUrl;
            return View();
        }

        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(LoginViewModel model, string returnUrl = null)
        {
            ViewData["ReturnUrl"] = returnUrl;
            if (ModelState.IsValid)
            {
                var user = await userManager.FindByNameAsync(model.Email);
                if (await IsEmailConfirmed(user))
                {
                    ModelState.AddModelError(string.Empty, "You must have a confirmed email to log in.");
                    return View(model);
                }

                var result = await PasswordSignInWithLockoutOnFailures(user, model);
                if (result.Succeeded)
                {
                    logger.LogInformation(LoggingEvents.UserLoggedIn, "User logged in.");
                    return RedirectToLocal(returnUrl);
                }
                if (result.RequiresTwoFactor)
                {
                    try
                    {
                        var verificationCode = await userManager.GenerateTwoFactorTokenAsync(user, TokenOptions.DefaultEmailProvider);
                        await emailSender.SendEmailAsync(model.Email, "Verification Code", GetVerificationCodeEmailTemplate(verificationCode));
                    }
                    catch (Exception ex)
                    {
                        logger.LogError(LoggingEvents.UserLoggedIn, ex, "Error in emailing verification code.");
                        ModelState.AddModelError(string.Empty, "Error in emailing verification code.");
                        return View(model);
                    }
                    return RedirectToAction("LoginWith2FA", new { returnUrl });
                }
                if (result.IsLockedOut)
                {
                    logger.LogWarning(LoggingEvents.AccountLockedOut, "User account locked out.");
                    return View("Lockout");
                }
                else
                {
                    ModelState.AddModelError(string.Empty, "Invalid login attempt.");
                    return View(model);
                }
            }

            return View(model);
        }

        [HttpGet]
        [AllowAnonymous]
        public IActionResult LoginWith2FA(string returnUrl = null)
        {
            ViewData["ReturnUrl"] = returnUrl;
            return View(new LoginWith2FAViewModel());
        }

        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> LoginWith2FA(LoginWith2FAViewModel model, string returnUrl = null)
        {
            ViewData["ReturnUrl"] = returnUrl;

            if (ModelState.IsValid)
            {
                var user = await signInManager.GetTwoFactorAuthenticationUserAsync();
                if (user == null)
                {
                    throw new InvalidOperationException($"Unable to load two-factor authentication user.");
                }

                var verificationCode = model.TwoFactorCode.Replace(" ", string.Empty).Replace("-", string.Empty);

                var result = await signInManager.TwoFactorSignInAsync(TokenOptions.DefaultEmailProvider, verificationCode, model.RememberMe, model.RememberMachine);

                if (result.Succeeded)
                {
                    logger.LogInformation("User with ID '{UserId}' logged in with 2FA.", user.Id);
                    return RedirectToLocal(returnUrl);
                }
                else if (result.IsLockedOut)
                {
                    logger.LogWarning("User with ID '{UserId}' account locked out.", user.Id);
                    return View("Lockout");
                }
                else
                {
                    logger.LogWarning("Invalid verification code entered for user with ID '{UserId}'.", user.Id);
                    ModelState.AddModelError(nameof(model.TwoFactorCode), "Invalid verification code.");
                    return View(model);
                }
            }

            return View(model);
        }

        [HttpGet]
        [Authorize(Roles = Roles.UserAdmin)]
        public IActionResult Register(string returnUrl = null)
        {
            ViewData["ReturnUrl"] = returnUrl;

            var viewModel = new RegisterViewModel
            {
                IsVirtual = systemConfiguration.DefaultIsVirtual,
                TwoFactorEnabled = systemConfiguration.Default2FA
            };

            PopulateSelectListsForRegistration(viewModel);

            return View(viewModel);
        }

        [HttpPost]
        [Authorize(Roles = Roles.UserAdmin)]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Register(RegisterViewModel model, string returnUrl = null)
        {
            ViewData["ReturnUrl"] = returnUrl;
            if (ModelState.IsValid)
            {
                var user = new ApplicationUser { UserName = model.Email, Email = model.Email };
                user.SetNames(model.FirstName, model.LastName);
                organisationService.SetOrganisation(user, model.OrganisationId);
                user.SetLocale(model.Locale);
                if (HttpContext.User.IsInRole(SecurityAdminUserBuilder.SecurityAdminRole))
                {
                    user.SetIsVirtual(model.IsVirtual);
                    user.TwoFactorEnabled = model.TwoFactorEnabled;
                }
                else
                {
                    user.SetIsVirtual(systemConfiguration.DefaultIsVirtual);
                    user.TwoFactorEnabled = systemConfiguration.Default2FA;
                }

                var result = await userManager.CreateAsync(user, model.Password);
                if (result.Succeeded)
                {
                    await userManager.AddToRolesAsync(user, model.Roles);

                    var code = await userManager.GenerateEmailConfirmationTokenAsync(user);
                    var callbackUrl = Url.Action("ConfirmEmail", "Account", new { userId = user.Id, code }, protocol: HttpContext.Request.Scheme);

                    try
                    {
                        await emailSender.SendEmailAsync(model.Email, "Confirm your account", GetRegisterEmailTemplate(callbackUrl));
                    }
                    catch (Exception exception)
                    {
                        logger.LogWarning(exception, "Failed to send registration email for user {0}", model.Email);
                    }

                    logger.LogInformation(LoggingEvents.AccountManagement, "User created a new account with password.");

                    return RedirectToLocal(returnUrl, user.UserName);
                }
                AddErrors(result);
            }

            PopulateSelectListsForRegistration(model);

            return View(model);
        }

        [HttpGet]
        [AllowAnonymous]
        public async Task<IActionResult> ConfirmEmail(string userId, string code)
        {
            if (userId == null || code == null)
            {
                logger.LogError(LoggingEvents.AccountManagement, "userId or code is null");
                return View("Error");
            }
            var user = await userManager.FindByIdAsync(userId);
            if (user == null)
            {
                logger.LogError(LoggingEvents.AccountManagement, $"user with id {userId} not found");
                return View("Error");
            }
            var result = await userManager.ConfirmEmailAsync(user, code);
            if (result.Errors.Any())
            {
                foreach (var error in result.Errors)
                {
                    logger.LogError(LoggingEvents.AccountManagement, error.Description);
                }
            }

            return View(result.Succeeded ? "ConfirmEmail" : "Error");
        }

        [HttpGet]
        [AllowAnonymous]
        public IActionResult ForgotPassword()
        {
            return View();
        }

        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ForgotPassword(ForgotPasswordViewModel model)
        {
            if (ModelState.IsValid)
            {
                var user = await userManager.FindByNameAsync(model.Email);
                if (user == null || !(await userManager.IsEmailConfirmedAsync(user)))
                {
                    // Don't reveal that the user does not exist or is not confirmed
                    return View("ForgotPasswordConfirmation");
                }

                var code = await userManager.GeneratePasswordResetTokenAsync(user);
                var callbackUrl = Url.Action("ResetPassword", "Account", new { userId = user.Id, code }, protocol: HttpContext.Request.Scheme);

                await emailSender.SendEmailAsync(model.Email, "Reset Password", GetResetPasswordEmailTemplate(callbackUrl));

                return View("ForgotPasswordConfirmation");
            }

            return View(model);
        }

        [HttpGet]
        [AllowAnonymous]
        public IActionResult ForgotPasswordConfirmation()
        {
            return View();
        }

        [HttpGet]
        [AllowAnonymous]
        public IActionResult ResetPassword(string code = null)
        {
            return code == null ? View("Error") : View();
        }

        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ResetPassword(ResetPasswordViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }
            var user = await userManager.FindByNameAsync(model.Email);
            if (user == null)
            {
                // Don't reveal that the user does not exist
                return RedirectToAction(nameof(AccountController.ResetPasswordConfirmation), "Account");
            }
            var result = await userManager.ResetPasswordAsync(user, model.Code, model.Password);
            if (result.Succeeded)
            {
                return RedirectToAction(nameof(AccountController.ResetPasswordConfirmation), "Account");
            }
            AddErrors(result);
            return View();
        }

        [HttpGet]
        [AllowAnonymous]
        public IActionResult ResetPasswordConfirmation()
        {
            return View();
        }

        [HttpGet]
        public IActionResult Logout(string logoutId)
        {
            var vm = new LogoutViewModel
            {
                LogoutId = logoutId
            };

            return View(vm);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Logout(LogoutViewModel model)
        {
            // get context information (client name, post logout redirect URI and iframe for federated signout)
            var logout = await interaction.GetLogoutContextAsync(model.LogoutId);
            var vm = new LoggedOutViewModel
            {
                PostLogoutRedirectUri = logout?.PostLogoutRedirectUri,
                ClientName = logout?.ClientId,
                SignOutIframeUrl = logout?.SignOutIFrameUrl
            };

            if (User?.Identity.IsAuthenticated ?? false)
            {
                await this.signInManager.SignOutAsync();
            }

            HttpContext.User = new ClaimsPrincipal(new ClaimsIdentity());

            return View("LoggedOut", vm);
        }

        [HttpGet]
        [Authorize(Roles = Roles.UserAdmin)]
        public IActionResult ManageAccounts(int page = 1, int itemsPerPage = PagingContext.DefaultItemsPerPage)
        {
            var model = new ManageAccountsViewModel
            {
                Users = GetUsers(new PagingContext(page, itemsPerPage)
                {
                    IsPageAdjustable = true
                })
            };
            return View(model);
        }

        private void AddErrors(IdentityResult result)
        {
            foreach (var error in result.Errors)
            {
                ModelState.AddModelError(string.Empty, error.Description);
            }
        }

        private IActionResult RedirectToLocal(string returnUrl, string userName = "")
        {
            if (Url.IsLocalUrl(returnUrl))
            {
                return Redirect(returnUrl);
            }
            else
            {
                return RedirectToAction(
                    nameof(ManageController.Index),
                    nameof(ManageController).Replace("Controller", string.Empty),
                    new { userName });
            }
        }

        private string GetRegisterEmailTemplate(string callbackUrl)
        {
            return $"Please confirm your account by clicking this link: <a href='{callbackUrl}'>link</a>";
        }

        private string GetResetPasswordEmailTemplate(string callbackUrl)
        {
            return $"Please reset your password by clicking here: <a href='{callbackUrl}'>link</a>";
        }

        private string GetVerificationCodeEmailTemplate(string verificationCode)
        {
            return $"Your verification code is: <h3>{verificationCode}</h3>";
        }

        private GenericPagedResult<ApplicationUser> GetUsers(PagingContext pagingContext)
        {
            var users = userManager.Users.Include(x => x.Organisation).OrderBy(x => x.UserName);

            pagingContext.SetCount(users.Count());

            return new GenericPagedResult<ApplicationUser>(users, pagingContext);
        }

        private void PopulateSelectListsForRegistration(RegisterViewModel viewModel)
        {
            viewModel.AllRoles = this.GetRoles(roleManager, systemConfiguration).ToList();
            viewModel.Organisations = new OrganisationSelectListItemsBuilder(organisationService.GetOrganisations()).Build();
            viewModel.Languages = new LanguageSelectListItemsBuilder().Build();
        }

        private async Task<bool> IsEmailConfirmed(ApplicationUser user)
        {
            return user != null && !await userManager.IsEmailConfirmedAsync(user);
        }

        private async Task<Microsoft.AspNetCore.Identity.SignInResult> PasswordSignInWithLockoutOnFailures(ApplicationUser user, LoginViewModel model)
        {
            var shouldEnableLockoutOnFailure = !user?.TwoFactorEnabled ?? false;

            return await signInManager.PasswordSignInAsync(model.Email, model.Password, model.RememberMe, lockoutOnFailure: shouldEnableLockoutOnFailure);
        }
    }
}