using System.Linq;
using Hydra.UserManagement;
using Hydra.UserManagement.Extensions;
using Hydra.UserManagement.Models;
using Hydra.UserManagement.Models.OrganisationViewModels;
using Hydra.UserManagement.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace UserManagement.Controllers
{
    [Authorize(Roles = SecurityAdminUserBuilder.SecurityAdminRole)]
    public class OrganisationController : Controller
    {
        private readonly IOrganisationSerivce organisationService;
        private readonly ILogger logger;

        public OrganisationController(
            IOrganisationSerivce organisationService, 
            ILoggerFactory loggerFactory)
        {
            this.organisationService = organisationService;
            logger = loggerFactory.CreateLogger<OrganisationController>();
        }

        [HttpGet]
        public IActionResult Index()
        {
            var model = new ManageOrganisationViewModel
            {
                Organisations = organisationService.GetOrganisations().OrderBy(x => x.Name).ToList()
            };

            return View(model);
        }

        [HttpGet]
        public IActionResult Edit(int organisationId, ManageMessageId? message = null)
        {
            ViewData["StatusMessage"] = this.GetStatusMessage(message);

            var organisation = organisationService.GetOrganisationById(organisationId);

            if (organisation == null)
            {
                logger.LogError(LoggingEvents.OrganisationManagement, $"The organisation with id {organisationId} doesn't exist."); 
                return View("Error");
            }

            var model = new OrganisationViewModel
            {
                Id = organisation.Id,
                Name = organisation.Name,
                OrganisationContext = organisation.OrganisationContext
            };

            return View(model);
        }

        [HttpPost]
        public IActionResult Edit(OrganisationViewModel model)
        {
            var organisation = organisationService.GetOrganisationById(model.Id);
            organisation.Name = model.Name;
            organisation.OrganisationContext = model.OrganisationContext;
            organisationService.UpdateOrganisation(organisation);

            return RedirectToAction(nameof(Edit), new { organisationId = model.Id, message = ManageMessageId.UpdateOrganisationSuccess });
        }
    }
}