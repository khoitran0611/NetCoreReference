using System;
using System.Threading.Tasks;
using Hydra.UserManagement;
using Hydra.UserManagement.Models;
using Hydra.UserManagement.Models.AboutViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.PlatformAbstractions;

namespace UserManagement.Controllers
{
    public class AboutController : Controller
    {
        private readonly UserManager<ApplicationUser> userManager;
        private readonly ILogger logger;

        public AboutController(
            UserManager<ApplicationUser> userManager, 
            ILoggerFactory loggerFactory)
        {
            this.userManager = userManager;
            logger = loggerFactory.CreateLogger<AboutController>();
        }

        [HttpGet]
        [AllowAnonymous]
        public async Task<IActionResult> Index()
        {
            var model = new AboutViewModel();

            model.Version = PlatformServices.Default.Application.ApplicationVersion;

            model.StoreStatus = await CanFindUserAsync() ? "OK" : "Error";

            return Ok(model);
        }

        private async Task<bool> CanFindUserAsync()
        {
            try
            {
                return await userManager.FindByNameAsync(SecurityAdminUserBuilder.SecurityAdminEmail) != null;
            }
            catch (Exception ex)
            {
                logger.LogError(LoggingEvents.StoreStatus, ex, "Error in checking store status.");

                return false;
            }
        }
    }
}