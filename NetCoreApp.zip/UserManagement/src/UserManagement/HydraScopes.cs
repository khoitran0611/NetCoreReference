﻿namespace Hydra.UserManagement
{
    public static class HydraScopes
    {
        public const string UserManagement = "user.management";
        public const string HydraCpsApi = "hydra.cps.api";
        public const string HydraEventHistoryApi = "hydra.eventhistory.api";
        public const string HydraCrsApi = "hydra.crs.api";
        public const string HydraCrsWeb = "hydra.crs.web";
        public const string HydraDocumentsApi = "hydra.documents.api";
        public const string ChimeraCcsWeb = "chimera.ccs.web";
        public const string ChimeraCcsApi = "chimera.ccs.api";
        public const string PegasusCustomerSearch = "pegasus.customersearch";
        public const string CrmTasksApi = "crm.tasks.api";
        public const string CustomerManagementApi = "customermanagement.api";
        public const string HydraMotorRegistryApi = "hydra.motorregistry.api";
        public const string OrganisationContext = "organisation.context";
        public const string HydraCustomerAuthentication = "hydra.customerauthentication";
    }
}