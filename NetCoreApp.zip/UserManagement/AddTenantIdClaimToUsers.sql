﻿  MERGE AspNetUserClaims AS target
  USING AspNetUsers AS source
  ON target.UserId = source.Id
  AND target.ClaimType = 'http://schemas.microsoft.com/identity/claims/tenantid'
  WHEN NOT MATCHED BY TARGET THEN
  INSERT (ClaimType, ClaimValue, UserId)
  VALUES ('http://schemas.microsoft.com/identity/claims/tenantid', 'ba1ad08e-61a6-48ec-8c8a-b56c7a20c3f1', source.Id);
