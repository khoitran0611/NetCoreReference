﻿IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'Organisations')
BEGIN
    IF NOT EXISTS (SELECT * FROM Organisations WHERE OrganisationContext = 'ba1ad08e-61a6-48ec-8c8a-b56c7a20c3f1')
	BEGIN 
		INSERT Organisations VALUES('ba1ad08e-61a6-48ec-8c8a-b56c7a20c3f1', 'Triton Norway')
	END

	IF NOT EXISTS (SELECT * FROM Organisations WHERE OrganisationContext = 'ba1ad08e-61a6-48ec-8c8a-b56c7a20c3f1,19bbd4a3-1a33-4135-bc2d-0d87d2d1c148')
	BEGIN 
		INSERT Organisations VALUES('ba1ad08e-61a6-48ec-8c8a-b56c7a20c3f1,19bbd4a3-1a33-4135-bc2d-0d87d2d1c148', 'Statoil Forsikring AS')
	END

	IF NOT EXISTS (SELECT * FROM Organisations WHERE OrganisationContext = 'ba1ad08e-61a6-48ec-8c8a-b56c7a20c3f1,9efcc868-1d22-42a0-b749-2899f45e8137')
	BEGIN 
		INSERT Organisations VALUES('ba1ad08e-61a6-48ec-8c8a-b56c7a20c3f1,9efcc868-1d22-42a0-b749-2899f45e8137', 'Finse Forsikring AS')
	END

	IF NOT EXISTS (SELECT * FROM Organisations WHERE OrganisationContext = 'ba1ad08e-61a6-48ec-8c8a-b56c7a20c3f1,d61b5fff-7468-4339-bc29-566f3ff019b9')
	BEGIN 
		INSERT Organisations VALUES('ba1ad08e-61a6-48ec-8c8a-b56c7a20c3f1,d61b5fff-7468-4339-bc29-566f3ff019b9', 'R&Q Malta')
	END

	IF NOT EXISTS (SELECT * FROM Organisations WHERE OrganisationContext = 'ba1ad08e-61a6-48ec-8c8a-b56c7a20c3f1,da6e6843-97bf-45ad-a734-9a63b97f3da2')
	BEGIN 
		INSERT Organisations VALUES('ba1ad08e-61a6-48ec-8c8a-b56c7a20c3f1,da6e6843-97bf-45ad-a734-9a63b97f3da2', 'Statnett Forsikring AS')
	END

	IF NOT EXISTS (SELECT * FROM Organisations WHERE OrganisationContext = 'ba1ad08e-61a6-48ec-8c8a-b56c7a20c3f1,146f81b2-81f5-4928-abec-aa7562f3ad8e')
	BEGIN 
		INSERT Organisations VALUES('ba1ad08e-61a6-48ec-8c8a-b56c7a20c3f1,146f81b2-81f5-4928-abec-aa7562f3ad8e', 'Statkraft Forsikring AS')
	END

	IF NOT EXISTS (SELECT * FROM Organisations WHERE OrganisationContext = 'ba1ad08e-61a6-48ec-8c8a-b56c7a20c3f1,e9f18f0d-4af0-4f5a-8a31-c14f968575e4')
	BEGIN 
		INSERT Organisations VALUES('ba1ad08e-61a6-48ec-8c8a-b56c7a20c3f1,e9f18f0d-4af0-4f5a-8a31-c14f968575e4', 'Telenor Forsikring AS')
	END

	IF NOT EXISTS (SELECT * FROM Organisations WHERE OrganisationContext = 'ba1ad08e-61a6-48ec-8c8a-b56c7a20c3f1,5102438c-9736-456c-a1ac-fc50d2cf203d')
	BEGIN 
		INSERT Organisations VALUES('ba1ad08e-61a6-48ec-8c8a-b56c7a20c3f1,5102438c-9736-456c-a1ac-fc50d2cf203d', 'International General Insurance (IGI)')
	END
END